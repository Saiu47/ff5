from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MPLBACKEND', 'Agg')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')

scripts = [
    'Base/01_build_passenger_data.py',
    'Base/02_build_broad_data.py',
    'Base/03_run_factor_models.py',
    'Base/04_portfolio_robustness.py',
    'Base/05_lifecycle_matching.py',
    'Base/06_state_dependent_models.py',
    'C01/02_benchmark_frequency.py',
    'C02/01_matching_audit.py',
    'C03/01_hac_wald.py',
    'C04/01_frequency_reconstruction.py',
    'C04/02_official_monthly_factors.py',
    'C05/01_gap_concentration.py',
    'C05/02_event_audit.py',
    'C05/03_external_event_sources.py',
    'C05/05_tata_sensitivity.py',
    'C05/06_canoo_sensitivity.py',
    'C05/07_bloomberg_validation.py',
    'C05/08_issuer_documentation.py',
]
for script in scripts:
    print(script, flush=True)
    subprocess.run([sys.executable, str(ROOT / 'Code' / script)], cwd=ROOT, check=True)
