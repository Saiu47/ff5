from pathlib import Path
import os, subprocess, sys
ROOT=Path(__file__).resolve().parent
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg')
for script in ['run_all.py','run_alternative_benchmarks.py','Code/Benchmarks/compare_results.py','Code/Benchmarks/monthly_official_sensitivity.py']:
    subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,env=ENV,check=True)
