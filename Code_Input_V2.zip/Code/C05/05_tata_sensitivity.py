"""Focused event QA for Tata Motors; read frozen V2 OOXML without editing it.
Regression uses statsmodels OLS with HAC(Newey West) 22 lags, matching R1.
Creates transparent outputs as CSV and JSON; never replaces the baseline workbook.
"""
import csv,json,math,sys
from datetime import date,timedelta
from pathlib import Path
import numpy as np
import statsmodels.api as sm
from read_xlsx_xml import row_iter
ROOT=Path(__file__).resolve().parents[2]/'Input'/'V2'
OUT=Path(__file__).resolve().parents[2]/'Output'/'C05'
PASS=ROOT/'FF5_Passenger_Data.xlsx'; MARKET=ROOT/'FF5_Market_Data.xlsx'

def dt(x):
    if isinstance(x,(int,float)):
        return date(1899,12,30)+timedelta(days=int(x))
    if isinstance(x,str):
        return date.fromisoformat(x[:10])
    raise ValueError(x)

def table_by_dates(fname, sheet, columns=None):
    it=row_iter(fname,sheet); names=next(it)
    wanted=names if columns is None else columns
    idx=[names.index(n) for n in wanted]
    out={}
    for row in it:
        if not row:continue
        k=dt(row[0])
        out[k]={n:(row[i] if i<len(row) else None) for n,i in zip(wanted,idx)}
    return out

factor_names=['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','MOM']
models=table_by_dates(PASS,4,['Date','EV_Return','NonEV_Return','LS_Return','EV_Constituents','NonEV_Constituents',*factor_names])
returns=table_by_dates(PASS,1,['Date','Tata Motors'])
portfolios=table_by_dates(PASS,3,['Date','EV_Return','NonEV_Return','LS_Return','EV_Constituents','NonEV_Constituents'])
price=table_by_dates(MARKET,1,['Date','TMPV IN Equity'])
cap=table_by_dates(MARKET,2,['Date','TMPV IN Equity'])
monthly={}
it=row_iter(PASS,2)
next(it)
for row in it:
    if len(row)>5 and row[1]=='Tata Motors':
        monthly[dt(row[0]).strftime('%Y-%m')]=bool(row[5])

for day in models:
    assert abs(models[day]['LS_Return']-portfolios[day]['LS_Return'])<1e-12

D0=date(2025,10,14); D1=date(2025,11,12); D2=date(2025,12,31)

def event_date(d):return D0<=d<=D1

def recompose(day, orig):
    p=portfolios[day]
    val=returns.get(day,{}).get('Tata Motors')
    n=p['NonEV_Constituents']
    passing=monthly.get(day.strftime('%Y-%m'),False)
    if not passing or not isinstance(val,(float,int)) or n<=1:
        return orig,False
    if p['NonEV_Return'] is None: return orig,False
    without=(p['NonEV_Return']*n-val)/(n-1)
    new_y=p['EV_Return']-without
    return new_y,True

scenarios={
 'R1_full':lambda d,y:(True,y,False),
 'Drop_2025_10_14':lambda d,y:(d!=D0,y,False),
 'Drop_2025_10_14_to_11_12':lambda d,y:(not event_date(d),y,False),
 'Tata_removed_exdate_only':lambda d,y:(True, *recompose(d,y)) if d==D0 else (True,y,False),
 'Tata_removed_14Oct_12Nov':lambda d,y:(True, *recompose(d,y)) if event_date(d) else (True,y,False),
 'Tata_removed_14Oct_31Dec':lambda d,y:(True, *recompose(d,y)) if D0<=d<=D2 else (True,y,False),
 'Tata_removed_all_eligible_dates':lambda d,y:(True, *recompose(d,y)),
}
res=[]
allcoef={}
for name,fun in scenarios.items():
    ys=[]; xs=[]; changed=[]
    for d,vals in sorted(models.items()):
        include,y,ch=fun(d,vals['LS_Return'])
        if not include:continue
        ys.append(y);xs.append([1]+[vals[f] for f in factor_names]);
        if ch:changed.append(d)
    fit=sm.OLS(np.asarray(ys,dtype=float),np.asarray(xs,dtype=float)).fit(cov_type='HAC',cov_kwds={'maxlags':22,'use_correction':False},use_t=False)
    allcoef[name]={n:float(v) for n,v in zip(['const',*factor_names],fit.params)}
    for i,f in enumerate(['Alpha',*factor_names]):
        res.append({'Scenario':name,'Variable':f,'Coef':float(fit.params[i]),'SE_HAC22':float(fit.bse[i]),'t':float(fit.tvalues[i]),'p':float(fit.pvalues[i]),'N':len(ys),'Adjusted_R2':float(fit.rsquared_adj),'Tata_Removed_Days':len(changed)})

with open(OUT/'tata_event_regressions.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(res[0]));w.writeheader();w.writerows(res)

eventrows=[]
for d in sorted(set(price)&set(models)):
    if not date(2025,9,25)<=d<=date(2025,11,21):continue
    p=price[d].get('TMPV IN Equity');capd=cap.get(d,{}).get('TMPV IN Equity')
    prior=d-timedelta(days=1)
    # previous observed date, not calendar day
    prevs=[x for x in price if x<d and isinstance(price[x].get('TMPV IN Equity'),(float,int))]
    prev=max(prevs) if prevs else None
    pp=price[prev].get('TMPV IN Equity') if prev else None
    cc=cap[prev].get('TMPV IN Equity') if prev in cap else None
    y=models[d]['LS_Return']; n=models[d]['NonEV_Constituents']
    remove_y,actual=recompose(d,y)
    eventrows.append({'Date':d.isoformat(),'Observed_Price_USD':p,'Observed_Price_Prior_Date':prev.isoformat() if prev else None,
       'Observed_Price_Prior_USD':pp,'Price_USD_Return':p/pp-1 if p and pp else None,
       'MarketCap_USDmn':capd,'MarketCap_Prior_USDmn':cc,'MarketCap_Daily_Change':capd/cc-1 if capd and cc else None,
       'Tata_Stock_Return':returns.get(d,{}).get('Tata Motors'),'Tata_Eligible_50mn':monthly.get(d.strftime('%Y-%m'),False),
       'N_NonEV':n,'LS_R1':y,'LS_without_Tata':remove_y if actual else None,'Delta_LS_minus_R1':remove_y-y if actual else None})
with open(OUT/'tata_event_daily_qa.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(eventrows[0]));w.writeheader();w.writerows(eventrows)

summary={'R1_N':len(models),'Full_R1_Mkt_RF':allcoef['R1_full']['FF5_Mkt_RF'],
         'Full_R1_HML':allcoef['R1_full']['FF5_HML'],'Full_R1_RMW':allcoef['R1_full']['RMW'],
         'Tata_Price_13Oct':price[date(2025,10,13)]['TMPV IN Equity'],
         'Tata_Price_14Oct':price[date(2025,10,14)]['TMPV IN Equity'],
         'Tata_MCap_13Oct':cap[date(2025,10,13)]['TMPV IN Equity'],
         'Tata_MCap_14Oct':cap[date(2025,10,14)]['TMPV IN Equity'],
         'Tata_Price_Change':price[date(2025,10,14)]['TMPV IN Equity']/price[date(2025,10,13)]['TMPV IN Equity']-1,
         'Tata_MCap_Change':cap[date(2025,10,14)]['TMPV IN Equity']/cap[date(2025,10,13)]['TMPV IN Equity']-1,
         'Tata_Oct_MCap_Formation':next(v[4] for v in row_iter(PASS,2) if len(v)>5 and v[1]=='Tata Motors' and dt(v[0])==date(2025,10,1)),
         'Tata_Nov_MCap_Formation':next(v[4] for v in row_iter(PASS,2) if len(v)>5 and v[1]=='Tata Motors' and dt(v[0])==date(2025,11,1)),
         'Scenarios':allcoef}
with open(OUT/'tata_event_qa_summary.json','w',encoding='utf-8') as f:json.dump(summary,f,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k!='Scenarios'},indent=2))
print('---')
for name in scenarios:
    vals=allcoef[name]
    print(f'{name:32} HML {vals["FF5_HML"]:+.6f} RMW {vals["RMW"]:+.6f} Mkt {vals["FF5_Mkt_RF"]:+.6f}')
