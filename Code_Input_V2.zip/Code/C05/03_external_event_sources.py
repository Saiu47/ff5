from pathlib import Path
import csv,json
O=Path(__file__).resolve().parents[2]/'Output'/'C05'

def load(fname):
 with (O/fname).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(fname,rows):
 with (O/fname).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

externals=[
 ('KG Mobility','Trading resumed 2023-04-28 after prolonged suspension','2023-04-28','https://en.yna.co.kr/view/AEN20230427015400320','CONTEMPORANEOUS_NEWS','CONFIRMED_EVENT','Vendor dates 2023-02-09 to 2023-04-27 must be excluded in valid-segment sensitivity'),
 ('Zeekr','Acquisition of Lynk & Co completed; class changes EV to Non-EV','2025-02-14','https://www.sec.gov/Archives/edgar/data/1954042/000110465925013365/tm256005d1_ex99-1.htm','ISSUER_SEC','CONFIRMED_EVENT','Class break grounded by legal control date; validate class window endpoints and economic perimeter'),
 ('Zeekr','Geely merger effective 2025-12-22; trading suspended; last baseline trading day 2025-12-19','2025-12-22','https://www.sec.gov/Archives/edgar/data/1954042/000110465925123525/tm2534059d1_ex99-1.htm','ISSUER_SEC','CONFIRMED_EVENT','Final ordinary/ADS merger consideration and terminal payoff not explicitly integrated in R1 daily return'),
 ('Sono Group','Sion passenger-car program terminated, switching to solar third-party applications','2023-02-24','https://www.sec.gov/Archives/edgar/data/1840416/000117184324000984/exh_991.htm','ISSUER_SEC','CONFIRMED_EVENT','Economic end in R1 represents business-model exit rather than last day of any stock trading'),
 ('Sono Group','Shares were re-listed on Nasdaq in September 2025 under SSM','2025-09-05','https://www.sec.gov/Archives/edgar/data/1840416/000117184325007436/sev20250930_10q.htm','ISSUER_SEC','CONFIRMED_EVENT','No re-entry to EV passenger universe after pivot; no dummy/zero post-delisting'),
 ('Canoo','Nasdaq stock suspension January 29 2025 following bankruptcy','2025-01-29','https://www.sec.gov/Archives/edgar/data/1750153/000162828025002459/goev-20250124.htm','ISSUER_SEC','CONFIRMED_EVENT','V2 ends 2025-01-28; vendor ID ISIN; terminal return not estimated'),
 ('Fisker','NYSE suspended shares March 25 2024 and commenced delisting','2024-03-25','https://www.sec.gov/Archives/edgar/data/1720990/000172099024000032/fsr-20240325.htm','ISSUER_SEC','CONFIRMED_EVENT','V2 ends March 22 before suspension; post-NYSE OTC does not enter baseline'),
 ('Next.e.GO','Nasdaq suspension scheduled at open May 1, 2024 after appeal withdrawal','2024-05-01','https://www.sec.gov/Archives/edgar/data/1942808/000121390024037306/ea0204924-6k_nextego.htm','ISSUER_SEC','CONFIRMED_EVENT','V2 ends April 30; correct session-boundary rationale'),
 ('Next.e.GO','Principal subsidiary insolvency proceedings expected to open May 1, 2024','2024-04-30','https://www.sec.gov/Archives/edgar/data/1942808/000121390024037879/ea020500601ex99-1_nextego.htm','ISSUER_SEC','CONFIRMED_EVENT','Corporate event does not imply zero or negative-one delisting return automatically'),
 ('Tata Motors','Demerger record date; 1 CV share for every 1 existing share','2025-10-14','https://bsmedia.business-standard.com/_media/bs/data/announcements/bse/09102025/9f4e773d-a80f-4975-a15e-fb36e36e51ad.pdf','COMPANY_EXCHANGE_FILING','CONFIRMED_EVENT','Bloomberg price shows -1.27% 13-14 October versus raw-market ~40% ex-date drop; adjustment lineage still requires vendor validation'),
 ('Faraday Future','Nasdaq symbol changed FFIE to FFAI','2025-03-10','https://www.sec.gov/Archives/edgar/data/1805521/000162828025024006/ffie-20250331.htm','ISSUER_SEC','CONFIRMED_EVENT','V2 uses FFAI for pre-change history; preserve stable issuer-level ID across symbol change'),
 ('AvtoVAZ','Delisted from Moscow stock exchange in May 2019','2019-05','https://echanges.dila.gouv.fr/OPENDATA/AMF/281/2020/07/FC281345371_20200730.pdf','COMPANY_FINANCIAL_DISCLOSURE','CONFIRMED_EVENT','V2 economic end April 2019 appears earlier than delisting; verify last trade and price observations'),
 ('Lordstown Motors','RIDE Nasdaq trading from October 2020 to July 2023; traded OTC as RIDEQ thereafter','2020-10 to 2023-07','https://www.sec.gov/files/litigation/admin/2024/33-11274.pdf','SEC_REGULATOR','CONFIRMED_EVENT','R1 excluded due to absent mapped Bloomberg ID, not because no equity ever traded; targeted data/eligibility check needed'),
 ('Polestar','Nasdaq PSNY trading began June 24, 2022 after SPAC combination','2022-06-24','https://www.sec.gov/Archives/edgar/data/1847127/000119312522182029/d318554dex991.htm','ISSUER_SEC','CONFIRMED_EVENT','SPAC predecessor excluded in baseline'),
 ('Lotus Technology','LOT began trading on Nasdaq February 23, 2024 after SPAC combination','2024-02-23','https://www.sec.gov/Archives/edgar/data/1962746/000110465924027121/tm247116d1_ex99-1.htm','ISSUER_SEC','CONFIRMED_EVENT','SPAC predecessor excluded in baseline'),
 ('Chery Automobile','Listed HKEX on September 25, 2025','2025-09-25','https://www.hkexnews.hk/listedco/listconews/sehk/2025/1028/2025102802412.pdf','EXCHANGE_LISTING_DOCUMENT','CONFIRMED_EVENT','V2 economic start coincides with listing'),
 ('Dongfeng Motor Group','HKEX trading in H shares resumed August 25, 2025','2025-08-25','https://www1.hkexnews.hk/listedco/listconews/sehk/2025/0825/2025082500181.htm','EXCHANGE_NOTICE','CONFIRMED_EVENT','Large 2025-08-25 return in Bloomberg should be paired with market news; not mechanically removed'),
]
events=[dict(Company=c,Event=event,Event_Date=d,Source_URL=url,Source_Type=typ,Verification_Status=status) for c,event,d,url,typ,status,imp in externals]
write('validated_external_events.csv',events)
rows=load('issuer_audit_54.csv')
for row in rows:
    evidence=[e for e in events if e['Company']==row['Company']]
    if evidence:
        row['Reviewed_Primary_URL']=row.get('Reviewed_Primary_URL') or evidence[0]['Source_URL']
        row['Verified_Event_Note']=' | '.join(e['Event'] for e in evidence)
        row['External_Verification']='EVENT_VERIFIED_EXTERNAL'
write('issuer_audit_54.csv',rows)
