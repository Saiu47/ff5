"""Re-estimate full R1 LS FF5+MOM excluding Canoo on valid contribution days only.
Reader reuses read_xlsx_xml.py; no Excel file mutation. For days where EV leg would
be empty after Canoo's deletion, omit day; disclose count.
"""
import csv,json
from pathlib import Path
from datetime import date,timedelta
import numpy as np
import statsmodels.api as sm
from read_xlsx_xml import row_iter
P=Path(__file__).resolve().parents[2]/'Input'/'V2'/'FF5_Passenger_Data.xlsx'
O=Path(__file__).resolve().parents[2]/'Output'/'C05'

def dt(x):return date(1899,12,30)+timedelta(days=int(x))
mods={dt(r[0]):r for r in list(row_iter(P,4))[1:]}
rets=list(row_iter(P,1)); rh=rets[0]; ci=rh.index('Canoo'); canoo={dt(r[0]):(r[ci] if len(r)>ci else None) for r in rets[1:]}
elig={}
for r in list(row_iter(P,2))[1:]:
 if len(r)>=6 and r[1]=='Canoo': elig[dt(r[0]).strftime('%Y-%m')]=bool(r[5])
F=[14,15,16,17,18,19]  # col FF5_Mkt_RF,FF5_SMB,FF5_HML,RMW,CMA,MOM (0 based)
reg=[]
for sc in ['R1','Ex_Canoo']:
 xs=[];ys=[];modified=0;missing=0
 for day,r in sorted(mods.items()):
  ev=r[1];nonev=r[2];n=r[8];cr=canoo.get(day)
  if sc=='Ex_Canoo' and elig.get(day.strftime('%Y-%m'),False) and isinstance(cr,(float,int)):
   if n<2:missing+=1;continue
   ev=(ev*n-cr)/(n-1);modified+=1
  xs.append([1,*[r[i] for i in F]])
  ys.append(ev-nonev)
 fit=sm.OLS(np.asarray(ys,float),np.asarray(xs,float)).fit(cov_type='HAC',cov_kwds={'maxlags':22,'use_correction':False},use_t=False)
 for idx,name in enumerate(['Alpha','Mkt-RF','SMB','HML','RMW','CMA','MOM']):
  reg.append({'Scenario':sc,'Variable':name,'Coeff':float(fit.params[idx]),'p':float(fit.pvalues[idx]),'N':len(ys),'Changed_Days':modified,'Missing_EV_Leg_Days':missing})
with open(O/'canoo_taxonomy_sensitivity.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(reg[0]));w.writeheader();w.writerows(reg)
for rr in reg:
 if rr['Variable'] in ['HML','RMW','Mkt-RF']:print(rr)
