"""V2 source-documentation audit. Reads frozen inputs; never modifies R1.
Script reuses the same row-level standard-library OOXML reader used for Comment5 sensitivity.
"""
from __future__ import annotations
import csv,json,sys,math
from pathlib import Path
from collections import defaultdict,Counter
from datetime import date,timedelta
ROOT=Path(__file__).resolve().parents[2]/'Input'/'V2'
OUT=Path(__file__).resolve().parents[2]/'Output'/'C05'
sys.path.insert(0,str(Path(__file__).resolve().parent))
from importlib import import_module
src=import_module('01_gap_concentration')
load_sheet,dparse,val=src.load_sheet,src.dparse,src.val

def write_csv(path,records):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0].keys()));w.writeheader();w.writerows(records)

def headers(p,sh):
 it=iter(load_sheet(p,sh));head=next(it)
 return {str(v):j for j,v in head.items() if v not in ('',None)},it

def main():
 universe_rows=list(load_sheet(ROOT/'FF5_Universe_Definitions.xlsx','Passenger_Universe'))
 broad_rows=list(load_sheet(ROOT/'FF5_Universe_Definitions.xlsx','Broad_Universe'))
 uni=[[r.get(j) for j in range(max(r)+1)] for r in universe_rows[1:]]
 broad=[[r.get(j) for j in range(max(max(r)+1,16))] for r in broad_rows]
 broad_by=defaultdict(list)
 for r in broad[1:]:
  if r[0]:broad_by[str(r[0])].append(r)
 names=sorted({r[0] for r in uni}); tickers={r[1] for r in uni if r[1]}
 print('Universe',len(names),'tickers',len(tickers), flush=True)
 grouped=defaultdict(list)
 for r in uni:grouped[r[0]].append(r)
 # Market rows (full dates). Slice 2015-2025 only for audit of R1.
 price_dates=defaultdict(list); raw_price=defaultdict(dict)
 h,it=headers(ROOT/'FF5_Market_Data.xlsx','Prices_USD'); col2tick={j:k for k,j in h.items() if k in tickers}
 for r in it:
  if 0 not in r:continue
  d=dparse(r.get(0));
  if d is None or d<date(2015,1,1) or d>date(2025,12,31):continue
  for j,t in col2tick.items():
   p=val(r.get(j))
   if p is not None and p>0:price_dates[t].append(d);raw_price[t][d]=p
 print('Market prices extracted',len(price_dates), flush=True)
 dh,it=headers(ROOT/'FF5_Passenger_Data.xlsx','Daily_Returns'); cols={j:c for c,j in dh.items() if c in names}
 rstats=defaultdict(lambda:{'dates':[],'obs':[],'maxabs':0.0,'maxabs_date':None,'maxabs_value':None})
 for r in it:
  d=dparse(r.get(0))
  if d is None or d>date(2025,12,31):continue
  for j,c in cols.items():
   x=val(r.get(j))
   if x is None:continue
   s=rstats[c];s['dates'].append(d);s['obs'].append(x)
   if abs(x)>s['maxabs']:
    s['maxabs']=abs(x);s['maxabs_value']=x;s['maxabs_date']=d
 print('Returns parsed',len(rstats), flush=True)
 # Days contributing to R1 on model sample dates (and months eligible)
 h,it=headers(ROOT/'FF5_Passenger_Data.xlsx','Monthly_Eligibility')
 eligible=defaultdict(set);nmonths=Counter();sdate={};lcap={}
 for r in it:
  c=r.get(h['Company']);m=dparse(r.get(h['Month']))
  if c is None or m is None or m>date(2025,12,1):continue
  if r.get(h['Pass_USD50m']) is True:eligible[m].add(c);nmonths[c]+=1
 h,it=headers(ROOT/'FF5_Passenger_Data.xlsx','Model_Input')
 model_dates=set()
 for r in it:
  d=dparse(r.get(h['Date']))
  if d and d<=date(2025,12,31):model_dates.add(d)
 contribute=Counter();classcontrib=defaultdict(Counter)
 for c,s in rstats.items():
  for d in s['dates']:
   if d not in model_dates or c not in eligible[date(d.year,d.month,1)]:continue
   win=grouped[c]
   typ=next((x[6] for x in win if x[4] is not None and dparse(x[4])<=d<=dparse(x[5])),None)
   if typ in ('EV','Non-EV'):
    contribute[c]+=1;classcontrib[c][typ]+=1
 # some source cases verified externally, source-check timepoint 2026-11-22
 verifications={
 'Zeekr':('2025-02-14 Lynk & Co integration closing','https://www.sec.gov/Archives/edgar/data/1954042/000110465925013365/tm256005d1_ex99-1.htm','VERIFIED_PRIMARY'),
 'Sono Group':('2023-02-24 end Sion program; 2025-09-05 relisting pertains to different activity','https://www.sec.gov/Archives/edgar/data/1840416/000117184325007436/sev20250930_10q.htm','VERIFIED_PRIMARY'),
 'Canoo':('2025-01-29 Nasdaq suspension following January bankruptcy','https://www.sec.gov/Archives/edgar/data/1750153/000162828025002459/goev-20250124.htm','VERIFIED_PRIMARY'),
 'Fisker':('2024-03-25 NYSE immediate trading suspension; subsequent OTC is not baseline','https://www.sec.gov/Archives/edgar/data/1720990/000172099024000032/fsr-20240325.htm','VERIFIED_PRIMARY'),
 'Next.e.GO':('2024-04-26 additional Nasdaq delisting determination; terminal date rationale requires session-level check','https://www.sec.gov/Archives/edgar/data/1942808/000121390024037080/ea020489401ex99-1_nextegonv.htm','PARTIAL_PRIMARY'),
 'Tata Motors':('2025-10-14 Indian corporate demerger; price/cap continuity requires Bloomberg corporate-action lineage','https://www.bseindia.com/xml-data/corpfiling/AttachLive/bece4d69-3276-4305-88a5-440ed2a2660e.pdf','PARTIAL_PRIMARY'),
 'KG Mobility':('2023-04-28 Korean trading resumption; pre-resumption vendor observations quarantined','https://en.yna.co.kr/view/AEN20230427015400320','VERIFIED_NEWS'),
 }
 out=[];events=[]
 for c in names:
  rows=grouped[c];ticker=next((str(x[1]) for x in rows if x[1]),'')
  win_start=dparse(rows[0][2]) if rows[0][2] is not None else None
  win_end=dparse(rows[0][3]) if rows[0][3] is not None else None
  class_windows=[]
  for x in rows:
   if x[4] is not None:
    class_windows.append(f'{dparse(x[4])}..{dparse(x[5])}: {x[6]}')
  pr=[d for d in price_dates.get(ticker,[]) if win_start and win_end and win_start<=d<=win_end]
  sr=rstats.get(c,{});rt=sr.get('dates',[])
  source=broad_by.get(c,[])
  main=source[0] if source else None
  start_url=main[7] if main else ''
  end_url=main[9] if main else ''
  class_urls=sorted({x[14] for x in source if len(x)>14 and x[14] and str(x[14]).startswith('http')})
  status='INCLUDED_R1' if c in rstats else ('EXCLUDED_40_DAY_GAP' if c=='KG Mobility' else 'EXCLUDED_PRE_PRICE')
  manual_note,manual_url,verification=verifications.get(c,('','','NOT_INDEPENDENTLY_VERIFIED'))
  if c=='KG Mobility':status='EXCLUDED_40_DAY_GAP'
  if c in ('Lordstown Motors','Iran Khodro','SAIPA'):status='EXCLUDED_PRE_PRICE'
  # source provenance is not itself external verification of correctness
  source_count=bool(start_url)+bool(end_url)+bool(class_urls)
  is_terminal=win_end is not None and win_end<date(2025,12,31)
  last_price=pr[-1] if pr else None
  huge=sr.get('maxabs',0)>0.5
  is_reclass=len(set(r[6] for r in rows if r[6]))>1
  flags=[]
  if status.startswith('EXCLUDED'):flags.append('exclusion_justification')
  if is_terminal:flags.append('pre_sample_end_exit')
  if is_reclass:flags.append('class_change')
  if huge:flags.append('single_day_abs_return_gt50pct')
  if c=='Tata Motors':flags.append('2025_demerg_price_adjustment')
  if c=='Zeekr':flags.append('2025_change_ev_nonev')
  if c=='Sono Group':flags.append('2023_business_pivot_not_delisting')
  if c=='Next.e.GO':flags.append('2024_last_trade_vs_exchange_status')
  if c=='Faraday Future':flags.append('ticker_history_FFIE_FFAI')
  if c in ('Canoo','Fisker'):flags.append('isin_as_vendor_id')
  if c=='KG Mobility':flags.append('vendor_obs_during_suspension')
  if not (start_url or end_url or class_urls):flags.append('no_external_url_in_prior_registry')
  row=dict(Company=c,Bloomberg_ID=ticker,Status_R1=status,Class_Windows=' | '.join(class_windows),
      Economic_Start=win_start.isoformat() if win_start else '',Economic_End=win_end.isoformat() if win_end else '',
      First_Valid_Price_R1=pr[0].isoformat() if pr else '',Last_Valid_Price_R1=last_price.isoformat() if last_price else '',
      Return_Observations_R1=len(rt),Days_Contributing_Model=contribute.get(c,0),Contrib_EV_Days=classcontrib[c]['EV'],Contrib_NonEV_Days=classcontrib[c]['Non-EV'],
      Months_Passing_MCap_50m=nmonths[c],
      Max_Abs_Daily_Return=round(sr.get('maxabs_value',0),6) if rt else '',Max_Abs_Return_Date=sr['maxabs_date'].isoformat() if rt else '',
      Source_Start_URL=start_url or '',Source_End_URL=end_url or '',Source_Classification_URL=';'.join(class_urls),
      Reviewed_Primary_URL=manual_url,Verified_Event_Note=manual_note,
      External_Verification=verification,
      Audit_Flags=';'.join(flags),Source_Record='V2_Passenger_Universe + V2_Prices_USD + prior Step1_Revised_Audit')
  out.append(row)
  if status.startswith('EXCLUDED') or is_terminal or is_reclass or c in verifications:
   events.append(dict(Company=c,Event_Window=f'{win_start} - {win_end}',Event_Flags=row['Audit_Flags'],
       R1_Decision=status,Primary_or_Prior_URL=manual_url or end_url or start_url or ';'.join(class_urls),
       Verification=verification,Unresolved_Question='Verify actual terminal trading session, security/corporate actions and delisting return treatment' if is_terminal else 'Check issuer/security ID continuity and applicable event-date treatment'))
 write_csv(OUT/'issuer_audit_54.csv',out)
 write_csv(OUT/'event_exception_log.csv',events)
 summary={'candidates':len(out),'included':sum(x['Status_R1']=='INCLUDED_R1' for x in out),'excluded':sum(x['Status_R1']!='INCLUDED_R1' for x in out),
     'with_start_source':sum(bool(x['Source_Start_URL']) for x in out),'with_end_source':sum(bool(x['Source_End_URL']) for x in out),'with_classification_source':sum(bool(x['Source_Classification_URL']) for x in out),
     'without_any_prior_url':sum(not any([x['Source_Start_URL'],x['Source_End_URL'],x['Source_Classification_URL']]) for x in out),
     'verified_primary_manual':sum(x['External_Verification']=='VERIFIED_PRIMARY' for x in out),
     'event_exceptions':len(events),'max_return_flags':sum('single_day_abs_return_gt50pct' in x['Audit_Flags'] for x in out),
     'model_rows':len(model_dates),'total_contribution_firmdays':sum(contribute.values())}
 with open(OUT/'audit_summary.json','w') as f:json.dump(summary,f,indent=2)
 print('Summary:',summary, flush=True)
 print('Events:',[(x['Company'],x['Event_Flags']) for x in events])
 print('Large-return outliers:',[(x['Company'],x['Max_Abs_Daily_Return'],x['Max_Abs_Return_Date']) for x in out if 'single_day_abs_return_gt50pct' in x['Audit_Flags']])
 for c in ['Tata Motors','Zeekr','Sono Group','Next.e.GO','Canoo','Fisker']:
  rec=next(x for x in out if x['Company']==c)
  print(c,'first/last',rec['First_Valid_Price_R1'],rec['Last_Valid_Price_R1'],'last return',rec['Return_Observations_R1'],'contrib',rec['Days_Contributing_Model'])
 # 2025 October Tata price sequence (observed vendor prices, without valuation judgment)
 for c in ['Tata Motors','Zeekr']:
  id=next(x['Bloomberg_ID'] for x in out if x['Company']==c)
  dct=raw_price.get(id,{})
  extract=[]
  for d,p in sorted(dct.items()):
   if (c=='Tata Motors' and date(2025,10,7)<=d<=date(2025,10,23)) or (c=='Zeekr' and date(2025,2,7)<=d<=date(2025,2,24)):
    extract.append(dict(Company=c,Date=d.isoformat(),Price_USD=p))
  if extract:write_csv(OUT/f'price_event_{c.replace(" ","_")}.csv',extract)
if __name__=='__main__':main()
