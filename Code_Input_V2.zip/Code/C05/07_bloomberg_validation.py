"""Comment 5 – Bloomberg closeout QA and conditional RIDE inclusion.

Command: python 01_reproduce_comment5_bloomberg.py
Requires numpy, statsmodels. Uses built-in OOXML streaming, no proprietary data APIs.
All paths are relative to this script. Does NOT change the original R1 input workbooks.
"""
from __future__ import annotations
import csv, re, zipfile, json
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET
import numpy as np
import statsmodels.api as sm

HERE=Path(__file__).resolve().parents[2]
IN=HERE/'Input';OUT=HERE/'Output'/'C05';OUT.mkdir(exist_ok=True)
M='http://schemas.openxmlformats.org/spreadsheetml/2006/main';R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
FACTORS=['const','Mkt-RF','SMB','HML','RMW','CMA','MOM']

def cidx(ref):
    n=0
    for c in re.match(r'([A-Z]+)',ref).group(1):n=n*26+ord(c)-64
    return n-1

def rows(p,name,columns=None):
    with zipfile.ZipFile(p) as z:
        wk=ET.fromstring(z.read('xl/workbook.xml'))
        rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={e.attrib['Id']:e.attrib['Target'] for e in rel}
        sh=next(s for s in wk.findall('.//{'+M+'}sheet') if s.attrib['name']==name)
        path=targets[sh.attrib['{'+R+'}id']].lstrip('/')
        path=path if path.startswith('xl/') else 'xl/'+path
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            ss=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in s.iter('{'+M+'}t')) for s in ss.findall('{'+M+'}si')]
        with z.open(path) as f:
            for _,el in ET.iterparse(f,events=('end',)):
                if el.tag!='{'+M+'}row':continue
                out={}
                for c in el.findall('{'+M+'}c'):
                    k=cidx(c.attrib['r'])
                    if columns is not None and k not in columns:continue
                    v=c.find('{'+M+'}v');ty=c.attrib.get('t')
                    if ty=='inlineStr':
                        i=c.find('{'+M+'}is'); vv=''.join(t.text or '' for t in i.iter('{'+M+'}t')) if i is not None else ''
                    elif v is None:vv=None
                    elif ty=='s':vv=shared[int(v.text)]
                    elif ty in ('str','e'):vv=v.text
                    elif ty=='b':vv=v.text=='1'
                    else:
                        try:vv=float(v.text)
                        except(ValueError,TypeError):vv=v.text
                    out[k]=vv
                yield out
                el.clear()

def dt(v):
    if v is None or v=='':return None
    if isinstance(v,(int,float)):return date(1899,12,30)+timedelta(days=int(v))
    if isinstance(v,date):return v
    try:return datetime.strptime(str(v)[:10],'%Y-%m-%d').date()
    except(ValueError,TypeError):return None

def num(v):
    try:
        f=float(v)
        return f if np.isfinite(f) else None
    except(TypeError,ValueError):return None

def writecsv(name,lines):
    if not lines:return
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(lines[0]));w.writeheader();w.writerows(lines)

def estimate(sample,base):
    days=sorted(sample)
    y=np.array([sample[d] for d in days])
    X=sm.add_constant(np.array([base[d]['factors'] for d in days]),has_constant='add')
    res=sm.OLS(y,X).fit(cov_type='HAC',cov_kwds={'maxlags':22},use_t=False)
    return {'N':len(days),'first':str(days[0]),'last':str(days[-1]),'Adj_R2':float(res.rsquared_adj),
            **{n:float(v) for n,v in zip(FACTORS,res.params)},
            **{'p_'+n:float(v) for n,v in zip(FACTORS,res.pvalues)},
            **{'se_'+n:float(v) for n,v in zip(FACTORS,res.bse)}}

def main():
    src=IN/'Bloomberg_BDH_Export.xlsx'
    tata={};ride={};cap={};shares={}
    for r in rows(src,'TATA_BDH',columns={1,2,4,5}):
        day=dt(r.get(1)); adj=num(r.get(2));raw=num(r.get(5))
        if day and adj and raw:tata[day]=(adj,raw)
    for r in rows(src,'RIDE_PRET',columns={1,2,4,5,7,8}):
        day=dt(r.get(1)); adj=num(r.get(2));raw=num(r.get(5));vol=num(r.get(8))
        if day and adj and raw:ride[day]={'adj':adj,'raw':raw,'volume':vol}
    for r in rows(src,'RIDE_SIZE',columns={1,2,4,5}):
        day=dt(r.get(1)); c=num(r.get(2))
        if day and c and c>0:cap[day]=c
        sdt=dt(r.get(4));sh=num(r.get(5))
        if sdt and sh is not None:shares[sdt]=sh
    # Detailed CACS evidence
    events=[]
    for filename in ('CACS_Lordstown_SNFI.csv','CACS_Tata_TMPV.csv'):
        with (IN/filename).open(encoding='utf-8-sig',newline='') as f:
            rr=csv.reader(f); next(rr);next(rr);next(rr);next(rr);next(rr)
            for row in rr:
                if not row or not row[0]:continue
                events.append({'Source':filename,'Event':row[0],'Security':row[1],
                               'Announced':row[2],'Effective':row[3],
                               'Details':' | '.join(v.strip() for v in row[5:] if v.strip())})
    writecsv('Bloomberg_CACS_All_Events.csv',events)
    # Compare Tata with archived original V2 USD price series
    it=iter(rows(IN/'V2'/'FF5_Market_Data.xlsx','Prices_USD'))
    h=next(it);i=next(j for j,v in h.items() if str(v)=='TMPV IN Equity')
    historical={}
    for r in it:
        day=dt(r.get(0))
        if day in tata:
            price=num(r.get(i))
            if price is not None:historical[day]=price
    tata_out=[];pairs=[]
    for day in sorted(tata):
        adj,raw=tata[day]
        old=historical.get(day)
        if old:
            pairs.append((day,adj,old))
        tata_out.append({'Date':str(day),'New_PX_LAST_CapChg_Y_USD':adj,
                         'New_PX_LAST_CapChg_N_USD':raw,'Old_V2_Price_USD':old,
                         'Raw_To_Adjusted_Ratio':raw/adj,
                         'New_Adjusted_To_V2_Ratio':adj/old if old else ''})
    writecsv('Tata_Daily_Adjustment_Audit.csv',tata_out)
    daily_delta=[]
    for (d0,a0,b0),(d1,a1,b1) in zip(pairs,pairs[1:]):
        daily_delta.append({'Date':str(d1),'New_Adjusted_Return':a1/a0-1,
                            'Old_V2_Return':b1/b0-1,'Difference':(a1/a0-1)-(b1/b0-1)})
    writecsv('Tata_Return_Reconciliation.csv',daily_delta)
    # Lordstown: split-adjusted prices; monthly lagged cap from prior month last observation
    dates=sorted(ride)
    rret={};ride_out=[];gaps=[]
    for j,day in enumerate(dates):
        v=ride[day];p=dates[j-1] if j else None
        if p:
            gap=int(np.busday_count((p+timedelta(days=1)).isoformat(),day.isoformat()))
            if gap>=40:gaps.append((str(p),str(day),gap))
            else:rret[day]=v['adj']/ride[p]['adj']-1
        ride_out.append({'Date':str(day),'Adjusted_Price_USD':v['adj'],
                         'Raw_Price_USD':v['raw'],'Volume_shares':v['volume'],
                         'MarketCap_USD_mn':cap.get(day),
                         'Adjusted_Return':rret.get(day),
                         'Before_Bankruptcy':day<=date(2023,6,26)})
    writecsv('Lordstown_Daily_Bloomberg_Audit.csv',ride_out)
    # R1 fixed baseline
    it=iter(rows(IN/'V2'/'FF5_Passenger_Data.xlsx','Model_Input'))
    header=next(it);pos={str(v):j for j,v in header.items()}
    model={}
    for r in it:
        day=dt(r.get(pos['Date']))
        if not day or not(date(2015,1,1)<=day<=date(2025,12,31)):continue
        ls=num(r.get(pos['LS_Return']))
        f=[num(r.get(pos[k])) for k in ['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','MOM']]
        if ls is None or any(v is None for v in f):continue
        model[day]={'ls':ls,'ev':num(r.get(pos['EV_Return'])),
                    'nonev':num(r.get(pos['NonEV_Return'])),
                    'n_ev':int(r.get(pos['EV_Constituents']) or 0),'factors':f}
    if len(model)!=2765:raise AssertionError('Unexpected baseline N')
    formation={}
    for day in model:
        mon=date(day.year,day.month,1)
        if mon in formation:continue
        end=mon-timedelta(days=1);start=date(end.year,end.month,1)
        poss=[(d,v) for d,v in cap.items() if start<=d<=end]
        formation[mon]=max(poss) if poss else None
    eligible={}
    for day,v in model.items():
        mon=date(day.year,day.month,1)
        m=formation[mon]
        if m is not None and m[1]>=50 and day in rret:
            eligible[day]=rret[day]
    def build(limit):
        out={d:v['ls'] for d,v in model.items()};changed=[]
        for day,r in eligible.items():
            if day>limit:continue
            v=model[day]
            out[day]=(v['ev']*v['n_ev']+r)/(v['n_ev']+1)-v['nonev']
            changed.append(day)
        return out,changed
    base={d:v['ls'] for d,v in model.items()}
    strict,ds=build(date(2023,6,26))
    through,jds=build(date(2023,7,6))
    scenarios=[]
    for name,s in [('R1_baseline_unchanged',base),
                   ('RIDE_conditional_pre_bankruptcy',strict),
                   ('RIDE_conditional_through_last_Nasdaq_close',through),
                   ('Same_dates_R1', {d:base[d] for d in ds}),
                   ('Same_dates_RIDE', {d:strict[d] for d in ds})]:
        scenarios.append({'Scenario':name,**estimate(s,model)})
    writecsv('Conditional_RIDE_FF5_MOM_HAC22.csv',scenarios)
    eligible_rows=[]
    for day in sorted(eligible):
        mon=date(day.year,day.month,1)
        fm=formation[mon]
        eligible_rows.append({'Date':str(day),'Adjusted_RIDE_Return':eligible[day],
            'EV_N_Baseline':model[day]['n_ev'],'Prior_Month_Cap_Date':str(fm[0]),
            'Prior_Month_Cap_USD_mn':fm[1],
            'Pre_Bankruptcy':day<=date(2023,6,26)})
    writecsv('Lordstown_Monthly_Eligibility_Active_Days.csv',eligible_rows)
    metrics={
      'n_baseline':len(model),'n_tata_dates':len(tata),'n_tata_v2_overlaps':len(pairs),
      'tata_old_new_ratio_mean':float(np.mean([a/b for _,a,b in pairs])),
      'tata_old_new_ratio_std':float(np.std([a/b for _,a,b in pairs])),
      'tata_adjust_factor_pre_event':float(tata[date(2025,10,13)][1]/tata[date(2025,10,13)][0]),
      'tata_ret_event_new':float(tata[date(2025,10,14)][0]/tata[date(2025,10,13)][0]-1),
      'tata_ret_event_old':float(historical[date(2025,10,14)]/historical[date(2025,10,13)]-1),
      'tata_max_return_discrepancy':max(abs(x['Difference']) for x in daily_delta),
      'ride_start':str(min(dates)),'ride_end':str(max(dates)),
      'ride_n_price':len(ride),'ride_n_cap':len(cap), 'ride_long_gaps':gaps,
      'ride_pre_split_adj_ratio':float(ride[date(2023,5,23)]['adj']/ride[date(2023,5,23)]['raw']),
      'ride_split_adjusted_ret':float(rret[date(2023,5,24)]),
      'ride_split_raw_ret':float(ride[date(2023,5,24)]['raw']/ride[date(2023,5,23)]['raw']-1),
      'ride_eligible_days_to_bankruptcy':len(ds),
      'ride_eligible_days_until_nasdaq_end':len(jds),
      'ride_eligibility_by_year':dict(Counter(str(d.year) for d in ds)),
      'total_cacs_events':len(events)}
    (OUT/'Diagnostics.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'metrics':metrics,'scenarios':[{'name':x['Scenario'],'HML':x['HML'],'p_HML':x['p_HML'],'RMW':x['RMW'],'p_RMW':x['p_RMW']} for x in scenarios]},indent=2))

if __name__=='__main__':main()
