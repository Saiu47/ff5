"""Read OOXML values with standard library, avoiding any workbook mutation."""
import zipfile,xml.etree.ElementTree as ET,re
from datetime import datetime, timedelta
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

def row_iter(path,sheet_index=1):
    with zipfile.ZipFile(path) as z:
        ss=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.findall(NS+'si'):
                ss.append(''.join(t.text or '' for t in si.iter(NS+'t')))
        fp=z.open(f'xl/worksheets/sheet{sheet_index}.xml')
        for event,elt in ET.iterparse(fp,events=('end',)):
            if elt.tag!=NS+'row': continue
            vals={}
            for c in elt.findall(NS+'c'):
                r=c.attrib.get('r','')
                m=re.match(r'^([A-Z]+)',r)
                if not m: continue
                idx=0
                for ch in m.group(1): idx=idx*26+ord(ch)-64
                idx-=1
                v=c.find(NS+'v')
                if v is not None and v.text is not None:
                    raw=v.text
                    if c.attrib.get('t')=='s': val=ss[int(raw)]
                    elif c.attrib.get('t')=='b':val=raw=='1'
                    else:
                        try: val=float(raw) if '.' in raw or 'E' in raw.upper() else int(raw)
                        except ValueError: val=raw
                else:
                    t=c.find(NS+'is')
                    val=''.join(n.text or '' for n in t.iter(NS+'t')) if t is not None else None
                vals[idx]=val
            if vals: yield [vals.get(i) for i in range(max(vals)+1)]
            elt.clear()

if __name__=='__main__':
 from pathlib import Path
 root=Path(__file__).resolve().parents[2]/'Input'/'V2'
 for f,j in [('FF5_Passenger_Data.xlsx',1),('FF5_Passenger_Data.xlsx',2),('FF5_Passenger_Data.xlsx',3),('FF5_Passenger_Data.xlsx',4),('FF5_Market_Data.xlsx',1),('FF5_Market_Data.xlsx',2)]:
  it=row_iter(root/f,j)
  print(f,j, next(it)[:65]); print(next(it)[:13]);print()
