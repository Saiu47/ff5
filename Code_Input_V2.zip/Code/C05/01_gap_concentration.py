"""JBEM R2 Comment 5 reproducible analytical sensitivity.
Reads archived V2 XLSX using standard-library OOXML (no mutation of source workbooks).
Scenarios: reinstate valid KG Mobility segments; ex-Tesla common-date and EV leave-one-out.
Usage: python 01_comment5_sensitivity.py
"""
from __future__ import annotations
import csv, json, re, zipfile, io
from collections import defaultdict, Counter
from datetime import date, datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET
import numpy as np
import statsmodels.api as sm

ROOT=Path(__file__).resolve().parents[2]/'Input'/'V2'
OUT=Path(__file__).resolve().parents[2]/'Output'/'C05'; OUT.mkdir(exist_ok=True)
START=date(2015,1,1); END=date(2025,12,31)
M='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P='http://schemas.openxmlformats.org/package/2006/relationships'
A=['const','Mkt-RF','SMB','HML','RMW','CMA','MOM']


def col_idx(ref):
    col=re.match(r'([A-Z]+)',ref).group(1); n=0
    for c in col:n=n*26+(ord(c)-64)
    return n-1

def load_sheet(p,name,only_cols=None):
    with zipfile.ZipFile(p) as z:
        wk=ET.fromstring(z.read('xl/workbook.xml'))
        rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        targets={e.attrib['Id']:e.attrib['Target'] for e in rel}
        sh=next(x for x in wk.findall('.//{'+M+'}sheet') if x.attrib['name']==name)
        target=targets[sh.attrib['{'+R+'}id']].lstrip('/')
        path=target if target.startswith('xl/') else 'xl/'+target
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            ss=ET.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(t.text or '' for t in si.iter('{'+M+'}t')) for si in ss.findall('{'+M+'}si')]
        with z.open(path) as source:
            it=ET.iterparse(source, events=('end',))
            for _,el in it:
                if el.tag!='{'+M+'}row': continue
                data={}
                for c in el.findall('{'+M+'}c'):
                    j=col_idx(c.attrib['r'])
                    if only_cols is not None and j not in only_cols: continue
                    v=c.find('{'+M+'}v'); typ=c.attrib.get('t')
                    if typ=='inlineStr':
                        t=c.find('{'+M+'}is'); val=''.join(x.text or '' for x in t.iter('{'+M+'}t')) if t is not None else ''
                    elif v is None: val=None
                    elif typ=='s': val=strings[int(v.text)]
                    elif typ in ('str','e'): val=v.text
                    elif typ=='b': val=v.text=='1'
                    else:
                        try: val=float(v.text)
                        except (ValueError,TypeError):val=v.text
                    data[j]=val
                yield data
                el.clear()

def dparse(v):
    if v is None: return None
    if isinstance(v,(float,int)):return date(1899,12,30)+timedelta(days=int(v))
    if isinstance(v,date):return v
    return datetime.strptime(str(v)[:10],'%Y-%m-%d').date()

def val(x):
    try:
        f=float(x)
        return f if np.isfinite(f) else None
    except(TypeError,ValueError):return None

def cwrite(name,rows):
    if not rows: return
    with open(OUT/name,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)

def estimate(data):
    if len(data)<50:return None
    y=np.array([x[1] for x in data],dtype=float)
    x=sm.add_constant(np.array([x[2] for x in data],dtype=float),has_constant='add')
    res=sm.OLS(y,x).fit(cov_type='HAC',cov_kwds={'maxlags':22},use_t=False)
    return dict(n=len(y), first=data[0][0].isoformat(),last=data[-1][0].isoformat(), adj_r2=float(res.rsquared_adj),
                **{k:float(v) for k,v in zip(A,res.params)},
                **{'se_'+k:float(v) for k,v in zip(A,res.bse)},
                **{'p_'+k:float(v) for k,v in zip(A,res.pvalues)})

def weekdays_between(a,b):
    n=0;cur=a+timedelta(days=1)
    while cur<b:
        if cur.weekday()<5:n+=1
        cur+=timedelta(days=1)
    return n

def main():
    print('READ MODEL INPUT',flush=True)
    riter=iter(load_sheet(ROOT/'FF5_Passenger_Data.xlsx','Model_Input'))
    hdr=next(riter); headers={str(v):k for k,v in hdr.items() if v is not None}
    model={}
    for row in riter:
        dd=dparse(row.get(headers['Date']))
        if dd is None or dd<START or dd>END:continue
        ls=val(row.get(headers['LS_Return']))
        factors=[val(row.get(headers[k])) for k in ['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','MOM']]
        if ls is None or any(v is None for v in factors): continue
        model[dd]={'ls':ls,'ev':val(row.get(headers['EV_Return'])),'non':val(row.get(headers['NonEV_Return'])),
                  'factors':factors, 'n_ev':int(row.get(headers['EV_Constituents'],0)),'n_non':int(row.get(headers['NonEV_Constituents'],0))}
    dates=sorted(model)
    print('MODEL',len(dates),dates[0],dates[-1],flush=True)
    base=estimate([(d,model[d]['ls'],model[d]['factors']) for d in dates])
    print('BASE', base['Mkt-RF'],base['HML'],base['RMW'], flush=True)

    print('READ DAILY RETURNS',flush=True)
    it=iter(load_sheet(ROOT/'FF5_Passenger_Data.xlsx','Daily_Returns'))
    hr=next(it); comp={str(v):j for j,v in hr.items() if j and v not in (None,'')}
    daily={}
    for row in it:
        d=dparse(row.get(0))
        if d not in model: continue
        daily[d]={name:val(row.get(j)) for name,j in comp.items()}
    print('READ MONTHLY ELIGIBILITY',flush=True)
    it=iter(load_sheet(ROOT/'FF5_Passenger_Data.xlsx','Monthly_Eligibility'))
    eh=next(it);eh={str(v):j for j,v in eh.items() if v is not None}
    eligible=defaultdict(set)
    for r in it:
        m=dparse(r.get(eh['Month'])); name=r.get(eh['Company'])
        if m is not None and r.get(eh['Pass_USD50m']) is True:eligible[m].add(name)
    print('READ UNIVERSE',flush=True)
    it=iter(load_sheet(ROOT/'FF5_Universe_Definitions.xlsx','Passenger_Universe'))
    uh=next(it);uh={str(v):j for j,v in uh.items() if v is not None}
    windows=defaultdict(list); ids={}
    for r in it:
        name=r.get(uh['Company'])
        if not name:continue
        ids[name]=r.get(uh['Bloomberg_ID'])
        if r.get(uh['Classification_Start']) is not None:
            windows[name].append((dparse(r.get(uh['Classification_Start'])),dparse(r.get(uh['Classification_End'])),r.get(uh['Binary_Class'])))
    def getclass(name,d):
        for s,e,c in windows.get(name,[]):
            if s<=d<=e:return c
        return None
    def mkey(d):return date(d.year,d.month,1)
    # Validate reconstruction of portfolio cross-sections on every R1 model date.
    exposures={}; coverage=[]; ev_universe=set()
    maxdiff=0.0; diffs=0
    for d in dates:
        active=eligible.get(mkey(d),set())
        ev={c:r for c,r in daily[d].items() if r is not None and c in active and getclass(c,d)=='EV'}
        non={c:r for c,r in daily[d].items() if r is not None and c in active and getclass(c,d)=='Non-EV'}
        if not ev or not non: raise AssertionError(('Empty on baseline',d))
        aev=sum(ev.values())/len(ev); anon=sum(non.values())/len(non)
        err=max(abs(aev-model[d]['ev']), abs(anon-model[d]['non']))
        maxdiff=max(maxdiff,err)
        if err>1e-12:diffs+=1
        exposures[d]=(ev,non)
        ev_universe.update(ev)
        coverage.append({'Date':d.isoformat(),'EV_n':len(ev),'NonEV_n':len(non),
                         'Tesla_present':int('Tesla' in ev),'Tesla_only_EV':int(len(ev)==1 and 'Tesla' in ev),
                         'EV_ex_Tesla_n':len(ev)-int('Tesla' in ev),
                         'EV_companies':';'.join(sorted(ev))})
    print('RECON',maxdiff,diffs,'ev firms',len(ev_universe),flush=True)
    if maxdiff>1e-12:raise AssertionError('Could not recreate baseline daily constituents')

    # KG Mobility price series and USD50m market cap independently extracted.
    print('READ KG PRICES+CAP',flush=True)
    kg_id=str(ids['KG Mobility'])
    print('KG id',kg_id,flush=True)
    def getkg(sheet):
        it=iter(load_sheet(ROOT/'FF5_Market_Data.xlsx',sheet))
        header=next(it); kk=[j for j,v in header.items() if str(v)==kg_id]
        if len(kk)!=1:raise AssertionError((sheet,kk,kg_id))
        idx=kk[0]; obj={}
        # fast parse and filter
        for row in it:
            d=dparse(row.get(0)); v=val(row.get(idx))
            if d is not None and v is not None and v>0 and START<=d<=END:
                obj[d]=v
        return obj
    prices=getkg('Prices_USD');caps=getkg('MarketCap_USD')
    econ_start=dparse(next(r.get(uh['Economic_Start']) for r in load_sheet(ROOT/'FF5_Universe_Definitions.xlsx','Passenger_Universe') if r.get(uh['Company'])=='KG Mobility'))
    econ_end=dparse(next(r.get(uh['Economic_End']) for r in load_sheet(ROOT/'FF5_Universe_Definitions.xlsx','Passenger_Universe') if r.get(uh['Company'])=='KG Mobility'))
    prices={d:v for d,v in prices.items() if econ_start<=d<=econ_end}
    pdays=sorted(prices)
    gaps=[{'Left':left.isoformat(),'Right':right.isoformat(),'Weekdays_Missing':weekdays_between(left,right)} for left,right in zip(pdays,pdays[1:]) if weekdays_between(left,right)>=40]
    print('GAPS',gaps,flush=True)
    # Rule: each long interruption creates a new continuous segment. No cross-gap return.
    kg_returns={}; restart_days=[]
    for prev,d in zip(pdays,pdays[1:]):
        if weekdays_between(prev,d)>=40:
            restart_days.append(d);continue
        kg_returns[d]=prices[d]/prices[prev]-1
    # The exchange resumed trading on 2023-04-28 (Yonhap/Asia Business Daily). Bloomberg
    # provides price observations earlier in Feb-Apr during the documented suspension.
    # Exclude the suspended window and the first resumed close from return calculation.
    suspension_end=date(2023,4,27)
    resume_day=date(2023,4,28)
    verified_kg_returns={d:v for d,v in kg_returns.items() if d<=date(2020,12,21) or d>resume_day}
    suspect_obs=[d for d in pdays if date(2023,2,9)<=d<=suspension_end]
    # Previous month's last market cap, no prior cap -> not eligible, not future cap.
    months=sorted({mkey(d) for d in dates})
    kg_pass={}; kg_form={}
    for month in months:
        prior_month_end=month-timedelta(days=1)
        prior_month_start=date(prior_month_end.year,prior_month_end.month,1)
        if month==date(2015,1,1):
            obs=[(d,v) for d,v in sorted(caps.items()) if month<=d<date(2015,2,1) and d.weekday()<5]
            formation=obs[0] if obs else None
        else:
            obs=[(d,v) for d,v in sorted(caps.items()) if prior_month_start<=d<=prior_month_end and d.weekday()<5]
            formation=obs[-1] if obs else None
        kg_pass[month]=formation is not None and formation[1]>=50
        kg_form[month]=formation
    gap_cutoffs=[(dparse(x['Left']),dparse(x['Right'])) for x in gaps]
    def region(d):
        if not gap_cutoffs:return 'NO_GAP'
        if d<=gap_cutoffs[0][0]:return 'PRE_GAP'
        if d<gap_cutoffs[0][1]:return 'IN_GAP'
        return 'POST_GAP'
    kg_daily=[]; scenarios={n:[] for n in ['R1_baseline','KG_pre_gap_only','KG_verified_trading_segments','KG_vendor_segments_diagnostic','Ex_Tesla','Ex_Tesla_two_remaining_EV']}
    matched={n:[] for n in scenarios if n!='R1_baseline'}
    years=defaultdict(lambda:dict(days=0,tesla_only=0,tesla_present=0,ev_n_sum=0,ev_max=0,ev_gte2=0,ev_gte3=0))
    kg_used=Counter(); kg_diff_max=0
    loo={n:[] for n in sorted(ev_universe)};loo_comparison={n:[] for n in loo};loo_counts=Counter()
    for d in dates:
        ev,non=exposures[d];b=model[d];factors=b['factors'];month=mkey(d)
        scenarios['R1_baseline'].append((d,b['ls'],factors))
        yy=years[d.year];yy['days']+=1;yy['tesla_only']+=len(ev)==1 and 'Tesla' in ev;yy['tesla_present']+='Tesla' in ev
        yy['ev_n_sum']+=len(ev);yy['ev_max']=max(yy['ev_max'],len(ev));yy['ev_gte2']+=len(ev)>=2;yy['ev_gte3']+=len(ev)>=3
        kg_rt=kg_returns.get(d);kg_verified=verified_kg_returns.get(d);gg=region(d)
        can=(kg_rt is not None and kg_pass[month] and getclass('KG Mobility',d)=='Non-EV')
        kg_daily.append({'Date':d.isoformat(),'Segment':gg,'Price_observed':int(d in prices),'Return_observed':int(kg_rt is not None),
                         'Return':kg_rt,'Prior_month_cap_date':kg_form[month][0].isoformat() if kg_form[month] else '',
                         'Prior_month_cap_USD_mn':kg_form[month][1] if kg_form[month] else '',
                         'Pass_cap':int(kg_pass[month]),'Vendor_pre_reopening_observation':int(d in suspect_obs),
                         'Contribution_vendor_segments':int(can),
                         'Contribution_verified_trading_segments':int(kg_verified is not None and kg_pass[month] and getclass('KG Mobility',d)=='Non-EV')})
        for mode in ['KG_pre_gap_only','KG_verified_trading_segments','KG_vendor_segments_diagnostic']:
            mode_return=kg_verified if mode=='KG_verified_trading_segments' else kg_rt
            active=(mode_return is not None and kg_pass[month] and getclass('KG Mobility',d)=='Non-EV'
                    and (mode!='KG_pre_gap_only' or gg=='PRE_GAP'))
            newnon=(sum(non.values())+mode_return)/(len(non)+1) if active else b['non']
            value=b['ev']-newnon
            scenarios[mode].append((d,value,factors))
            matched[mode].append((d,b['ls'],factors))
            if active:kg_used[mode]+=1
            if mode=='KG_verified_trading_segments':kg_diff_max=max(kg_diff_max,abs(value-b['ls']))
        evex={c:v for c,v in ev.items() if c!='Tesla'}
        if evex:
            exval=(sum(evex.values())/len(evex))-b['non']
            scenarios['Ex_Tesla'].append((d,exval,factors)); matched['Ex_Tesla'].append((d,b['ls'],factors))
            if len(evex)>=2:
                scenarios['Ex_Tesla_two_remaining_EV'].append((d,exval,factors))
                matched['Ex_Tesla_two_remaining_EV'].append((d,b['ls'],factors))
        for firm in loo:
            if firm not in ev: continue
            x={n:r for n,r in ev.items() if n!=firm}
            if not x:continue
            loo[firm].append((d,(sum(x.values())/len(x))-b['non'],factors))
            loo_comparison[firm].append((d,b['ls'],factors))
            loo_counts[firm]+=1
    cwrite('daily_ev_concentration.csv',coverage)
    cwrite('kg_gap_eligible_daily.csv',kg_daily)
    cwrite('gap_events.csv',[dict(Ticker=kg_id,**g) for g in gaps])
    # Estimate all scenarios, plus baseline on identical dates (also subset 2021-25 for ex-Tesla).
    results=[]
    for mode,rows in scenarios.items():
        rr=estimate(rows)
        if not rr:continue
        for key,valr in [('scenario',rr),('same_dates_baseline',estimate(matched[mode]) if mode!='R1_baseline' else rr)]:
            results.append(dict(Scenario=mode,Comparison=key,**valr))
    post=date(2021,1,1)
    for mode in ['Ex_Tesla','Ex_Tesla_two_remaining_EV']:
        for suffix,rt in [('scenario',[x for x in scenarios[mode] if x[0]>=post]),('same_dates_baseline',[x for x in matched[mode] if x[0]>=post])]:
            res=estimate(rt)
            if res:results.append(dict(Scenario=mode+'_2021_25',Comparison=suffix,**res))
    lresults=[]
    for firm in loo:
        est=estimate(loo[firm]); baseline=estimate(loo_comparison[firm]);
        if est is None or baseline is None: continue
        lresults.append(dict(Firm=firm,LOO_n=loo_counts[firm],LOO_HML=est['HML'],LOO_HML_p=est['p_HML'],
                             LOO_RMW=est['RMW'],LOO_RMW_p=est['p_RMW'],
                             LOO_MKT=est['Mkt-RF'],LOO_MKT_p=est['p_Mkt-RF'],
                             Baseline_same_dates_HML=baseline['HML'],Baseline_same_dates_RMW=baseline['RMW'],
                             delta_HML=est['HML']-baseline['HML'],delta_RMW=est['RMW']-baseline['RMW']))
    lresults.sort(key=lambda x:x['Firm'])
    # Fixed 2021-2025 period: remove each EV firm on every date, retaining exactly the same dates.
    # Dates on which the firm was absent remain unchanged, an important distinction from
    # firm-active-period leave-one-out above. All models use the same comparison window.
    fixed_days=[d for d in dates if d>=date(2021,1,1)]
    fixed_base=estimate([(d,model[d]['ls'],model[d]['factors']) for d in fixed_days])
    fixed_loo=[]
    for firm in sorted(ev_universe):
        pair=[]; active_count=0; min_remaining=10000
        for d in fixed_days:
            ev,non=exposures[d]
            if firm in ev:active_count+=1
            rest=[v for name,v in ev.items() if name!=firm]
            min_remaining=min(min_remaining,len(rest))
            if not rest:raise AssertionError('Cannot maintain common date without EV: '+str((firm,d)))
            rv=sum(rest)/len(rest)-model[d]['non']
            pair.append((d,rv,model[d]['factors']))
        res=estimate(pair)
        fixed_loo.append(dict(Firm_removed=firm,Days_2021_2025=len(fixed_days),Days_firm_active=active_count,
                              Remaining_EV_min=min_remaining,Mkt_RF=res['Mkt-RF'],Mkt_RF_p=res['p_Mkt-RF'],
                              SMB=res['SMB'],SMB_p=res['p_SMB'],HML=res['HML'],HML_p=res['p_HML'],
                              RMW=res['RMW'],RMW_p=res['p_RMW'],CMA=res['CMA'],CMA_p=res['p_CMA'],
                              MOM=res['MOM'],MOM_p=res['p_MOM'],adj_r2=res['adj_r2'],
                              Difference_from_baseline_HML=res['HML']-fixed_base['HML'],
                              Difference_from_baseline_RMW=res['RMW']-fixed_base['RMW']))
    cwrite('loo_fixed_2021_2025.csv',fixed_loo)
    cwrite('scenario_regressions.csv',results);cwrite('ev_leave_one_out.csv',lresults)
    cy=[dict(Year=k,**v,Avg_EV_n=v['ev_n_sum']/v['days'],
             Pct_Tesla_only=v['tesla_only']/v['days'],Pct_at_least_two_EV=v['ev_gte2']/v['days']) for k,v in sorted(years.items())]
    cwrite('annual_ev_concentration.csv',cy)
    metrics={'baseline':base,'baseline_recreation_max_diff':maxdiff,'baseline_recreation_bad_days':diffs,
             'kg_bbg_id':kg_id,'kg_economic_start':econ_start.isoformat(),'kg_economic_end':econ_end.isoformat(),
             'kg_long_gaps':gaps,'kg_segment_restart_days':[x.isoformat() for x in restart_days],
             'kg_max_abs_daily_ls_change':kg_diff_max,'kg_used_days':dict(kg_used),
             'kg_vendor_obs_in_suspension':len(suspect_obs),
             'kg_vendor_pre_reopening_first':suspect_obs[0].isoformat() if suspect_obs else None,
             'kg_vendor_pre_reopening_last':suspect_obs[-1].isoformat() if suspect_obs else None,
             'kg_verified_resume_day':resume_day.isoformat(),
             'tesla_only_total':sum(r['Tesla_only_EV'] for r in coverage),
             'total_days':len(dates),'ev_firms_with_contribution':sorted(ev_universe),'annual':cy,
             'scenario_results':results,'loo':lresults,'loo_fixed':fixed_loo,'baseline_fixed_2021_2025':fixed_base}
    (OUT/'results.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False),encoding='utf8')
    print('SUMMARY',json.dumps({k:metrics[k] for k in ('kg_used_days','tesla_only_total','total_days','kg_max_abs_daily_ls_change')},ensure_ascii=False))
    for r in results:
        if r['Comparison']=='scenario':print(r['Scenario'],r['n'], 'mkt',round(r['Mkt-RF'],4), 'hml',round(r['HML'],4),'p',round(r['p_HML'],4),'rmw',round(r['RMW'],4),'p',round(r['p_RMW'],4))
    print('LOO',len(lresults),'saved')

if __name__=='__main__':main()
