from pathlib import Path
import pandas as pd, numpy as np, statsmodels.api as sm
B=Path(__file__).resolve().parents[2]; I=B/'Input'/'V2'; O=B/'Output'/'C02';O.mkdir(parents=True,exist_ok=True)
read=lambda file,sheet: pd.read_excel(I/file,sheet_name=sheet)
M='FF5_Lifecycle_Matching.xlsx'; P='FF5_Passenger_Data.xlsx'
a=read(M,'Annual_Covariates'); pr=read(M,'Primary_Pairs'); st=read(M,'Strict_Pairs'); se=read(M,'Sensitivity_Pairs'); orig=read(M,'Matched_Models'); strict=st[st.Final_Strict_Pair==True]
D={'Primary':pr,'Strict_Balance':strict,'NN_With_Replacement':se[se.Matching_Specification=='NN_With_Replacement'],'Age_Proxy':se[se.Matching_Specification=='Age_Proxy']}
m=read(P,'Model_Input').set_index('Date');m.index=pd.to_datetime(m.index);idx=m.index[m.index.year>=2016];r=read(P,'Daily_Returns').set_index('Date');r.index=pd.to_datetime(r.index);r=r.reindex(idx)
e=read(P,'Monthly_Eligibility');e.Month=pd.to_datetime(e.Month).dt.to_period('M'); passes={(q.Company,q.Month):bool(q.Pass_USD50m) for q in e.itertuples()};u=read('FF5_Universe_Definitions.xlsx','Passenger_Universe');
for c in ['Classification_Start','Classification_End']:u[c]=pd.to_datetime(u[c])
months=idx.to_period('M'); cls={}
for (bid,g),z in u.dropna(subset=['Bloomberg_ID']).groupby(['Bloomberg_ID','Binary_Class']):
 mask=np.zeros(len(idx),bool)
 for q in z.itertuples():mask|=(idx>=q.Classification_Start)&(idx<=q.Classification_End)
 cls[bid,g]=mask
cov=['log_mcap','bm_w','roa_w','log_age']; lookup=a.set_index(['return_year','bbg_id']); eligible=a[a.psm_eligible==True];
models={'FF3':['FF3_Mkt_RF','FF3_SMB','FF3_HML'],'FF5':['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA'],'FF5+MOM':['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','MOM']}; names=['alpha','Mkt-RF','SMB','HML','RMW','CMA','MOM']
rows=[]; bal=[]; coverage=[]; pairdays=[]; counts=[]; loo=[]; dailyall=[]; pairlist=[]; support=[]
def fit(d,model,portfolio):
 x=m.reindex(d.index)[models[model]]; y=d[portfolio].copy();rf='FF3_RF' if model=='FF3' else 'FF5_RF';
 if portfolio!='LS':y=y-m.reindex(d.index)[rf]
 data=pd.concat([y.rename('y'),x],axis=1).dropna(); n=len(data)
 if n<=len(x.columns)+1:return []
 reg=sm.OLS(data.y,sm.add_constant(data.iloc[:,1:],has_constant='add')).fit(cov_type='HAC',cov_kwds={'maxlags':22}); ci=reg.conf_int().to_numpy()
 return [dict(Variable=v,Coefficient=b,p_value=p,HAC_SE=s,HAC_t=t,CI95_Lower=c[0],CI95_Upper=c[1],N=n,Start=data.index.min(),End=data.index.max(),Adj_R2=reg.rsquared_adj) for v,b,p,s,t,c in zip(names,reg.params,reg.pvalues,reg.bse,reg.tvalues,ci)]
def balance(design,stage,year,l,h):
 for v in cov:
  x=l[v].astype(float);y=h[v].astype(float);den=np.sqrt((x.var(ddof=1)+y.var(ddof=1))/2);diff=x.mean()-y.mean();smd=diff/den if pd.notna(den) and den>1e-15 else np.nan
  bal.append(dict(Design=design,Stage=stage,Year=year,Variable=v,EV_N=len(x),NonEV_N=len(y),EV_mean=x.mean(),NonEV_mean=y.mean(),Denominator=den,SMD=smd,Abs_SMD=abs(smd),Status='Defined' if np.isfinite(smd) else 'Undefined: fewer than two observations or zero variance'))
def portfolios(A,H,keep):
 X=A[:,keep];Y=H[:,keep]; n=np.isfinite(X).sum(axis=1); ok=n>0; x=np.full(len(idx),np.nan);y=x.copy();x[ok]=np.nansum(X[ok],axis=1)/n[ok];y[ok]=np.nansum(Y[ok],axis=1)/n[ok];return pd.DataFrame({'EV':x,'NonEV':y,'LS':x-y,'Pairs_N':n},index=idx)
for design,pairs in D.items():
 pairs=pairs.reset_index(drop=True); A=np.full((len(idx),len(pairs)),np.nan);H=A.copy(); keys=[]
 for j,p in pairs.iterrows():
  y=p.Return_Year;ev=p.EV_Company;ne=p.NonEV_Company;eb=p.EV_Bloomberg_ID;nb=p.NonEV_Bloomberg_ID;keys.append((y,eb,nb));x=r[ev].to_numpy(float);z=r[ne].to_numpy(float)
  ok=(idx.year==y)&np.isfinite(x)&np.isfinite(z)&cls[eb,'EV']&cls[nb,'Non-EV']&np.array([passes.get((ev,t),False) and passes.get((ne,t),False) for t in months]); A[ok,j]=x[ok];H[ok,j]=z[ok];pairdays.append(dict(Design=design,Year=y,EV=ev,NonEV=ne,EV_ID=eb,NonEV_ID=nb,Contributing_Days=ok.sum(),First=idx[ok].min(),Last=idx[ok].max()))
  pairlist.append(dict(Design=design,**p.to_dict()))
 d=portfolios(A,H,list(range(len(pairs)))); d.index.name='Date'; dailyall.append(d.assign(Design=design).reset_index()); counts.append(dict(Design=design,Assignments=len(pairs),EV_Unique=pairs.EV_Bloomberg_ID.nunique(),NonEV_Unique=pairs.NonEV_Bloomberg_ID.nunique(),Unique_Pairs=pairs[['EV_Bloomberg_ID','NonEV_Bloomberg_ID']].drop_duplicates().shape[0],Days=(d.Pairs_N>0).sum(),First=d.LS.dropna().index.min(),Last=d.LS.dropna().index.max()))
 for y in range(2016,2026):
  n=d.loc[d.index.year==y,'Pairs_N']; active=n[n>0];p=pairs[pairs.Return_Year==y]; coverage.append(dict(Design=design,Year=y,Assignments=len(p),Factor_Days=len(n),Active_Days=len(active),Coverage=len(active)/len(n),Mean_Pairs_Active=active.mean(),**{f'Days_{i}_Pairs':(n==i).sum() for i in range(10)}))
  q=eligible[eligible.return_year==y]; balance(design,'Before',y,q[q.group_outcome=='EV'],q[q.group_outcome=='Non-EV']); l=lookup.reindex(list(zip(p.Return_Year,p.EV_Bloomberg_ID)));h=lookup.reindex(list(zip(p.Return_Year,p.NonEV_Bloomberg_ID)));balance(design,'Matched',y,l,h)
 balance(design,'Matched','Pooled',lookup.reindex(list(zip(pairs.Return_Year,pairs.EV_Bloomberg_ID))),lookup.reindex(list(zip(pairs.Return_Year,pairs.NonEV_Bloomberg_ID))))
 full=m[['EV_Return','NonEV_Return','LS_Return']].rename(columns={'EV_Return':'EV','NonEV_Return':'NonEV','LS_Return':'LS'}); same=full.loc[d.LS.dropna().index]
 for model in models:
  for port in ['EV','NonEV','LS']:
   for typ,frame in [('Matched',d),('Unmatched_Same_Dates',same),('Unmatched_Full',full)]:
    results=fit(frame,model,port)
    for v in results:rows.append(dict(Design=design,Type=typ,Model=model,Portfolio=port,**v))
    if typ=='Matched':
     ref=orig[(orig.Analysis_Type=='Matched')&(orig.Matching_Specification==design)&(orig.Model==model)&(orig.Portfolio==port)].set_index('Variable')
     for v in results:
      assert abs(v['Coefficient']-ref.loc[v['Variable'],'Coefficient'])<1e-10,(design,model,port,v)
      assert abs(v['p_value']-ref.loc[v['Variable'],'p_value'])<1e-9
 if design not in ['Primary','Strict_Balance']:continue
 scenarios=[]
 for side in ['EV','NonEV']:
  for firm in sorted(pairs[f'{side}_Company'].unique()):scenarios.append((side+'_Firm',firm,np.flatnonzero(pairs[f'{side}_Company'].to_numpy()!=firm)))
 for j,p in pairs.iterrows():scenarios.append(('Firm_Year_Pair',f'{p.Return_Year}: {p.EV_Company} / {p.NonEV_Company}',[k for k in range(len(pairs)) if k!=j]))
 for (ev,ne),group in pairs.groupby(['EV_Company','NonEV_Company']):scenarios.append(('Unique_Firm_Pair',f'{ev} / {ne}',[k for k in range(len(pairs)) if k not in group.index]))
 for typ,label,keep in scenarios:
  alt=portfolios(A,H,keep); dates=alt.LS.dropna().index
  for variant,frame in [('Deletion',alt),('Matched_Same_Dates',d.loc[dates])]:
   for v in fit(frame,'FF5+MOM','LS'):loo.append(dict(Design=design,Deletion_Type=typ,Excluded=label,Retained_Assignments=len(keep),Variant=variant,**v))
for y in range(2016,2026):
 q=a[a.return_year==y]; ev=q[(q.psm_eligible==True)&(q.group_outcome=='EV')]; ne=q[(q.psm_eligible==True)&(q.group_outcome=='Non-EV')]; strict_support=read(M,'Strict_Balance');ss=int(strict_support[(strict_support.Record_Type=='Support')&(strict_support.return_year==y)].n_ev_support.iloc[0]); ps=int(ev.att_support.sum()); p=(pr.Return_Year==y).sum();c=(st.Return_Year==y).sum();f=(strict.Return_Year==y).sum();support.append(dict(Year=y,Candidate_FirmYears=len(q),Eligible_EV=len(ev),Eligible_NonEV=len(ne),Primary_Support=ps,Primary_Outside_Support=len(ev)-ps,Primary_Assigned=p,Primary_Supported_Unassigned=ps-p,Strict_Support=ss,Strict_Outside_Support=len(ev)-ss,Strict_Candidate=c,Strict_Supported_Unassigned=ss-c,Strict_Final=f,Strict_Removed_Balance=c-f))
for name,data in [('Matching_Models',rows),('Annual_Balance',bal),('Annual_Coverage',coverage),('Pair_Daily_Contribution',pairdays),('Unique_Counts',counts),('Leave_One_Out',loo),('Annual_Pair_List',pairlist),('Common_Support',support)]:pd.DataFrame(data).to_csv(O/(name+'.csv'),index=False)
pd.concat(dailyall).to_csv(O/'Daily_Matched_Portfolios.csv',index=False)
print('All 36 original matched regressions reproduced, coefficients and p-values.'); print(pd.DataFrame(counts).to_string(index=False));print(pd.DataFrame(support).to_string(index=False));
