"""Independent, source-locked reproduction of Comment 4, 2026-11-22.
No source workbook edits. Input read via standard OOXML ZIP parser (stdlib).
Python dependencies only numpy, scipy and statsmodels for econometrics.
"""
from pathlib import Path
from collections import OrderedDict
from datetime import timedelta
import numpy as np, csv, json, math, sys, os
import statsmodels.api as sm
HERE=Path(__file__).resolve().parents[2]/'Output'/'C04'
CODE_DIR=Path(__file__).resolve().parent
sys.path.insert(0, str(CODE_DIR))
from ff5_rapid_xml import as_records,serial_to_date
SRC=Path(__file__).resolve().parents[2]/'Input'/'V2'
F=['Mkt-RF','SMB','HML','RMW','CMA','MOM']
FM={'Mkt-RF':'FF5_Mkt_RF','SMB':'FF5_SMB','HML':'FF5_HML','RMW':'RMW','CMA':'CMA','MOM':'MOM'}

def finite(x):return x is not None and math.isfinite(x)

def prodret(values):return float(math.prod(1+x for x in values)-1.)

def rows_to_csv(p, recs, headers=None):
    recs=list(recs)
    if headers is None: headers=list(dict.fromkeys(k for r in recs for k in r))
    with p.open('w',encoding='utf-8-sig',newline='') as file:
        wr=csv.DictWriter(file,fieldnames=headers,extrasaction='ignore')
        wr.writeheader(); wr.writerows(recs)

raw=[]
for r in as_records(SRC/'FF5_Passenger_Data.xlsx','Model_Input'):
    day=serial_to_date(r['Date'])
    if day.year>2025 or day.year<2015:continue
    if not all(finite(r[x]) for x in ['EV_Return','NonEV_Return','LS_Return','FF5_RF',*FM.values()]): continue
    assert abs((r['EV_Return']-r['NonEV_Return'])-r['LS_Return'])<1e-12
    raw.append({'Date':day,'EV':float(r['EV_Return']),'NonEV':float(r['NonEV_Return']),
                'LS':float(r['LS_Return']),'RF':float(r['FF5_RF']),
                **{f:float(r[FM[f]]) for f in F}})
assert len(raw)==2765,len(raw)
assert str(raw[0]['Date'])=='2015-01-05' and str(raw[-1]['Date'])=='2025-12-31'


def weekly_key(day):return str(day+timedelta(days=4-day.weekday()))
def monthly_key(day):return f'{day.year:04d}-{day.month:02d}'

def period_data(period_type):
    gs=OrderedDict()
    for r in raw:
        key=weekly_key(r['Date']) if period_type=='Weekly' else monthly_key(r['Date'])
        gs.setdefault(key,[]).append(r)
    data=[]
    for key,vals in gs.items():
        ev=prodret([r['EV'] for r in vals]); nev=prodret([r['NonEV'] for r in vals]);
        ls2=ev-nev; ls1=prodret([r['LS'] for r in vals]);
        # Method 1: exact R1 factor process (compounding signed daily factor spreads).
        factor_comp={f:prodret([r[f] for r in vals]) for f in F}
        # Method 2: additive aggregation of factor returns; for factor-mimicking spreads
        #           this is a 1st-order approximation, NOT official weekly/monthly French data.
        factor_sum={f:float(math.fsum(r[f] for r in vals)) for f in F}
        # Alternate market premium from daily gross Rm and RF, reinvesting separately.
        market_gross=prodret([r['Mkt-RF']+r['RF'] for r in vals]); rf_gross=prodret([r['RF'] for r in vals]);
        factor_mix={**factor_sum,'Mkt-RF':market_gross-rf_gross}
        data.append({'Period':key,'Frequency':period_type,'First_Date':str(vals[0]['Date']),
                     'Last_Date':str(vals[-1]['Date']),'Daily_N':len(vals),
                     'EV_Compounded':ev,'NonEV_Compounded':nev,
                     'LS_DirectCompounded':ls1,'LS_SeparateLegs':ls2,'Difference_SeparateMinusDirect':ls2-ls1,
                     'RF_Compounded':rf_gross,
                     **{f'F_comp_{f}':factor_comp[f] for f in F},
                     **{f'F_sum_{f}':factor_sum[f] for f in F},
                     **{f'F_hybrid_{f}':factor_mix[f] for f in F}})
    return data

rows_week=period_data('Weekly'); rows_month=period_data('Monthly')
assert len(rows_week)==574, len(rows_week)
assert len(rows_month)==132, len(rows_month)


def estimate(records, dep, factor_prefix, lag, frequency, sample='Full sample', method_label=None):
    X=np.array([[r['F_'+factor_prefix+'_'+f] for f in F] for r in records],dtype=float)
    y=np.array([r[dep] for r in records],dtype=float)
    model=sm.OLS(y,sm.add_constant(X,has_constant='add')).fit(cov_type='HAC',cov_kwds={'maxlags':lag,'use_correction':False})
    res=[]
    for idx,term in enumerate(['alpha']+F):
        conf=model.conf_int()[idx]
        res.append({'Frequency':frequency,'LS_Definition':dep,'Factor_Aggregation':factor_prefix,
            'Model_Label':method_label or '', 'Sample':sample,'HAC_Lags':lag,'Variable':term,
            'Coefficient':float(model.params[idx]),'HAC_SE':float(model.bse[idx]),
            't':float(model.tvalues[idx]),'p_value':float(model.pvalues[idx]),
            'CI95_Lower':float(conf[0]),'CI95_Upper':float(conf[1]),
            'N':int(model.nobs),'R2':float(model.rsquared),'Adj_R2':float(model.rsquared_adj)})
    return res

result=[]
for typ,rs,lags in [('Weekly',rows_week,5),('Monthly',rows_month,3)]:
    for factors in ['comp','sum','hybrid']:
        for dep in ['LS_DirectCompounded','LS_SeparateLegs']:
            tag=('R1 reproduced' if factors=='comp' and dep=='LS_DirectCompounded' else
                 'Corrected LS, R1 factor process' if factors=='comp' and dep=='LS_SeparateLegs' else
                 'Alternative daily-factor approximation')
            result+=estimate(rs,dep,factors,lags,typ,method_label=tag)

original=list(as_records(SRC/'FF5_Passenger_Results.xlsx','Frequency_Robustness'))
for typ in ['Weekly','Monthly']:
    old={x['Variable']:x for x in original if x['Record_Type']=='Coefficient' and x['Frequency']==typ}
    current={x['Variable']:x for x in result if x['Frequency']==typ and x['Factor_Aggregation']=='comp' and x['LS_Definition']=='LS_DirectCompounded'}
    for name in ['alpha']+F:
        assert name in old and name in current
        assert abs(old[name]['Coefficient']-current[name]['Coefficient'])<1e-11, ('coefficient mismatch',typ,name,old[name]['Coefficient'],current[name]['Coefficient'])
        assert abs(old[name]['p_value']-current[name]['p_value'])<1e-9, ('p mismatch',typ,name,old[name]['p_value'],current[name]['p_value'])

lagrows=[]
for typ,rs in [('Weekly',rows_week),('Monthly',rows_month)]:
    for lag in ([0,1,3,5,10] if typ=='Weekly' else [0,1,2,3,6]):
        for dep in ['LS_SeparateLegs']:
            for factors in ['comp','sum','hybrid']:
                lagrows+=estimate(rs,dep,factors,lag,typ,method_label='HAC lag sensitivity')

# Factor consistency diagnostics and differential returns
def diagnostic(recs):
    z=np.array([r['Difference_SeparateMinusDirect'] for r in recs],dtype=float)
    return {'Frequency':recs[0]['Frequency'],'N':len(recs),
        'MeanDifference':float(np.mean(z)),'MeanAbsoluteDifference':float(np.mean(abs(z))),
        'MedianAbsoluteDifference':float(np.median(abs(z))),'MaxAbsoluteDifference':float(np.max(abs(z))),
        'ShareWithAbsDiffOver1bp':float(np.mean(abs(z)>0.0001)),
        'ShareWithAbsDiffOver10bp':float(np.mean(abs(z)>0.001)),
        'DifferenceSignedSum':float(np.sum(z)),
        'LS_DirectMean':float(np.mean([r['LS_DirectCompounded'] for r in recs])),
        'LS_SeparateMean':float(np.mean([r['LS_SeparateLegs'] for r in recs])),
        'MinDays':min(r['Daily_N'] for r in recs),'MaxDays':max(r['Daily_N'] for r in recs)}
diags=[diagnostic(rows_week),diagnostic(rows_month)]

# Per-month gross US risk-free consistency and approximation gap.
for r in rows_week+rows_month:
    r['LS_Difference_abs']=abs(r['Difference_SeparateMinusDirect'])
    r['R1_DailyFactorComp_vs_Sum_RMW']=r['F_comp_RMW']-r['F_sum_RMW']
    r['R1_DailyFactorComp_vs_Sum_HML']=r['F_comp_HML']-r['F_sum_HML']

rows_to_csv(HERE/'Weekly_Aligned.csv',rows_week)
rows_to_csv(HERE/'Monthly_Aligned.csv',rows_month)
rows_to_csv(HERE/'Frequency_Regressions.csv',result)
rows_to_csv(HERE/'HAC_Lag_Sensitivity.csv',lagrows)
rows_to_csv(HERE/'Frequency_Construction_Diagnostics.csv',diags)

summary={'source':'V2 FF5_Passenger_Data.xlsx / Model_Input; R1 output FF5_Passenger_Results.xlsx / Frequency_Robustness',
 'daily_n':len(raw),'date_first':str(raw[0]['Date']),'date_last':str(raw[-1]['Date']),
 'frequency_n':{'Weekly':len(rows_week),'Monthly':len(rows_month)},
 'verified_original_frequency_compounding':True,'construction_diagnostics':diags}
(HERE/'Audit_Summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')

print(json.dumps(summary,indent=2,ensure_ascii=False))
for typ in ['Weekly','Monthly']:
 print('\n##',typ)
 for aggregation in ['comp','sum','hybrid']:
  for dep in ['LS_DirectCompounded','LS_SeparateLegs']:
   res={r['Variable']:r for r in result if r['Frequency']==typ and r['Factor_Aggregation']==aggregation and r['LS_Definition']==dep}
   print(aggregation,dep, 'N',res['HML']['N'], 'HML',round(res['HML']['Coefficient'],5),'p',round(res['HML']['p_value'],5),'RMW',round(res['RMW']['Coefficient'],5),'p',round(res['RMW']['p_value'],5),'MKT',round(res['Mkt-RF']['Coefficient'],5),'MOM',round(res['MOM']['Coefficient'],5),'adjR2',round(res['MOM']['Adj_R2'],5))
