"""Official monthly FF5+MOM Developed check for JBEM R2 Comment 4.
Input: previously validated Monthly_Aligned.csv (V2, Comment4); raw French CSV ZIPs.
Output: monthly factor alignment and HAC(3) results.
Units: French raw monthly percentage points /100; LS raw simple fractions.
"""
from pathlib import Path
import csv, zipfile, io, json
import numpy as np
import statsmodels.api as sm
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'Output'/'C04'; OUT.mkdir(parents=True,exist_ok=True)
F5=ROOT/'Input'/'Factors'/'Developed_5_Factors_CSV (1).zip'; MOM=ROOT/'Input'/'Factors'/'Developed_Mom_Factor_CSV (1).zip'
SRC=ROOT/'Output'/'C04'/'Monthly_Aligned.csv'

def french(zip_path,ncols):
 with zipfile.ZipFile(zip_path) as z:
  name=[n for n in z.namelist() if n.lower().endswith('.csv')][0]
  data=z.read(name).decode('utf-8-sig')
 d={}
 for line in data.splitlines():
  parts=[p.strip() for p in line.split(',')]
  if len(parts)!=ncols+1:continue
  date=parts[0]
  if len(date)!=6 or not date.isdecimal(): continue
  month=date[:4]+'-'+date[4:]
  try: vals=[float(p)/100.0 for p in parts[1:]]
  except ValueError:continue
  if any(v < -.99 for v in vals):continue
  d[month]=vals
 return d

factor=french(F5,6);momentum=french(MOM,1)
header=['Mkt-RF','SMB','HML','RMW','CMA','RF','MOM']
merged=[]
with SRC.open(encoding='utf-8-sig',newline='') as f:
 for row in csv.DictReader(f):
  date=row['Period']
  if date not in factor or date not in momentum:
   raise RuntimeError('Missing published monthly factor for '+date)
  vals=factor[date]+momentum[date]
  r={'Period':date,'LS_DirectCompounded':float(row['LS_DirectCompounded']),'LS_SeparateLegs':float(row['LS_SeparateLegs']),**dict(zip(header,vals))}
  merged.append(r)
assert len(merged)==132 and merged[0]['Period']=='2015-01' and merged[-1]['Period']=='2025-12', (len(merged),merged[:1],merged[-1:])
X=np.asarray([[1]+[r[h] for h in ['Mkt-RF','SMB','HML','RMW','CMA','MOM']] for r in merged],float)
assert np.all(np.isfinite(X))
results=[]
for dependent in ['LS_DirectCompounded','LS_SeparateLegs']:
 Y=np.asarray([r[dependent] for r in merged],float)
 for lags in [0,1,2,3,6]:
  m=sm.OLS(Y,X).fit(cov_type='HAC',cov_kwds={'maxlags':lags,'use_correction':False})
  for idx,name in enumerate(['alpha','Mkt-RF','SMB','HML','RMW','CMA','MOM']):
   results.append({'LS_Definition':dependent,'Factor_Source':'Official Developed FF5 + Developed MOM monthly','HAC_Lags':lags,'Factor':name,'Coefficient':float(m.params[idx]),'HAC_SE':float(m.bse[idx]),'t':float(m.tvalues[idx]),'p_value':float(m.pvalues[idx]),'CI95_Lower':float(m.conf_int()[idx,0]),'CI95_Upper':float(m.conf_int()[idx,1]),'N':int(m.nobs),'R2':float(m.rsquared),'Adj_R2':float(m.rsquared_adj)})
with (OUT/'Monthly_Official_Factor_Aligned.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['Period','LS_DirectCompounded','LS_SeparateLegs']+header);w.writeheader();w.writerows(merged)
with (OUT/'Monthly_Official_Factor_Results.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
with (OUT/'Summary_HAC3.json').open('w',encoding='utf-8') as f:
 json.dump([r for r in results if r['HAC_Lags']==3],f,ensure_ascii=False,indent=2)
print('Official month data 2015-2025 complete:',len(merged))
for dep in ['LS_DirectCompounded','LS_SeparateLegs']:
 print('\n',dep)
 for r in results:
  if r['LS_Definition']==dep and r['HAC_Lags']==3:
   print(f" {r['Factor']:6s} beta {r['Coefficient']:+.5f}, t {r['t']:+.3f}, p={r['p_value']:.5g}, adjR2={r['Adj_R2']:.4f}")
print('monthly files created')
