from __future__ import annotations

from calendar import monthrange
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
from openpyxl import Workbook


BASE = Path(__file__).resolve().parents[2] / 'Input' / 'V2'
OUTPUT_DIR = Path(__file__).resolve().parents[2] / 'Output' / 'Base'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
PASSENGER_DATA = BASE / "FF5_Passenger_Data.xlsx"
MARKET_DATA = BASE / "FF5_Market_Data.xlsx"
UNIVERSE_DATA = BASE / "FF5_Universe_Definitions.xlsx"
OUTPUT = OUTPUT_DIR / "FF5_Portfolio_Robustness.xlsx"
FIGURE_PNG = OUTPUT_DIR / "Figure_Active_Constituents_2025.png"
FIGURE_PDF = OUTPUT_DIR / "Figure_Active_Constituents_2025.pdf"

CUTOFF = pd.Timestamp("2020-12-31")
HAC_LAGS = 22
FF3_FACTORS = ["Mkt-RF", "SMB", "HML"]
FF5_FACTORS = ["Mkt-RF", "SMB", "HML", "RMW", "CMA"]
FF5MOM_FACTORS = ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]


def load_clean_data():
    returns = pd.read_excel(PASSENGER_DATA, sheet_name="Daily_Returns")
    eligibility = pd.read_excel(PASSENGER_DATA, sheet_name="Monthly_Eligibility")
    portfolios = pd.read_excel(PASSENGER_DATA, sheet_name="Daily_Portfolios")
    model_input = pd.read_excel(PASSENGER_DATA, sheet_name="Model_Input")
    universe = pd.read_excel(UNIVERSE_DATA, sheet_name="Passenger_Universe")
    market_cap = pd.read_excel(MARKET_DATA, sheet_name="MarketCap_USD")

    returns["Date"] = pd.to_datetime(returns["Date"])
    eligibility["Month"] = pd.to_datetime(eligibility["Month"])
    eligibility["MarketCap_Date"] = pd.to_datetime(eligibility["MarketCap_Date"])
    portfolios["Date"] = pd.to_datetime(portfolios["Date"])
    model_input["Date"] = pd.to_datetime(model_input["Date"])
    market_cap["Date"] = pd.to_datetime(market_cap["Date"])
    for column in ["Economic_Start", "Economic_End", "Classification_Start", "Classification_End"]:
        universe[column] = pd.to_datetime(universe[column])
    return returns, eligibility, portfolios, model_input, universe, market_cap


def company_metadata(companies, universe):
    rows = []
    metadata = {}
    for company in companies:
        records = universe[universe["Company"] == company].copy()
        economic_start = records["Economic_Start"].dropna().iloc[0]
        economic_end = records["Economic_End"].dropna().iloc[0]
        ticker = records["Bloomberg_ID"].dropna().iloc[0]
        retained = economic_start <= CUTOFF
        classes = sorted(records["Binary_Class"].dropna().unique())
        metadata[company] = {
            "ticker": ticker,
            "economic_start": economic_start,
            "economic_end": economic_end,
            "records": records,
            "retained": retained,
        }
        rows.append({
            "Company": company,
            "Economic_Start": economic_start,
            "Economic_End": economic_end,
            "Class_or_Classes": " / ".join(classes),
            "Retained": bool(retained),
            "Cutoff": CUTOFF,
        })
    return metadata, rows


def classification_on_day(records, day):
    match = records[
        records["Classification_Start"].notna()
        & records["Classification_End"].notna()
        & (records["Classification_Start"] <= day)
        & (records["Classification_End"] >= day)
    ]
    return None if match.empty else match.iloc[0]["Binary_Class"]


def eligibility_lookup(eligibility):
    return {
        (row.Company, row.Month): bool(row.Pass_USD50m)
        for row in eligibility.itertuples(index=False)
    }


def monthly_active_membership(eligibility, metadata):
    eligible = eligibility_lookup(eligibility)
    rows = []
    for month in sorted(eligibility["Month"].drop_duplicates()):
        day = pd.Timestamp(month.year, month.month, monthrange(month.year, month.month)[1])
        ev = nonev = 0
        for company, meta in metadata.items():
            if not eligible.get((company, month), False):
                continue
            if not (meta["economic_start"] <= day <= meta["economic_end"]):
                continue
            classification = classification_on_day(meta["records"], day)
            if classification == "EV":
                ev += 1
            elif classification == "Non-EV":
                nonev += 1
        rows.append({"Date": day, "EV_Active_Constituents": ev,
                     "NonEV_Active_Constituents": nonev})
    return pd.DataFrame(rows)


def write_active_figure(active):
    figure, axis = plt.subplots(figsize=(8.2, 4.8))
    axis.plot(active["Date"], active["EV_Active_Constituents"], label="EV passenger",
              color="#1f4e79", linewidth=1.7)
    axis.plot(active["Date"], active["NonEV_Active_Constituents"], label="Non-EV",
              color="#7f7f7f", linewidth=1.7)
    axis.set_xlabel("Date")
    axis.set_ylabel("Number of active constituents")
    axis.set_xlim(active["Date"].min(), active["Date"].max())
    axis.legend(frameon=False)
    axis.grid(axis="y", color="#d9d9d9", linewidth=.6)
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)
    figure.tight_layout()


    plt.close(figure)


def build_restricted(returns, eligibility, metadata):
    eligible = eligibility_lookup(eligibility)
    records = []
    for _, row in returns.iterrows():
        day = row["Date"]
        month = pd.Timestamp(day.year, day.month, 1)
        ev, nonev = [], []
        for company, meta in metadata.items():
            if not meta["retained"] or not eligible[(company, month)]:
                continue
            value = row[company]
            classification = classification_on_day(meta["records"], day)
            if pd.isna(value) or classification is None:
                continue
            (ev if classification == "EV" else nonev).append(float(value))
        ev_return = float(np.mean(ev)) if ev else np.nan
        nonev_return = float(np.mean(nonev)) if nonev else np.nan
        records.append({
            "Date": day, "EV_Restricted": ev_return, "NonEV_Restricted": nonev_return,
            "LS_Restricted": ev_return - nonev_return,
            "EV_Restricted_N": len(ev), "NonEV_Restricted_N": len(nonev),
        })
    return pd.DataFrame(records).set_index("Date")


def build_lagged_market_cap(market_cap, metadata, dates):
    target = pd.DataFrame({"Date": dates}).sort_values("Date")
    output = pd.DataFrame(index=pd.DatetimeIndex(dates))
    for company, meta in metadata.items():
        source = market_cap[["Date", meta["ticker"]]].dropna().copy()
        source = source[np.isfinite(source[meta["ticker"]]) & (source[meta["ticker"]] > 0)]
        source = source[source["Date"].dt.weekday < 5]
        source.columns = ["MarketCap_Date", "MarketCap"]
        aligned = pd.merge_asof(
            target, source.sort_values("MarketCap_Date"), left_on="Date", right_on="MarketCap_Date",
            direction="backward", allow_exact_matches=False,
        )
        output[company] = aligned.set_index("Date")["MarketCap"].reindex(output.index)
    return output


def build_value_weighted(returns, eligibility, metadata, market_cap):
    eligible = eligibility_lookup(eligibility)
    dates = pd.DatetimeIndex(returns["Date"])
    lagged = build_lagged_market_cap(market_cap, metadata, dates)
    records = []
    for _, row in returns.iterrows():
        day = row["Date"]
        month = pd.Timestamp(day.year, day.month, 1)
        ev, nonev = [], []
        for company, meta in metadata.items():
            if not eligible[(company, month)]:
                continue
            value = row[company]
            classification = classification_on_day(meta["records"], day)
            weight = lagged.at[day, company]
            if pd.isna(value) or classification is None or pd.isna(weight) or weight <= 0:
                continue
            (ev if classification == "EV" else nonev).append((float(value), float(weight)))

        def weighted_average(pairs):
            if not pairs:
                return np.nan
            values_array = np.array([item[0] for item in pairs])
            weights_array = np.array([item[1] for item in pairs])
            return float(np.sum(values_array * weights_array) / np.sum(weights_array))

        ev_return, nonev_return = weighted_average(ev), weighted_average(nonev)
        records.append({
            "Date": day, "EV_VW": ev_return, "NonEV_VW": nonev_return,
            "LS_VW": ev_return - nonev_return, "EV_VW_N": len(ev), "NonEV_VW_N": len(nonev),
        })
    return pd.DataFrame(records).set_index("Date")


def factor_sets(model_input):
    frame = model_input.set_index("Date")
    ff3 = pd.DataFrame({
        "Mkt-RF": frame["FF3_Mkt_RF"], "SMB": frame["FF3_SMB"],
        "HML": frame["FF3_HML"], "RF": frame["FF3_RF"],
    })
    ff5 = pd.DataFrame({
        "Mkt-RF": frame["FF5_Mkt_RF"], "SMB": frame["FF5_SMB"],
        "HML": frame["FF5_HML"], "RMW": frame["RMW"], "CMA": frame["CMA"],
        "MOM": frame["MOM"], "RF": frame["FF5_RF"],
    })
    return ff3, ff5, ff5.copy()


def hac(y, factors):
    data = pd.concat([y.rename("Y"), factors], axis=1).dropna()
    exog = sm.add_constant(data[factors.columns], has_constant="add")
    return sm.OLS(data["Y"], exog).fit(cov_type="HAC", cov_kwds={"maxlags": HAC_LAGS})


def regress_three_models(ev, nonev, factors, specification):
    rows = []
    ls = ev - nonev
    for model_name, factor_frame, names in [
        ("FF3", factors[0], FF3_FACTORS),
        ("FF5", factors[1], FF5_FACTORS),
        ("FF5+MOM", factors[2], FF5MOM_FACTORS),
    ]:
        for portfolio, dependent, excess in [
            ("EV", ev, True), ("Non-EV", nonev, True), ("LS", ls, False),
        ]:
            y = dependent - factor_frame["RF"] if excess else dependent
            model = hac(y, factor_frame[names])
            interval = model.conf_int()
            for name in model.params.index:
                rows.append({
                    "Specification": specification, "Portfolio": portfolio, "Model": model_name,
                    "Variable": "alpha" if name == "const" else name,
                    "Coefficient": float(model.params[name]), "HAC_SE": float(model.bse[name]),
                    "HAC_t": float(model.tvalues[name]), "p_value": float(model.pvalues[name]),
                    "CI95_Lower": float(interval.loc[name, 0]), "CI95_Upper": float(interval.loc[name, 1]),
                    "N": int(model.nobs), "R2": float(model.rsquared),
                    "Adj_R2": float(model.rsquared_adj), "HAC_Lags": HAC_LAGS,
                })
    return rows


def write_sheet(workbook, name, frame):
    sheet = workbook.create_sheet(name)
    sheet.append(list(frame.columns))
    for row in frame.itertuples(index=False, name=None):
        sheet.append(list(row))
    sheet.freeze_panes = "A2"
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, pd.Timestamp):
                cell.value = cell.value.to_pydatetime()
            if hasattr(cell.value, "year") and hasattr(cell.value, "month"):
                cell.number_format = "yyyy-mm-dd"


def main():
    returns, eligibility, portfolios, model_input, universe, market_cap = load_clean_data()
    companies = [column for column in returns.columns if column != "Date"]
    metadata, restriction_rows = company_metadata(companies, universe)
    restricted = build_restricted(returns, eligibility, metadata)
    value_weighted = build_value_weighted(returns, eligibility, metadata, market_cap)

    baseline = portfolios.set_index("Date").rename(columns={
        "EV_Return": "EV_EW", "NonEV_Return": "NonEV_EW", "LS_Return": "LS_EW",
        "EV_Constituents": "EV_N", "NonEV_Constituents": "NonEV_N",
    })
    daily = baseline.join(restricted).join(value_weighted)
    active = monthly_active_membership(eligibility, metadata)
    daily = daily.reset_index()

    factors = factor_sets(model_input)
    baseline_models = regress_three_models(
        baseline["EV_EW"], baseline["NonEV_EW"], factors, "Passenger EW baseline")
    restricted_models = regress_three_models(
        restricted["EV_Restricted"], restricted["NonEV_Restricted"], factors,
        "Passenger EW — exclude Economic_Start after 2020-12-31")
    value_models = regress_three_models(
        value_weighted["EV_VW"], value_weighted["NonEV_VW"], factors,
        "Passenger VW baseline — strict lagged USD market cap")
    models = pd.DataFrame(baseline_models + restricted_models + value_models)

    assert len(companies) == 50
    assert len(active) == 132
    assert active["Date"].min() == pd.Timestamp("2015-01-31")
    assert active["Date"].max() == pd.Timestamp("2025-12-31")

    workbook = Workbook()
    workbook.remove(workbook.active)
    write_sheet(workbook, "Active_Constituents", active)
    write_sheet(workbook, "Universe_Restriction", pd.DataFrame(restriction_rows))
    write_sheet(workbook, "Daily_Robustness", daily)
    write_sheet(workbook, "Robustness_Models", models)
    workbook.save(OUTPUT)
    write_active_figure(active)
    print(OUTPUT.name)


if __name__ == "__main__":
    main()
