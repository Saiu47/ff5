from __future__ import annotations

import math
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

from openpyxl import Workbook, load_workbook

BASE = Path(__file__).resolve().parents[2] / 'Input' / 'V2'
OUTPUT_DIR = Path(__file__).resolve().parents[2] / 'Output' / 'Base'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
MARKET_DATA = BASE / "FF5_Market_Data.xlsx"
UNIVERSE_DATA = BASE / "FF5_Universe_Definitions.xlsx"
FACTOR_DATA = BASE / "FF5_Factor_Data.xlsx"
OUTPUT = OUTPUT_DIR / "FF5_Broad_Data.xlsx"

SAMPLE_START = date(2015, 1, 1)
SAMPLE_END = date(2025, 12, 31)
LONG_GAP_WEEKDAYS = 40
MCAP_THRESHOLD_USD_MN = 50.0

def read_sheet(path, sheet_name):
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        return [list(row) for row in workbook[sheet_name].iter_rows(values_only=True)]
    finally:
        workbook.close()


def parse_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)):
        return date(1899, 12, 30) + timedelta(days=int(value))

    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(text[:10], fmt).date()
        except ValueError:
            pass
    return None


def positive_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number > 0 else None


def weekday_calendar(start, end):
    days = []
    current = start
    while current <= end:
        if current.weekday() < 5:
            days.append(current)
        current += timedelta(days=1)
    return days


def missing_weekdays_between(left, right):
    count = 0
    current = left + timedelta(days=1)
    while current < right:
        if current.weekday() < 5:
            count += 1
        current += timedelta(days=1)
    return count


def month_start(day):
    return date(day.year, day.month, 1)


def next_month(month):
    return date(month.year + 1, 1, 1) if month.month == 12 else date(month.year, month.month + 1, 1)


def previous_month(month):
    return date(month.year - 1, 12, 1) if month.month == 1 else date(month.year, month.month - 1, 1)


def month_end(month):
    return next_month(month) - timedelta(days=1)


def monthly_calendar(start, end):
    months = []
    current = date(start.year, start.month, 1)
    last = date(end.year, end.month, 1)
    while current <= last:
        months.append(current)
        current = next_month(current)
    return months


def read_market_sheet(sheet_name):
    rows = read_sheet(MARKET_DATA, sheet_name)
    tickers = [str(value) for value in rows[0][1:]]
    series = {ticker: {} for ticker in tickers}

    for row in rows[1:]:
        day = parse_date(row[0] if row else None)
        if day is None:
            continue

        for index, ticker in enumerate(tickers, start=1):
            if index >= len(row):
                continue
            value = positive_number(row[index])
            if value is not None:
                series[ticker][day] = value

    return series


def read_universe():
    rows = read_sheet(UNIVERSE_DATA, "Broad_Universe")
    positions = {str(value): index for index, value in enumerate(rows[0])}
    order = []
    windows = defaultdict(list)

    for row in rows[1:]:
        if not row or row[0] in (None, ""):
            continue

        company = str(row[positions["Company"]])
        if company not in order:
            order.append(company)

        windows[company].append(
            {
                "Bloomberg_ID": row[positions["Bloomberg_ID"]],
                "Economic_Start": parse_date(row[positions["Economic_Start"]]),
                "Economic_End": parse_date(row[positions["Economic_End"]]),
                "Classification_Start": parse_date(row[positions["Classification_Start"]]),
                "Classification_End": parse_date(row[positions["Classification_End"]]),
                "Binary_Class": row[positions["Binary_Class"]],
            }
        )

    return order, windows


def read_factors():
    rows = read_sheet(FACTOR_DATA, "Daily_Factors")
    header = [str(value) for value in rows[0]]
    positions = {name: index for index, name in enumerate(header)}
    factors = {}

    for row in rows[1:]:
        day = parse_date(row[positions["Date"]])
        if day is None:
            continue

        factors[day] = {
            name: float(row[index])
            for name, index in positions.items()
            if name != "Date" and index < len(row) and row[index] is not None
        }

    return factors


def build_data():
    prices = read_market_sheet("Prices_USD")
    market_cap = read_market_sheet("MarketCap_USD")
    factors = read_factors()
    company_order, windows = read_universe()

    company_ticker = {}
    company_window = {}
    pre_price_exclusions = []

    for company in company_order:
        rows = windows[company]
        tickers = [row["Bloomberg_ID"] for row in rows if row["Bloomberg_ID"] not in (None, "")]
        ticker = str(tickers[0]) if tickers else None
        company_ticker[company] = ticker

        economic_windows = {
            (row["Economic_Start"], row["Economic_End"])
            for row in rows
            if row["Economic_Start"] is not None and row["Economic_End"] is not None
        }

        if ticker is None or ticker not in prices or not prices[ticker] or len(economic_windows) != 1:
            pre_price_exclusions.append(company)
            continue

        company_window[company] = next(iter(economic_windows))

    candidates = [company for company in company_order if company not in pre_price_exclusions]
    gap_exclusions = []

    for company in candidates:
        economic_start, economic_end = company_window[company]
        ticker = company_ticker[company]
        valid_dates = sorted(
            day
            for day, value in prices[ticker].items()
            if economic_start <= day <= economic_end and value > 0
        )

        maximum_gap = 0
        for left, right in zip(valid_dates[:-1], valid_dates[1:]):
            maximum_gap = max(maximum_gap, missing_weekdays_between(left, right))

        if maximum_gap >= LONG_GAP_WEEKDAYS:
            gap_exclusions.append(company)

    included = [company for company in candidates if company not in gap_exclusions]
    calendar = weekday_calendar(SAMPLE_START, SAMPLE_END)
    daily_returns = {}
    daily_classification = {}

    for company in included:
        economic_start, economic_end = company_window[company]
        ticker = company_ticker[company]
        raw_prices = {
            day: value
            for day, value in prices[ticker].items()
            if economic_start <= day <= economic_end and value > 0
        }
        valid_dates = sorted(raw_prices)
        returns = {day: None for day in calendar}
        classifications = {day: None for day in calendar}

        if valid_dates:
            first_valid = valid_dates[0]
            last_valid = valid_dates[-1]
            observed_returns = {
                day: raw_prices[day] / raw_prices[previous_day] - 1.0
                for previous_day, day in zip(valid_dates, valid_dates[1:])
            }

            for day in calendar:
                if day < first_valid or day > last_valid:
                    continue

                if day in observed_returns:
                    returns[day] = observed_returns[day]

                for window in windows[company]:
                    if (
                        window["Classification_Start"] is not None
                        and window["Classification_End"] is not None
                        and window["Classification_Start"] <= day <= window["Classification_End"]
                    ):
                        classifications[day] = window["Binary_Class"]
                        break

        daily_returns[company] = returns
        daily_classification[company] = classifications

    months = monthly_calendar(SAMPLE_START, SAMPLE_END)
    eligibility = {}
    eligibility_rows = []

    for company in included:
        economic_start, economic_end = company_window[company]
        ticker = company_ticker[company]

        for month in months:
            end = min(month_end(month), SAMPLE_END)
            active = any(
                month <= day <= end
                and economic_start <= day <= economic_end
                and daily_classification[company][day] is not None
                for day in calendar
            )

            formation_date = None
            formation_value = None

            if active:
                if month == date(2015, 1, 1):
                    observations = sorted(
                        (day, value)
                        for day, value in market_cap[ticker].items()
                        if day.weekday() < 5
                        and month <= day <= month_end(month)
                        and economic_start <= day <= economic_end
                        and value > 0
                    )
                    if observations:
                        formation_date, formation_value = observations[0]
                else:
                    prior = previous_month(month)
                    observations = sorted(
                        (day, value)
                        for day, value in market_cap[ticker].items()
                        if day.weekday() < 5
                        and prior <= day <= month_end(prior)
                        and economic_start <= day <= economic_end
                        and value > 0
                    )
                    if observations:
                        formation_date, formation_value = observations[-1]

            passes = active and formation_value is not None and formation_value >= MCAP_THRESHOLD_USD_MN
            eligibility[(company, month)] = passes
            eligibility_rows.append(
                [
                    datetime(month.year, month.month, month.day),
                    company,
                    ticker,
                    datetime(formation_date.year, formation_date.month, formation_date.day) if formation_date else None,
                    formation_value,
                    passes,
                ]
            )

    daily_return_rows = [
        [datetime(day.year, day.month, day.day)] + [daily_returns[company][day] for company in included]
        for day in calendar
    ]

    portfolio_rows = []
    portfolio_by_date = {}

    for day in calendar:
        month = month_start(day)
        ev_returns = []
        nonev_returns = []

        for company in included:
            if not eligibility[(company, month)]:
                continue

            value = daily_returns[company][day]
            classification = daily_classification[company][day]

            if value is None or classification is None:
                continue

            if classification == "EV":
                ev_returns.append(value)
            elif classification == "Non-EV":
                nonev_returns.append(value)

        ev_return = sum(ev_returns) / len(ev_returns) if ev_returns else None
        nonev_return = sum(nonev_returns) / len(nonev_returns) if nonev_returns else None
        ls_return = ev_return - nonev_return if ev_return is not None and nonev_return is not None else None

        portfolio_by_date[day] = {
            "EV_Return": ev_return,
            "NonEV_Return": nonev_return,
            "LS_Return": ls_return,
            "EV_Constituents": len(ev_returns),
            "NonEV_Constituents": len(nonev_returns),
        }

        portfolio_rows.append(
            [
                datetime(day.year, day.month, day.day),
                ev_return,
                nonev_return,
                ls_return,
                len(ev_returns),
                len(nonev_returns),
            ]
        )

    required_factors = [
        "FF3_Mkt_RF",
        "FF3_SMB",
        "FF3_HML",
        "FF3_RF",
        "FF5_Mkt_RF",
        "FF5_SMB",
        "FF5_HML",
        "RMW",
        "CMA",
        "MOM",
        "FF5_RF",
    ]

    model_rows = []

    for day in sorted(set(portfolio_by_date) & set(factors)):
        portfolio = portfolio_by_date[day]
        factor = factors[day]

        if portfolio["EV_Return"] is None or portfolio["NonEV_Return"] is None:
            continue
        if any(name not in factor for name in required_factors):
            continue

        model_rows.append(
            [
                datetime(day.year, day.month, day.day),
                portfolio["EV_Return"],
                portfolio["NonEV_Return"],
                portfolio["LS_Return"],
                portfolio["EV_Return"] - factor["FF3_RF"],
                portfolio["NonEV_Return"] - factor["FF3_RF"],
                portfolio["EV_Return"] - factor["FF5_RF"],
                portfolio["NonEV_Return"] - factor["FF5_RF"],
                portfolio["EV_Constituents"],
                portfolio["NonEV_Constituents"],
                factor["FF3_Mkt_RF"],
                factor["FF3_SMB"],
                factor["FF3_HML"],
                factor["FF3_RF"],
                factor["FF5_Mkt_RF"],
                factor["FF5_SMB"],
                factor["FF5_HML"],
                factor["RMW"],
                factor["CMA"],
                factor["MOM"],
                factor["FF5_RF"],
            ]
        )

    return {
        "company_order": company_order,
        "pre_price_exclusions": pre_price_exclusions,
        "gap_exclusions": gap_exclusions,
        "included": included,
        "daily_return_rows": daily_return_rows,
        "eligibility_rows": eligibility_rows,
        "portfolio_rows": portfolio_rows,
        "model_rows": model_rows,
    }


def write_workbook(result):
    returns_headers = ["Date"] + result["included"]
    eligibility_headers = [
        "Month",
        "Company",
        "Bloomberg_ID",
        "MarketCap_Date",
        "MarketCap_USD_mn",
        "Pass_USD50m",
    ]
    portfolio_headers = [
        "Date",
        "EV_Return",
        "NonEV_Return",
        "LS_Return",
        "EV_Constituents",
        "NonEV_Constituents",
    ]
    model_headers = [
        "Date",
        "EV_Return",
        "NonEV_Return",
        "LS_Return",
        "EV_Excess_FF3",
        "NonEV_Excess_FF3",
        "EV_Excess_FF5",
        "NonEV_Excess_FF5",
        "EV_Constituents",
        "NonEV_Constituents",
        "FF3_Mkt_RF",
        "FF3_SMB",
        "FF3_HML",
        "FF3_RF",
        "FF5_Mkt_RF",
        "FF5_SMB",
        "FF5_HML",
        "RMW",
        "CMA",
        "MOM",
        "FF5_RF",
    ]

    workbook = Workbook()
    workbook.remove(workbook.active)
    sheets = [
        ("Daily_Returns", returns_headers, result["daily_return_rows"]),
        ("Monthly_Eligibility", eligibility_headers, result["eligibility_rows"]),
        ("Daily_Portfolios", portfolio_headers, result["portfolio_rows"]),
        ("Model_Input", model_headers, result["model_rows"]),
    ]
    for name, headers, rows in sheets:
        sheet = workbook.create_sheet(name)
        sheet.append(headers)
        for row in rows:
            sheet.append(row)
        sheet.freeze_panes = "A2"
        if name == "Monthly_Eligibility":
            for cell in sheet["A"][1:]:
                cell.number_format = "yyyy-mm"
            for cell in sheet["D"][1:]:
                cell.number_format = "yyyy-mm-dd"
        else:
            for cell in sheet["A"][1:]:
                cell.number_format = "yyyy-mm-dd"
    workbook.save(OUTPUT)


def validate(result):
    assert len(result["company_order"]) == 151
    assert result["pre_price_exclusions"] == []
    assert set(result["gap_exclusions"]) == {
        "KG Mobility",
        "Wardwizard Innovations & Mobility",
    }
    assert len(result["included"]) == 149
    assert result["daily_return_rows"][0][0].date() == SAMPLE_START
    assert result["daily_return_rows"][-1][0].date() == SAMPLE_END
    assert result["eligibility_rows"][-1][0].date() == date(2025, 12, 1)
    assert result["model_rows"][0][0].date() == date(2015, 1, 5)
    assert result["model_rows"][-1][0].date() == SAMPLE_END


if __name__ == "__main__":
    data = build_data()
    validate(data)
    write_workbook(data)
    print(OUTPUT.name)
