from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from openpyxl import Workbook
from scipy import stats
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tsa.stattools import adfuller


BASE = Path(__file__).resolve().parents[2] / 'Input' / 'V2'
OUTPUT_DIR = Path(__file__).resolve().parents[2] / 'Output' / 'Base'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
DATASETS = {
    "Passenger": (BASE / "FF5_Passenger_Data.xlsx", OUTPUT_DIR / "FF5_Passenger_Results.xlsx"),
    "Broad": (BASE / "FF5_Broad_Data.xlsx", OUTPUT_DIR / "FF5_Broad_Results.xlsx"),
}
DAILY_HAC_LAGS = 22
BREAKPOINTS = [pd.Timestamp("2020-03-11"), pd.Timestamp("2023-05-06")]
FF3_FACTORS = ["Mkt-RF", "SMB", "HML"]
FF5_FACTORS = ["Mkt-RF", "SMB", "HML", "RMW", "CMA"]
FF5MOM_FACTORS = ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]


def load_inputs(path):
    source = pd.read_excel(path, sheet_name="Model_Input")
    source["Date"] = pd.to_datetime(source["Date"])
    source = source.set_index("Date").sort_index()
    common = {
        "EV Return": source["EV_Return"],
        "Non-EV Return": source["NonEV_Return"],
        "Delta EV-NonEV": source["LS_Return"],
    }
    ff3 = pd.DataFrame({
        **common,
        "EV Excess Return": source["EV_Excess_FF3"],
        "Non-EV Excess Return": source["NonEV_Excess_FF3"],
        "Mkt-RF": source["FF3_Mkt_RF"], "SMB": source["FF3_SMB"],
        "HML": source["FF3_HML"], "RF": source["FF3_RF"],
    })
    ff5 = pd.DataFrame({
        **common,
        "EV Excess Return": source["EV_Excess_FF5"],
        "Non-EV Excess Return": source["NonEV_Excess_FF5"],
        "Mkt-RF": source["FF5_Mkt_RF"], "SMB": source["FF5_SMB"],
        "HML": source["FF5_HML"], "RMW": source["RMW"],
        "CMA": source["CMA"], "MOM": source["MOM"], "RF": source["FF5_RF"],
    })
    return ff3, ff5, ff5.copy()


def hac_model(y, x, maxlags=DAILY_HAC_LAGS):
    data = pd.concat([y.rename("Y"), x], axis=1).dropna()
    exog = sm.add_constant(data[x.columns], has_constant="add")
    return sm.OLS(data["Y"], exog).fit(cov_type="HAC", cov_kwds={"maxlags": maxlags}), data


def coefficient_rows(model, portfolio, specification, maxlags, frequency="Daily", sample="Full sample"):
    ci = model.conf_int()
    rows = []
    for name in model.params.index:
        rows.append({
            "Record_Type": "Coefficient", "Portfolio": portfolio, "Model": specification,
            "Frequency": frequency, "Sample": sample, "HAC_Lags": maxlags,
            "Variable": "alpha" if name == "const" else name,
            "Coefficient": float(model.params[name]), "HAC_SE": float(model.bse[name]),
            "HAC_t": float(model.tvalues[name]), "p_value": float(model.pvalues[name]),
            "CI95_Lower": float(ci.loc[name, 0]), "CI95_Upper": float(ci.loc[name, 1]),
            "N": int(model.nobs), "R2": float(model.rsquared), "Adj_R2": float(model.rsquared_adj),
        })
    return rows


def model_fit_row(model, portfolio, specification, maxlags, frequency="Daily", sample="Full sample"):
    return {
        "Record_Type": "Model_Fit", "Portfolio": portfolio, "Model": specification,
        "Frequency": frequency, "Sample": sample, "HAC_Lags": maxlags,
        "N": int(model.nobs), "R2": float(model.rsquared), "Adj_R2": float(model.rsquared_adj),
        "F_stat_HAC": float(model.fvalue), "F_p_value_HAC": float(model.f_pvalue),
        "AIC": float(model.aic), "BIC": float(model.bic),
        "Durbin_Watson": float(durbin_watson(model.resid)),
    }


def residual_diagnostics(model, portfolio, specification):
    resid = pd.Series(model.resid).dropna()
    jb_stat, jb_p, skew, kurt = jarque_bera(resid)
    rows = [{"Diagnostic": "Jarque-Bera", "Portfolio": portfolio, "Model": specification,
             "Lag": None, "Statistic": float(jb_stat), "p_value": float(jb_p),
             "Extra_1": float(skew), "Extra_2": float(kurt)}]
    rows.append({"Diagnostic": "Durbin-Watson", "Portfolio": portfolio, "Model": specification,
                 "Lag": None, "Statistic": float(durbin_watson(resid)), "p_value": None,
                 "Extra_1": None, "Extra_2": None})
    for lag in [5, 10, 22]:
        lb = acorr_ljungbox(resid, lags=[lag], return_df=True)
        rows.append({"Diagnostic": "Ljung-Box", "Portfolio": portfolio, "Model": specification,
                     "Lag": lag, "Statistic": float(lb.loc[lag, "lb_stat"]),
                     "p_value": float(lb.loc[lag, "lb_pvalue"]), "Extra_1": None, "Extra_2": None})
        arch_stat, arch_p, _, _ = het_arch(resid, nlags=lag)
        rows.append({"Diagnostic": "ARCH LM", "Portfolio": portfolio, "Model": specification,
                     "Lag": lag, "Statistic": float(arch_stat), "p_value": float(arch_p),
                     "Extra_1": None, "Extra_2": None})
    return rows


def run_baseline(ff3, ff5, ff5mom):
    specs = [("FF3", ff3, FF3_FACTORS), ("FF5", ff5, FF5_FACTORS),
             ("FF5+MOM", ff5mom, FF5MOM_FACTORS)]
    main, diagnostics = [], []
    for model_name, frame, factors in specs:
        for portfolio, dependent in [("EV", "EV Excess Return"),
                                     ("Non-EV", "Non-EV Excess Return"),
                                     ("LS", "Delta EV-NonEV")]:
            model, _ = hac_model(frame[dependent], frame[factors])
            main.extend(coefficient_rows(model, portfolio, model_name, DAILY_HAC_LAGS))
            main.append(model_fit_row(model, portfolio, model_name, DAILY_HAC_LAGS))
            diagnostics.extend(residual_diagnostics(model, portfolio, model_name))
            alpha = float(model.params["const"])
            main.append({
                "Record_Type": "Annualized_Alpha", "Portfolio": portfolio, "Model": model_name,
                "Daily_Alpha": alpha, "Annualized_Alpha_Arithmetic": alpha * 252.0,
                "Annualized_Alpha_Exact": (1.0 + alpha) ** 252.0 - 1.0,
                "Alpha_p_value_HAC": float(model.pvalues["const"]),
            })
    return main, diagnostics


def descriptive_stats(frame):
    columns = ["EV Return", "Non-EV Return", "Delta EV-NonEV", "EV Excess Return",
               "Non-EV Excess Return", *FF5MOM_FACTORS, "RF"]
    rows = []
    for column in columns:
        series = frame[column].dropna()
        rows.append({
            "Dataset": "Full aligned daily sample", "Variable": column, "N": int(series.size),
            "Mean": float(series.mean()), "Std": float(series.std(ddof=1)),
            "Min": float(series.min()), "P25": float(series.quantile(.25)),
            "Median": float(series.median()), "P75": float(series.quantile(.75)),
            "Max": float(series.max()), "Skew": float(series.skew()),
            "Kurtosis_Excess": float(series.kurt()),
        })
    return rows


def diagnostic_tables(ff3, ff5, ff5mom, residual_rows):
    rows = list(residual_rows)
    for frame, name, factors in [(ff3, "FF3", FF3_FACTORS), (ff5, "FF5", FF5_FACTORS),
                                 (ff5mom, "FF5+MOM", FF5MOM_FACTORS)]:
        exog = sm.add_constant(frame[factors].dropna(), has_constant="add")
        for index, variable in enumerate(exog.columns):
            if variable != "const":
                rows.append({"Diagnostic": "VIF", "Model": name, "Variable": variable,
                             "Statistic": float(variance_inflation_factor(exog.values, index))})
    variables = ["EV Return", "Non-EV Return", "Delta EV-NonEV", "EV Excess Return",
                 "Non-EV Excess Return", *FF5MOM_FACTORS, "RF"]
    for variable in variables:
        stat, p, usedlag, nobs, crit, _ = adfuller(ff5mom[variable].dropna(), autolag="AIC")
        rows.append({"Diagnostic": "ADF", "Variable": variable, "Statistic": float(stat),
                     "p_value": float(p), "Lag": int(usedlag), "N": int(nobs),
                     "Extra_1": float(crit["1%"]), "Extra_2": float(crit["5%"]),
                     "Extra_3": float(crit["10%"])})
    corr = ff5mom[variables].corr()
    for left in variables:
        for right in variables:
            rows.append({"Diagnostic": "Correlation", "Variable": left,
                         "Variable_2": right, "Statistic": float(corr.loc[left, right])})
    return rows


def chow_test(data, breakpoint):
    before, after = data[data.index < breakpoint], data[data.index >= breakpoint]
    def ols(frame):
        return sm.OLS(frame["LS"], sm.add_constant(frame[FF5MOM_FACTORS], has_constant="add")).fit()
    full_model, before_model, after_model = ols(data), ols(before), ols(after)
    rssf = float((full_model.resid ** 2).sum())
    rssb = float((before_model.resid ** 2).sum())
    rssa = float((after_model.resid ** 2).sum())
    k, nb, na = len(FF5MOM_FACTORS) + 1, len(before), len(after)
    statistic = ((rssf - rssb - rssa) / k) / ((rssb + rssa) / (nb + na - 2 * k))
    return {"Breakpoint": breakpoint.to_pydatetime(), "F_stat": statistic,
            "p_value": float(stats.f.sf(statistic, k, nb + na - 2 * k)),
            "N_before": nb, "N_after": na, "Restrictions_k": k}


def regime_and_break_results(ff5mom):
    data = ff5mom[["Delta EV-NonEV", *FF5MOM_FACTORS]].rename(columns={"Delta EV-NonEV": "LS"}).dropna()
    periods = [("Pre-COVID", pd.Timestamp("2015-01-05"), pd.Timestamp("2020-03-10")),
               ("COVID", pd.Timestamp("2020-03-11"), pd.Timestamp("2023-05-05")),
               ("Post-COVID", pd.Timestamp("2023-05-06"), ff5mom.index.max())]
    regimes = []
    for label, start, end in periods:
        model, _ = hac_model(data.loc[start:end, "LS"], data.loc[start:end, FF5MOM_FACTORS])
        block = coefficient_rows(model, "LS", "FF5+MOM", DAILY_HAC_LAGS, sample=label)
        for row in block:
            row.update({"Start": start.to_pydatetime(), "End": end.to_pydatetime()})
        regimes.extend(block)
    return regimes, [chow_test(data, point) for point in BREAKPOINTS]


def rolling_results(ff5mom, window):
    data = ff5mom[["Delta EV-NonEV", *FF5MOM_FACTORS]].rename(columns={"Delta EV-NonEV": "LS"}).dropna()
    rows = []
    for end in range(window - 1, len(data)):
        sample = data.iloc[end - window + 1:end + 1]
        model = sm.OLS(sample["LS"], sm.add_constant(sample[FF5MOM_FACTORS], has_constant="add")).fit(
            cov_type="HAC", cov_kwds={"maxlags": DAILY_HAC_LAGS})
        ci = model.conf_int()
        for name in model.params.index:
            variable = "alpha" if name == "const" else name
            rows.append({"Record_Type": "Estimate", "Date": sample.index[-1].to_pydatetime(),
                         "Window": window, "Portfolio": "LS", "Model": "FF5+MOM",
                         "Variable": variable, "Coefficient": float(model.params[name]),
                         "HAC_SE": float(model.bse[name]), "p_value": float(model.pvalues[name]),
                         "CI95_Lower": float(ci.loc[name, 0]), "CI95_Upper": float(ci.loc[name, 1])})
    result = pd.DataFrame(rows)
    summaries = []
    for variable in ["alpha", *FF5MOM_FACTORS]:
        subset = result[result.Variable == variable]
        summaries.append({
            "Record_Type": "Summary", "Window": window, "Variable": variable,
            "Mean_Coefficient": subset.Coefficient.mean(), "Median_Coefficient": subset.Coefficient.median(),
            "Min_Coefficient": subset.Coefficient.min(), "Max_Coefficient": subset.Coefficient.max(),
            "Share_p_lt_10pct": (subset.p_value < .10).mean(),
            "Share_p_lt_5pct": (subset.p_value < .05).mean(),
            "Share_p_lt_1pct": (subset.p_value < .01).mean(),
            "First_Date": subset.Date.iloc[0], "Last_Date": subset.Date.iloc[-1],
            "N_Windows": len(subset),
        })
    return rows + summaries


def compound(series):
    return (1.0 + series.dropna()).prod() - 1.0 if series.notna().any() else np.nan


def frequency_results(ff5mom):
    daily = ff5mom[["Delta EV-NonEV", *FF5MOM_FACTORS]].rename(columns={"Delta EV-NonEV": "LS"}).dropna()
    rows = []
    for frequency, rule, lags in [("Weekly", "W-FRI", 5), ("Monthly", "ME", 3)]:
        data = pd.concat([daily["LS"].resample(rule).apply(compound).rename("LS"),
                          daily[FF5MOM_FACTORS].resample(rule).agg(compound)], axis=1).dropna()
        model, _ = hac_model(data.LS, data[FF5MOM_FACTORS], lags)
        rows.extend(coefficient_rows(model, "LS", "FF5+MOM", lags, frequency=frequency))
        rows.append(model_fit_row(model, "LS", "FF5+MOM", lags, frequency=frequency))
    return rows


def hac_sensitivity(ff5mom):
    rows = []
    for lag in [5, 10, 22, 44]:
        model, _ = hac_model(ff5mom["Delta EV-NonEV"], ff5mom[FF5MOM_FACTORS], lag)
        rows.extend(coefficient_rows(model, "LS", "FF5+MOM", lag, sample="HAC bandwidth sensitivity"))
    return rows


def add_contributions(main, ff5mom):
    coefficients = {r["Variable"]: r["Coefficient"] for r in main
                    if r.get("Record_Type") == "Coefficient" and r.get("Portfolio") == "LS"
                    and r.get("Model") == "FF5+MOM"}
    for factor in FF5MOM_FACTORS:
        mean = float(ff5mom[factor].mean())
        contribution = coefficients[factor] * mean
        main.append({"Record_Type": "Factor_Contribution", "Portfolio": "LS", "Model": "FF5+MOM",
                     "Variable": factor, "Coefficient": coefficients[factor],
                     "Mean_Daily_Factor_Return": mean, "Daily_Average_Contribution": contribution,
                     "Annualized_Sample_Average_Contribution": contribution * 252.0})


def validate_signs(main):
    bad = []
    for row in main:
        if row.get("Record_Type") == "Coefficient":
            coefficient, statistic = row["Coefficient"], row["HAC_t"]
            if coefficient != 0 and statistic != 0 and np.sign(coefficient) != np.sign(statistic):
                bad.append((row["Portfolio"], row["Model"], row["Variable"]))
    if bad:
        raise ValueError(f"Coefficient/t-statistic sign mismatch: {bad}")


def write_sheet(workbook, name, records):
    sheet = workbook.create_sheet(name)
    columns = []
    for record in records:
        for key in record:
            if key not in columns:
                columns.append(key)
    sheet.append(columns)
    for record in records:
        sheet.append([record.get(column) for column in columns])
    sheet.freeze_panes = "A2"
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, (pd.Timestamp,)):
                cell.value = cell.value.to_pydatetime()
            if hasattr(cell.value, "year") and hasattr(cell.value, "month"):
                cell.number_format = "yyyy-mm-dd"


def run_dataset(input_path, output_path):
    ff3, ff5, ff5mom = load_inputs(input_path)
    main, residual = run_baseline(ff3, ff5, ff5mom)
    add_contributions(main, ff5mom)
    validate_signs(main)
    regimes, breaks = regime_and_break_results(ff5mom)
    outputs = {
        "Main_Models": main,
        "Descriptives": descriptive_stats(ff5mom),
        "Diagnostics": diagnostic_tables(ff3, ff5, ff5mom, residual),
        "Break_Tests": breaks,
        "Regime_Models": regimes,
        "Rolling_Models": rolling_results(ff5mom, 252) + rolling_results(ff5mom, 504),
        "Frequency_Robustness": frequency_results(ff5mom),
        "HAC_Sensitivity": hac_sensitivity(ff5mom),
    }
    workbook = Workbook()
    workbook.remove(workbook.active)
    for name, records in outputs.items():
        write_sheet(workbook, name, records)
    workbook.save(output_path)
    return outputs


def main():
    for _, (input_path, output_path) in DATASETS.items():
        run_dataset(input_path, output_path)
        print(output_path.name)


if __name__ == "__main__":
    main()
