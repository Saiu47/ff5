from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from openpyxl import Workbook
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests


BASE = Path(__file__).resolve().parents[2] / 'Input' / 'V2'
OUTPUT_DIR = Path(__file__).resolve().parents[2] / 'Output' / 'Base'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
PASSENGER_FILE = BASE / "FF5_Passenger_Data.xlsx"
STATE_FILE = BASE / "FF5_State_Data.xlsx"
OUTPUT_FILE = OUTPUT_DIR / "FF5_State_Dependent_Models.xlsx"
START_DATE = pd.Timestamp("2015-01-05")
END_DATE = pd.Timestamp("2025-12-31")
HAC_LAGS = 22
FACTORS = ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]


def load_inputs():
    passenger = pd.read_excel(PASSENGER_FILE, sheet_name="Model_Input")
    state = pd.read_excel(STATE_FILE, sheet_name="State_Data")
    passenger["Date"] = pd.to_datetime(passenger["Date"])
    state["Date"] = pd.to_datetime(state["Date"])
    passenger = passenger.loc[passenger["Date"].between(START_DATE, END_DATE)].copy()
    passenger = passenger.rename(columns={
        "FF5_Mkt_RF": "Mkt-RF", "FF5_SMB": "SMB", "FF5_HML": "HML"
    })
    return passenger, state


def previous_available(values, target_dates):
    source = values.dropna().sort_index()
    keys = source.index.to_numpy(dtype="datetime64[ns]")
    result = []
    for day in target_dates:
        position = np.searchsorted(keys, np.datetime64(day), side="left") - 1
        result.append(np.nan if position < 0 else float(source.iloc[position]))
    return np.asarray(result, float)


def raw_log_returns(values):
    source = values.dropna().sort_index()
    returns = np.log(source / source.shift(1))
    return returns.loc[returns.index.to_series().between(START_DATE, END_DATE)]


def build_model_data(passenger, raw_state):
    raw = raw_state.set_index("Date").sort_index()
    dates = pd.DatetimeIndex(passenger["Date"])
    output = passenger[["Date", "LS_Return", *FACTORS]].copy()
    output["DGS2_Lagged"] = previous_available(raw["DGS2"], dates)
    previous_calendar_dates = dates - pd.Timedelta(days=1)
    output["EPU_Previous_Calendar_Day"] = raw["EPU_Daily_Index"].reindex(
        previous_calendar_dates).to_numpy(float)
    output["logEPU_Lagged"] = np.log1p(output["EPU_Previous_Calendar_Day"])

    brent_returns = raw_log_returns(raw["Brent_CO1"])
    cobalt_returns = raw_log_returns(raw["Cobalt_LMCODY"])
    lithium_returns = raw_log_returns(raw["Lithium_L4CNMJGO"])
    brent_mean, brent_sd = float(brent_returns.mean()), float(brent_returns.std(ddof=0))
    cobalt_mean, cobalt_sd = float(cobalt_returns.mean()), float(cobalt_returns.std(ddof=0))
    lithium_mean, lithium_sd = float(lithium_returns.mean()), float(lithium_returns.std(ddof=0))
    output["Brent_Log_Return"] = brent_returns.reindex(dates).to_numpy(float)
    output["Brent_Z"] = (output["Brent_Log_Return"] - brent_mean) / brent_sd
    output["Cobalt_Log_Return"] = cobalt_returns.reindex(dates).to_numpy(float)
    output["Cobalt_Z"] = (output["Cobalt_Log_Return"] - cobalt_mean) / cobalt_sd
    output["Lithium_Log_Return"] = lithium_returns.reindex(dates).to_numpy(float)
    output["Lithium_Z"] = (output["Lithium_Log_Return"] - lithium_mean) / lithium_sd

    complete_base = output[["LS_Return", *FACTORS]].notna().all(axis=1)
    for raw_name, z_name in [("DGS2_Lagged", "DGS2_Z"), ("logEPU_Lagged", "EPU_Z")]:
        sample = output.loc[complete_base & output[raw_name].notna(), raw_name]
        output[z_name] = (output[raw_name] - sample.mean()) / sample.std(ddof=0)
    metadata = {}
    for name, raw_column, returns, mean, sd in [
        ("Brent", "Brent_CO1", brent_returns, brent_mean, brent_sd),
        ("Cobalt", "Cobalt_LMCODY", cobalt_returns, cobalt_mean, cobalt_sd),
        ("Lithium", "Lithium_L4CNMJGO", lithium_returns, lithium_mean, lithium_sd),
    ]:
        metadata[name] = {
            "Record_Type": "Transformation_Summary", "Specification": name,
            "Source_Field": raw_column, "Raw_Observations": int(raw[raw_column].notna().sum()),
            "Raw_Log_Returns": int(returns.notna().sum()),
            "Raw_Return_Start": returns.dropna().index.min(),
            "Raw_Return_End": returns.dropna().index.max(),
            "Raw_Return_Mean": mean, "Raw_Return_Population_SD": sd,
            "Aligned_Factor_Dates": int(output[f"{name}_Log_Return"].notna().sum()),
        }
    return output, metadata


def fit_hac(data, regressors):
    columns = ["LS_Return", *regressors]
    sample = data.dropna(subset=columns).copy()
    x = sm.add_constant(sample[regressors].astype(float), has_constant="add")
    model = sm.OLS(sample["LS_Return"].astype(float), x).fit(
        cov_type="HAC", cov_kwds={"maxlags": HAC_LAGS})
    return model, sample


def coefficient_rows(model, sample, model_name):
    interval = model.conf_int()
    return [{
        "Model": model_name,
        "Variable": "alpha" if variable == "const" else variable,
        "Coefficient": float(model.params[variable]),
        "HAC_SE": float(model.bse[variable]),
        "HAC_t": float(model.tvalues[variable]),
        "p_value": float(model.pvalues[variable]),
        "CI95_Lower": float(interval.loc[variable, 0]),
        "CI95_Upper": float(interval.loc[variable, 1]),
        "N": int(model.nobs), "R2": float(model.rsquared),
        "Adj_R2": float(model.rsquared_adj), "HAC_Lags": HAC_LAGS,
        "Start": sample["Date"].min(), "End": sample["Date"].max(),
    } for variable in model.params.index]


def wald_block(model, variables, model_name, test_name, state=None):
    names = list(model.params.index)
    restriction = np.zeros((len(variables), len(names)))
    for row, variable in enumerate(variables):
        restriction[row, names.index(variable)] = 1.0
    test = model.wald_test(restriction, scalar=True)
    return {
        "Model": model_name, "Test": test_name, "State": state,
        "Restrictions": len(variables), "Statistic_Type": "Wald chi-square",
        "Statistic": float(test.statistic), "p_value": float(test.pvalue),
        "N": int(model.nobs), "R2": float(model.rsquared),
        "Adj_R2": float(model.rsquared_adj),
    }


def state_model(data, state, z_column, model_name):
    interaction_names = []
    work = data.copy()
    for factor in FACTORS:
        name = f"{factor}_x_{state}_Z"
        work[name] = work[factor] * work[z_column]
        interaction_names.append(name)
    regressors = [*FACTORS, z_column, *interaction_names]
    model, sample = fit_hac(work, regressors)
    raw_p = np.asarray([model.pvalues[name] for name in interaction_names], float)
    holm = multipletests(raw_p, alpha=.05, method="holm")
    order = np.argsort(raw_p, kind="stable")
    ranks = np.empty(len(raw_p), int)
    ranks[order] = np.arange(1, len(raw_p) + 1)
    interactions = []
    for index, factor in enumerate(FACTORS):
        name = interaction_names[index]
        interactions.append({
            "Model": model_name, "State": state, "Factor": factor,
            "Interaction_Variable": name, "Coefficient": float(model.params[name]),
            "HAC_SE": float(model.bse[name]), "HAC_t": float(model.tvalues[name]),
            "Raw_p_value": float(raw_p[index]), "Holm_Rank": int(ranks[index]),
            "Holm_Adjusted_p": float(holm[1][index]), "Holm_Reject": bool(holm[0][index]),
        })
    covariance = model.cov_params()
    marginal = []
    state_mean = float(sample[z_column].mean())
    state_sd = float(sample[z_column].std(ddof=0))
    levels = [(state_mean - state_sd, "Low (-1 SD)"),
              (state_mean, "Mean"),
              (state_mean + state_sd, "High (+1 SD)")]
    for factor in FACTORS:
        interaction = f"{factor}_x_{state}_Z"
        for z, label in levels:
            loading = float(model.params[factor] + z * model.params[interaction])
            variance = float(covariance.loc[factor, factor] + z * z * covariance.loc[interaction, interaction]
                             + 2 * z * covariance.loc[factor, interaction])
            se = math.sqrt(max(variance, 0.0))
            statistic = loading / se if se > 0 else np.nan
            p_value = 2 * (1 - norm.cdf(abs(statistic))) if np.isfinite(statistic) else np.nan
            marginal.append({
                "Model": model_name, "State": state, "Factor": factor,
                "State_Level": label, "Z_Value": z, "Marginal_Loading": loading,
                "SE": se, "t": float(statistic), "p_value": float(p_value),
            })
    joint = wald_block(model, interaction_names, model_name,
                       f"All six {state} interactions equal zero", state)
    return model, sample, coefficient_rows(model, sample, model_name), interactions, marginal, joint


def combined_model(data):
    work = data.copy()
    interaction_groups = {}
    for state, z_column in [("DGS2", "DGS2_Z"), ("EPU", "EPU_Z")]:
        names = []
        for factor in FACTORS:
            name = f"{factor}_x_{state}_Z"
            work[name] = work[factor] * work[z_column]
            names.append(name)
        interaction_groups[state] = names
    regressors = [*FACTORS, "DGS2_Z", "EPU_Z",
                  *interaction_groups["DGS2"], *interaction_groups["EPU"]]
    model, sample = fit_hac(work, regressors)
    interactions = []
    for state, names in interaction_groups.items():
        for factor, name in zip(FACTORS, names):
            interactions.append({
                "Model": "Combined_DGS2_EPU", "State": state, "Factor": factor,
                "Interaction_Variable": name, "Coefficient": float(model.params[name]),
                "HAC_SE": float(model.bse[name]), "HAC_t": float(model.tvalues[name]),
                "Raw_p_value": float(model.pvalues[name]), "Holm_Rank": None,
                "Holm_Adjusted_p": None, "Holm_Reject": None,
            })
    tests = [wald_block(model, names, "Combined_DGS2_EPU",
                        f"Combined model {state} interaction block", state)
             for state, names in interaction_groups.items()]
    return model, sample, coefficient_rows(model, sample, "Combined_DGS2_EPU"), interactions, tests


def commodity_models(data, metadata):
    output, tests = [], []
    output.extend(metadata.values())
    for model_name, controls in [
        ("Brent", ["Brent_Z"]),
        ("Cobalt", ["Cobalt_Z"]),
        ("Lithium", ["Lithium_Z"]),
        ("Brent_Cobalt", ["Brent_Z", "Cobalt_Z"]),
        ("Battery_Materials", ["Cobalt_Z", "Lithium_Z"]),
        ("All_Commodities", ["Brent_Z", "Cobalt_Z", "Lithium_Z"]),
    ]:
        model, sample = fit_hac(data, [*FACTORS, *controls])
        same_date_data = data.loc[data["Date"].isin(sample["Date"])].copy()
        baseline, baseline_sample = fit_hac(same_date_data, FACTORS)
        if not sample["Date"].reset_index(drop=True).equals(
                baseline_sample["Date"].reset_index(drop=True)):
            raise RuntimeError(f"Same-date baseline mismatch for {model_name}")
        included = ", ".join(controls)
        output.extend({"Record_Type": "Same_Date_Baseline", "Specification": model_name,
                       "Variables_Included": "FF5+MOM", **row}
                      for row in coefficient_rows(baseline, baseline_sample,
                                                  f"{model_name}_Same_Date_Baseline"))
        output.extend({"Record_Type": "Commodity_Model", "Specification": model_name,
                       "Variables_Included": f"FF5+MOM, {included}", **row}
                      for row in coefficient_rows(model, sample, model_name))
        test = wald_block(model, controls, model_name,
                          "Commodity controls jointly equal zero")
        tests.append(test)
        output.append({"Record_Type": "Commodity_Wald_Test", "Specification": model_name,
                       "Variables_Included": included, **test})
    return output, tests


def write_sheet(workbook, name, records):
    frame = records if isinstance(records, pd.DataFrame) else pd.DataFrame(records)
    sheet = workbook.create_sheet(name)
    sheet.append(frame.columns.tolist())
    for row in frame.itertuples(index=False, name=None):
        sheet.append([None if pd.isna(value) else
                      value.to_pydatetime() if isinstance(value, pd.Timestamp) else value
                      for value in row])
    sheet.freeze_panes = "A2"
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            if hasattr(cell.value, "year") and hasattr(cell.value, "month"):
                cell.number_format = "yyyy-mm-dd"


def main():
    passenger, raw_state = load_inputs()
    data, commodity_metadata = build_model_data(passenger, raw_state)

    baseline, baseline_sample = fit_hac(data, FACTORS)
    state_rows = coefficient_rows(baseline, baseline_sample, "Baseline")
    dgs = state_model(data, "DGS2", "DGS2_Z", "DGS2_State")
    epu = state_model(data, "EPU", "EPU_Z", "EPU_State")
    state_rows.extend(dgs[2]); state_rows.extend(epu[2])
    combined = combined_model(data)
    state_rows.extend(combined[2])
    interaction_rows = dgs[3] + epu[3] + combined[3]
    marginal_rows = dgs[4] + epu[4]
    joint_rows = [dgs[5], epu[5], *combined[4]]
    commodity_rows, commodity_tests = commodity_models(data, commodity_metadata)

    if data.empty or data["Date"].duplicated().any():
        raise RuntimeError("State-model input is empty or contains duplicate dates")
    assert data["Date"].min() == START_DATE and data["Date"].max() == END_DATE
    assert data["Date"].max().year == 2025
    assert int(baseline.nobs) == len(data)
    assert int(dgs[0].nobs) == len(data) and int(epu[0].nobs) == len(data)
    assert all(row["Restrictions"] == 6 for row in joint_rows)
    assert len([row for row in interaction_rows if row["Model"] == "DGS2_State"]) == 6
    assert len([row for row in interaction_rows if row["Model"] == "EPU_State"]) == 6
    assert len(marginal_rows) == 36
    assert np.isclose(data["DGS2_Z"].mean(), 0.0, atol=1e-12)
    assert np.isclose(data["DGS2_Z"].std(ddof=0), 1.0, atol=1e-12)
    assert np.isclose(data["EPU_Z"].mean(), 0.0, atol=1e-12)
    assert np.isclose(data["EPU_Z"].std(ddof=0), 1.0, atol=1e-12)

    audit = data[["Date", "LS_Return", *FACTORS, "DGS2_Lagged", "DGS2_Z",
                  "EPU_Previous_Calendar_Day", "logEPU_Lagged", "EPU_Z",
                  "Brent_Log_Return", "Brent_Z", "Cobalt_Log_Return", "Cobalt_Z",
                  "Lithium_Log_Return", "Lithium_Z"]].copy()

    workbook = Workbook()
    workbook.remove(workbook.active)
    write_sheet(workbook, "State_Data", audit)
    write_sheet(workbook, "State_Models", state_rows)
    write_sheet(workbook, "Interactions", interaction_rows)
    write_sheet(workbook, "Marginal_Loadings", marginal_rows)
    write_sheet(workbook, "Joint_Tests", joint_rows)
    write_sheet(workbook, "Commodity_Controls", commodity_rows)
    workbook.save(OUTPUT_FILE)
    print(OUTPUT_FILE.name)


if __name__ == "__main__":
    main()
