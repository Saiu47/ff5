from __future__ import annotations

import itertools
import math
import warnings
from collections import defaultdict
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from openpyxl import Workbook
from scipy.optimize import linear_sum_assignment
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_bipartite_matching


BASE = Path(__file__).resolve().parents[2] / 'Input' / 'V2'
OUTPUT_DIR = Path(__file__).resolve().parents[2] / 'Output' / 'Base'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
CHARACTERISTICS = BASE / "FF5_Firm_Characteristics.xlsx"
PASSENGER_DATA = BASE / "FF5_Passenger_Data.xlsx"
PASSENGER_RESULTS = BASE / "FF5_Passenger_Results.xlsx"
UNIVERSE_DATA = BASE / "FF5_Universe_Definitions.xlsx"
OUTPUT = OUTPUT_DIR / "FF5_Lifecycle_Matching.xlsx"
END_DATE = pd.Timestamp("2025-12-31")
HAC_LAGS = 22
CALIPER_GRID = [0.20, 0.15, 0.10, 0.08, 0.05]
BALANCE_TARGET = 0.10
STRICT_CALIPER = 0.50
SCORE_NORM_TOLERANCE = 1e-8
OPTIMIZER_COEFFICIENT_TOLERANCE = 1e-7
OPTIMIZER_PROPENSITY_TOLERANCE = 1e-8
OPTIMIZER_LOGLIKELIHOOD_TOLERANCE = 1e-10
COVARIATES = ["log_mcap", "bm_w", "roa_w", "log_age"]
FF3 = ["Mkt-RF", "SMB", "HML"]
FF5 = ["Mkt-RF", "SMB", "HML", "RMW", "CMA"]
FFM = ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]


def load_inputs():
    pit = pd.read_excel(CHARACTERISTICS, sheet_name="PIT_Fundamentals")
    age = pd.read_excel(CHARACTERISTICS, sheet_name="Firm_Age")
    eligibility = pd.read_excel(PASSENGER_DATA, sheet_name="Monthly_Eligibility")
    returns = pd.read_excel(PASSENGER_DATA, sheet_name="Daily_Returns")
    factors = pd.read_excel(PASSENGER_DATA, sheet_name="Model_Input")
    universe = pd.read_excel(UNIVERSE_DATA, sheet_name="Passenger_Universe")
    for frame, columns in [
        (pit, ["Anchor_Date", "Common_Equity_Period_End", "Common_Equity_Revision_Date",
               "ROA_Period_End", "ROA_Revision_Date"]),
        (age, ["Resolved_Age_Start"]),
        (eligibility, ["Month", "MarketCap_Date"]),
        (returns, ["Date"]), (factors, ["Date"]),
        (universe, ["Economic_Start", "Economic_End", "Classification_Start", "Classification_End"]),
    ]:
        for column in columns:
            frame[column] = pd.to_datetime(frame[column])
    return pit, age, eligibility, returns, factors, universe


def classification(records, day):
    selected = records[
        records["Classification_Start"].notna() & records["Classification_End"].notna()
        & (records["Classification_Start"] <= day) & (records["Classification_End"] >= day)
    ]
    return None if selected.empty else selected.iloc[0]["Binary_Class"]


def stable_class(records, year, economic_start, economic_end):
    start = max(pd.Timestamp(year, 1, 1), economic_start)
    end = min(pd.Timestamp(year, 12, 31), END_DATE, economic_end)
    if start > end:
        return None
    groups = set()
    for row in records.itertuples(index=False):
        if pd.isna(row.Classification_Start) or pd.isna(row.Classification_End):
            continue
        if max(start, row.Classification_Start) <= min(end, row.Classification_End):
            groups.add(row.Binary_Class)
    return next(iter(groups)) if len(groups) == 1 else None


def build_annual_panel(pit, age, eligibility, universe):
    age_index = age.set_index("Bloomberg_ID")
    pit_index = pit.set_index(["Anchor_Date", "Bloomberg_ID"])
    formation = eligibility.set_index(["Company", "Month"])
    valid_ids = set(age["Bloomberg_ID"].dropna().astype(str))
    universe = universe[universe["Bloomberg_ID"].astype(str).isin(valid_ids)].copy()
    metadata = {}
    for bid, records in universe.dropna(subset=["Bloomberg_ID"]).groupby("Bloomberg_ID", sort=False):
        economic = records.dropna(subset=["Economic_Start", "Economic_End"])
        if economic.empty:
            continue
        metadata[bid] = {
            "company": records.iloc[0]["Company"], "records": records,
            "economic_start": economic.iloc[0]["Economic_Start"],
            "economic_end": economic.iloc[0]["Economic_End"],
        }
    rows = []
    for year in range(2016, 2026):
        anchor = pd.Timestamp(year - 1, 12, 31)
        for bid, meta in metadata.items():
            if not (meta["economic_start"] <= anchor <= meta["economic_end"]):
                continue
            fundamental = pit_index.loc[(anchor, bid)]
            age_row = age_index.loc[bid]
            group_outcome = stable_class(meta["records"], year, meta["economic_start"], meta["economic_end"])
            month = pd.Timestamp(year, 1, 1)
            if (meta["company"], month) in formation.index:
                formed = formation.loc[(meta["company"], month)]
                market_cap = formed["MarketCap_USD_mn"]
                market_cap_date = formed["MarketCap_Date"]
                pass_50 = bool(formed["Pass_USD50m"])
            else:
                market_cap = market_cap_date = None
                pass_50 = False
            market_cap_usd = market_cap * 1e6 if pd.notna(market_cap) else None
            equity = fundamental["Common_Equity_USD"]
            bm = equity / market_cap_usd if pd.notna(equity) and market_cap_usd and market_cap_usd > 0 else None
            age_years = max((anchor - age_row["Resolved_Age_Start"]).days / 365.25, 0.0)
            log_market_cap = math.log(market_cap_usd) if market_cap_usd and market_cap_usd > 0 else None
            log_age = math.log1p(age_years)
            date_fields = [fundamental["Common_Equity_Period_End"], fundamental["Common_Equity_Revision_Date"],
                           fundamental["ROA_Period_End"], fundamental["ROA_Revision_Date"]]
            pit_bad = any(pd.notna(value) and value > anchor for value in date_fields)
            equity_stale = ((anchor - fundamental["Common_Equity_Revision_Date"]).days
                            if pd.notna(fundamental["Common_Equity_Revision_Date"]) else None)
            roa_stale = ((anchor - fundamental["ROA_Revision_Date"]).days
                         if pd.notna(fundamental["ROA_Revision_Date"]) else None)
            stale = ((equity_stale is not None and equity_stale > 365)
                     or (roa_stale is not None and roa_stale > 365))
            roa = fundamental["ROA"]
            complete = all(value is not None and pd.notna(value) and np.isfinite(float(value))
                           for value in [log_market_cap, bm, roa, log_age])
            stable = group_outcome in ("EV", "Non-EV")
            eligible = stable and not pit_bad and not stale and complete and pass_50
            rows.append({
                "return_year": year, "source_year": year - 1, "obs_date": anchor,
                "bbg_id": bid, "company": meta["company"],
                "group_anchor": classification(meta["records"], anchor),
                "group_outcome": group_outcome, "treatment_stable": stable,
                "mcap_date": market_cap_date, "mcap_usd_mn": market_cap,
                "anchor_pass_50": pass_50, "log_mcap": log_market_cap,
                "tot_common_eqy_usd": equity, "bm": bm, "roa": roa,
                "negative_equity": bool(pd.notna(equity) and equity < 0),
                "age_start": age_row["Resolved_Age_Start"], "age_date_source": age_row["Age_Source"],
                "age_proxy": bool(age_row["Age_Proxy_Flag"]), "age_years": age_years, "log_age": log_age,
                "tce_period_end": fundamental["Common_Equity_Period_End"],
                "tce_revision_date": fundamental["Common_Equity_Revision_Date"],
                "roa_period_end": fundamental["ROA_Period_End"],
                "roa_revision_date": fundamental["ROA_Revision_Date"],
                "tce_stale_days": equity_stale, "roa_stale_days": roa_stale,
                "pit_bad": pit_bad, "stale_over_365": stale,
                "complete_raw": complete, "psm_eligible": eligible,
            })
    annual = pd.DataFrame(rows)
    eligible = annual[annual["psm_eligible"]]
    bm_low, bm_high = np.quantile(eligible["bm"], [.01, .99])
    roa_low, roa_high = np.quantile(eligible["roa"], [.01, .99])
    annual["bm_w"] = np.where(annual["psm_eligible"], annual["bm"].clip(bm_low, bm_high), np.nan)
    annual["roa_w"] = np.where(annual["psm_eligible"], annual["roa"].clip(roa_low, roa_high), np.nan)
    return annual, {"bm_p01": bm_low, "bm_p99": bm_high, "roa_p01": roa_low, "roa_p99": roa_high}


def smd(treated, controls, variable):
    left = np.asarray([row[variable] for row in treated], float)
    right = np.asarray([row[variable] for row in controls], float)
    denominator = math.sqrt((np.var(left, ddof=1) + np.var(right, ddof=1)) / 2)
    return 0.0 if denominator < 1e-15 else float((left.mean() - right.mean()) / denominator)


def balance_pairs(pairs):
    return {v: smd([p["ev"] for p in pairs], [p["ne"] for p in pairs], v) for v in COVARIATES}


def fit_propensity(frame, squared_age=False):
    rows = frame.to_dict("records")
    years = sorted(frame["return_year"].unique())
    names = ["const", *COVARIATES]
    matrix = []
    for row in rows:
        values = [1, *[row[v] for v in COVARIATES]]
        if squared_age:
            values.append(row["log_age"] ** 2)
        values += [1 if row["return_year"] == year else 0 for year in years[1:]]
        matrix.append(values)
    if squared_age:
        names.append("log_age_sq")
    names += [(f"Y_{year}" if squared_age else f"Y{year}") for year in years[1:]]
    x = np.asarray(matrix, float)
    y = np.asarray([row["group_outcome"] == "EV" for row in rows], int)
    model = sm.Logit(y, x)
    continuous_columns = 5 if squared_age else 4
    verification_x = x.copy()
    verification_means = verification_x[:, 1:continuous_columns + 1].mean(axis=0)
    verification_scales = verification_x[:, 1:continuous_columns + 1].std(axis=0, ddof=0)
    verification_x[:, 1:continuous_columns + 1] = (
        (verification_x[:, 1:continuous_columns + 1] - verification_means) / verification_scales)
    verification_model = sm.Logit(y, verification_x)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        fit = model.fit(disp=False, maxiter=2000, method="newton", tol=1e-12, full_output=True)
        verification = verification_model.fit(disp=False, maxiter=5000, method="bfgs",
                                               gtol=1e-10, full_output=True)
    verification_params = np.asarray(verification.params, float).copy()
    verification_params[1:continuous_columns + 1] /= verification_scales
    verification_params[0] -= np.sum(
        verification_means * verification_params[1:continuous_columns + 1])
    predicted = np.asarray(fit.predict(x), float)
    verification_predicted = np.asarray(verification.predict(verification_x), float)
    score_norm = float(np.linalg.norm(model.score(fit.params)))
    verification_score_norm = float(np.linalg.norm(model.score(verification_params)))
    coefficient_difference = float(np.max(np.abs(fit.params - verification_params)))
    propensity_difference = float(np.max(np.abs(predicted - verification_predicted)))
    loglikelihood_difference = float(abs(fit.llf - verification.llf))
    covariance = np.asarray(fit.cov_params(), float)
    checks = [
        bool(fit.mle_retvals.get("converged", False)),
        bool(verification.mle_retvals.get("converged", False)),
        np.isfinite(fit.params).all(), np.isfinite(covariance).all(), np.isfinite(fit.bse).all(),
        score_norm <= SCORE_NORM_TOLERANCE,
        coefficient_difference <= OPTIMIZER_COEFFICIENT_TOLERANCE,
        propensity_difference <= OPTIMIZER_PROPENSITY_TOLERANCE,
        loglikelihood_difference <= OPTIMIZER_LOGLIKELIHOOD_TOLERANCE,
    ]
    if not all(checks):
        raise RuntimeError("Propensity optimizer verification failed")
    ps_name, logit_name, support_name = (("ps_alt", "logit_alt", "support_alt") if squared_age
                                         else ("ps", "logit_ps", "att_support"))
    for row, probability in zip(rows, predicted):
        row[ps_name] = float(probability)
        row[logit_name] = float(np.log(probability / (1 - probability)))
    support = []
    for year in years:
        group = [row for row in rows if row["return_year"] == year]
        treated = [row for row in group if row["group_outcome"] == "EV"]
        controls = [row for row in group if row["group_outcome"] == "Non-EV"]
        low, high = min(row[ps_name] for row in controls), max(row[ps_name] for row in controls)
        for row in group:
            row[support_name] = row["group_outcome"] == "Non-EV" or low <= row[ps_name] <= high
        support.append({"return_year": year, "n_ev_before": len(treated), "n_nonev_before": len(controls),
                        "n_ev_support": sum(row[support_name] for row in treated),
                        "control_ps_min": low, "control_ps_max": high,
                        "ev_ps_min": min(row[ps_name] for row in treated),
                        "ev_ps_max": max(row[ps_name] for row in treated)})
    ci = fit.conf_int()
    coefficients = [{"variable": name, "coefficient": float(fit.params[i]), "se": float(fit.bse[i]),
                     "z": float(fit.tvalues[i]), "p_value": float(fit.pvalues[i]),
                     "ci95_lower": float(ci[i, 0]), "ci95_upper": float(ci[i, 1])}
                    for i, name in enumerate(names)]
    diagnostics = [
        {"Optimizer": "Newton", "Converged": bool(fit.mle_retvals.get("converged", False)),
         "Iterations": fit.mle_retvals.get("iterations"), "Function_Evaluations": None,
         "Log_Likelihood": float(fit.llf), "Score_Norm": score_norm,
         "Design_Rank": int(np.linalg.matrix_rank(x)), "Design_Columns": int(x.shape[1]),
         "PS_Min": float(predicted.min()), "PS_Max": float(predicted.max()),
         "Finite_Covariance": bool(np.isfinite(covariance).all())},
        {"Optimizer": "BFGS_Verification",
         "Converged": bool(verification.mle_retvals.get("converged", False)),
         "Iterations": verification.mle_retvals.get("iterations"),
         "Function_Evaluations": verification.mle_retvals.get("fcalls"),
         "Log_Likelihood": float(verification.llf), "Score_Norm": verification_score_norm,
         "Design_Rank": int(np.linalg.matrix_rank(x)), "Design_Columns": int(x.shape[1]),
         "PS_Min": float(verification_predicted.min()), "PS_Max": float(verification_predicted.max()),
         "Finite_Covariance": bool(np.isfinite(verification.cov_params()).all())},
        {"Optimizer": "Newton_vs_BFGS", "Max_Coefficient_Difference": coefficient_difference,
         "Max_Propensity_Difference": propensity_difference,
         "Log_Likelihood_Difference": loglikelihood_difference},
    ]
    return rows, coefficients, support, diagnostics


def optimal_match(rows, multiplier, alternate=False):
    ps, logit, support = (("ps_alt", "logit_alt", "support_alt") if alternate
                          else ("ps", "logit_ps", "att_support"))
    pairs, yearly = [], []
    for year in sorted({row["return_year"] for row in rows}):
        group = [row for row in rows if row["return_year"] == year]
        stable_key = lambda row: (str(row["bbg_id"]), str(row["company"]))
        treated = sorted([row for row in group if row["group_outcome"] == "EV" and row[support]],
                         key=stable_key)
        controls = sorted([row for row in group if row["group_outcome"] == "Non-EV"], key=stable_key)
        if not treated:
            yearly.append({"return_year": year, "pairs": 0})
            continue
        score_sd = float(np.std([row[logit] for row in group], ddof=1))
        caliper = multiplier * score_sd
        scales = {v: max(float(np.std([row[v] for row in group], ddof=1)), 1e-12) for v in COVARIATES}
        raw = np.full((len(treated), len(controls)), np.inf)
        for i, left in enumerate(treated):
            for j, right in enumerate(controls):
                if abs(left[logit] - right[logit]) <= caliper:
                    distance = math.sqrt(sum(((left[v] - right[v]) / scales[v]) ** 2 for v in COVARIATES))
                    raw[i, j] = distance
        admissible = np.isfinite(raw)
        maximum_matching = maximum_bipartite_matching(csr_matrix(admissible), perm_type="column")
        maximum_cardinality = int(np.sum(maximum_matching >= 0))
        if maximum_cardinality == 0:
            yearly.append({"return_year": year, "pairs": 0, "supported_ev": len(treated),
                           "sd_logit_ps": score_sd, "caliper": caliper})
            continue
        valid = raw[admissible]
        dummy_columns = len(treated) - maximum_cardinality
        invalid_cost = (maximum_cardinality + 1) * (float(valid.max()) + 1.0)
        cost = np.full((len(treated), len(controls) + dummy_columns), invalid_cost)
        distinct = np.unique(valid)
        positive_gaps = np.diff(distinct)
        positive_gaps = positive_gaps[positive_gaps > 0]
        tie_unit = ((positive_gaps.min() / (10 * (raw.size + 1))) if positive_gaps.size
                    else np.finfo(float).eps * max(1.0, float(valid.max())))
        tie_rank = np.arange(raw.size, dtype=float).reshape(raw.shape)
        cost[:, :len(controls)] = np.where(admissible, raw + tie_unit * tie_rank, invalid_cost)
        if dummy_columns:
            cost[:, len(controls):] = 0.0
        row_indices, column_indices = linear_sum_assignment(cost)
        count = 0
        for i, j in zip(row_indices, column_indices):
            if j < len(controls) and np.isfinite(raw[i, j]):
                pairs.append({"year": year, "ev": treated[i], "ne": controls[j],
                              "ps_dist": abs(treated[i][logit] - controls[j][logit]),
                              "caliper": caliper, "cov_dist": float(raw[i, j]),
                              "ev_ps": treated[i][ps], "ne_ps": controls[j][ps]})
                count += 1
        if count != maximum_cardinality:
            raise RuntimeError("Maximum-cardinality assignment failed")
        yearly.append({"return_year": year, "pairs": count, "supported_ev": len(treated),
                       "sd_logit_ps": score_sd, "caliper": caliper})
    return pairs, yearly


def nearest_neighbor(rows, multiplier=.20):
    pairs = []
    for year in sorted({row["return_year"] for row in rows}):
        group = [row for row in rows if row["return_year"] == year]
        stable_key = lambda row: (str(row["bbg_id"]), str(row["company"]))
        treated = sorted([row for row in group if row["group_outcome"] == "EV" and row["att_support"]],
                         key=stable_key)
        controls = sorted([row for row in group if row["group_outcome"] == "Non-EV"], key=stable_key)
        caliper = multiplier * float(np.std([row["logit_ps"] for row in group], ddof=1))
        for left in treated:
            candidates = [(abs(left["logit_ps"] - right["logit_ps"]), right)
                          for right in controls if abs(left["logit_ps"] - right["logit_ps"]) <= caliper]
            candidates.sort(key=lambda item: (item[0], str(item[1]["bbg_id"]), str(item[1]["company"])))
            if candidates:
                distance, right = candidates[0]
                pairs.append({"year": year, "ev": left, "ne": right, "ps_dist": distance,
                              "caliper": caliper, "cov_dist": None,
                              "ev_ps": left["ps"], "ne_ps": right["ps"]})
    return pairs


def strict_subset(candidate):
    for size in range(len(candidate), 3, -1):
        best = None
        for indices in itertools.combinations(range(len(candidate)), size):
            subset = [candidate[i] for i in indices]
            values = balance_pairs(subset)
            maximum = max(abs(value) for value in values.values())
            if maximum < BALANCE_TARGET and (best is None or maximum < best[0]):
                best = (maximum, indices, values)
        if best is not None:
            return [candidate[i] for i in best[1]], best[2]
    raise RuntimeError("No strict-balance subset")


def pair_rows(pairs, specification):
    return [{"Matching_Specification": specification, "Return_Year": pair["year"],
             "EV_Bloomberg_ID": pair["ev"]["bbg_id"], "EV_Company": pair["ev"]["company"],
             "EV_PS": pair["ev_ps"],
             "EV_Logit_PS": pair["ev"].get("logit_alt", pair["ev"].get("logit_ps")),
             "NonEV_Bloomberg_ID": pair["ne"]["bbg_id"],
             "NonEV_Company": pair["ne"]["company"], "NonEV_PS": pair["ne_ps"],
             "NonEV_Logit_PS": pair["ne"].get("logit_alt", pair["ne"].get("logit_ps")),
             "Logit_PS_Distance": pair["ps_dist"], "Caliper": pair["caliper"],
             "Standardized_Covariate_Distance": pair["cov_dist"]} for pair in pairs]


def daily_pairs(pairs, returns, eligibility, universe, factor_dates):
    returns = returns.set_index("Date")
    pass_map = {(row.Company, row.Month.to_period("M")): bool(row.Pass_USD50m)
                for row in eligibility.itertuples(index=False)}
    class_map = {bid: records for bid, records in universe.dropna(subset=["Bloomberg_ID"]).groupby("Bloomberg_ID")}
    by_year = defaultdict(list)
    for pair in pairs:
        by_year[pair["year"]].append(pair)
    records = []
    for day in factor_dates:
        ev, nonev, spread = [], [], []
        for pair in by_year[day.year]:
            left, right = pair["ev"], pair["ne"]
            month = day.to_period("M")
            if not pass_map.get((left["company"], month), False) or not pass_map.get((right["company"], month), False):
                continue
            if day not in returns.index:
                continue
            left_return, right_return = returns.at[day, left["company"]], returns.at[day, right["company"]]
            if pd.isna(left_return) or pd.isna(right_return):
                continue
            if classification(class_map[left["bbg_id"]], day) != "EV" or classification(class_map[right["bbg_id"]], day) != "Non-EV":
                continue
            ev.append(float(left_return)); nonev.append(float(right_return)); spread.append(float(left_return-right_return))
        records.append({"Date": day, "EV": np.mean(ev) if ev else np.nan,
                        "NonEV": np.mean(nonev) if nonev else np.nan,
                        "LS": np.mean(spread) if spread else np.nan, "Pairs_N": len(spread)})
    return pd.DataFrame(records).set_index("Date")


def factor_frames(model_input):
    frame = model_input.set_index("Date")
    ff3 = pd.DataFrame({"Mkt-RF": frame.FF3_Mkt_RF, "SMB": frame.FF3_SMB,
                        "HML": frame.FF3_HML, "RF": frame.FF3_RF})
    ff5 = pd.DataFrame({"Mkt-RF": frame.FF5_Mkt_RF, "SMB": frame.FF5_SMB,
                        "HML": frame.FF5_HML, "RMW": frame.RMW, "CMA": frame.CMA,
                        "MOM": frame.MOM, "RF": frame.FF5_RF})
    return [("FF3", ff3, FF3), ("FF5", ff5, FF5), ("FF5+MOM", ff5, FFM)]


def regress_daily(daily, factors, specification, analysis_type="Matched", required_dates=None):
    rows = []
    date_sets = {}
    for model_name, factor_frame, names in factors:
        for portfolio in ["EV", "NonEV", "LS"]:
            data = pd.concat([daily[[portfolio]], factor_frame[names + ["RF"]]], axis=1).dropna()
            if required_dates is not None:
                target = pd.DatetimeIndex(required_dates[(model_name, portfolio)])
                data = data.loc[data.index.isin(target)]
                if not data.index.equals(target):
                    raise RuntimeError(f"Same-date sample mismatch for {model_name}/{portfolio}")
            date_sets[(model_name, portfolio)] = pd.DatetimeIndex(data.index)
            dependent = data[portfolio] - data.RF if portfolio != "LS" else data[portfolio]
            model = sm.OLS(dependent, sm.add_constant(data[names], has_constant="add")).fit(
                cov_type="HAC", cov_kwds={"maxlags": HAC_LAGS})
            interval = model.conf_int()
            for variable in model.params.index:
                rows.append({"Analysis_Type": analysis_type, "Matching_Specification": specification,
                             "Portfolio": portfolio,
                             "Model": model_name, "Variable": "alpha" if variable == "const" else variable,
                             "Coefficient": float(model.params[variable]), "HAC_SE": float(model.bse[variable]),
                             "HAC_t": float(model.tvalues[variable]), "p_value": float(model.pvalues[variable]),
                             "CI95_Lower": float(interval.loc[variable, 0]),
                             "CI95_Upper": float(interval.loc[variable, 1]), "N": int(model.nobs),
                             "R2": float(model.rsquared), "Adj_R2": float(model.rsquared_adj),
                             "HAC_Lags": HAC_LAGS, "Start": data.index.min(), "End": data.index.max()})
    return rows, date_sets


def comparison_rows(models, primary_dates, full_start):
    baseline = pd.read_excel(PASSENGER_RESULTS, sheet_name="Main_Models")
    baseline = baseline[(baseline.Record_Type == "Coefficient") & (baseline.Portfolio == "LS")
                        & baseline.Model.isin(["FF3", "FF5", "FF5+MOM"])]
    estimates = pd.DataFrame(models)
    primary = estimates[(estimates.Analysis_Type == "Matched")
                        & (estimates.Matching_Specification == "Primary")
                        & (estimates.Portfolio == "LS")]
    same_dates = estimates[(estimates.Analysis_Type == "Unmatched_Same_Dates")
                           & (estimates.Portfolio == "LS")]
    rows = []
    for model_name in ["FF3", "FF5", "FF5+MOM"]:
        full_model = baseline[baseline.Model == model_name].set_index("Variable")
        same_model = same_dates[same_dates.Model == model_name].set_index("Variable")
        primary_model = primary[primary.Model == model_name].set_index("Variable")
        for variable in primary_model.index:
            if variable not in full_model.index or variable not in same_model.index:
                continue
            full = full_model.loc[variable]
            same = same_model.loc[variable]
            matched = primary_model.loc[variable]
            rows.append({
                "Record_Type": "Coefficient_Comparison", "Portfolio": "LS", "Model": model_name,
                "Variable": variable, "Full_Baseline_Coefficient": full.Coefficient,
                "Full_Baseline_p": full.p_value,
                "SameDate_Unmatched_Coefficient": same.Coefficient,
                "SameDate_Unmatched_p": same.p_value,
                "Primary_Matched_Coefficient": matched.Coefficient,
                "Primary_Matched_p": matched.p_value,
                "Full_to_SameDate_Difference": same.Coefficient - full.Coefficient,
                "SameDate_to_Matched_Difference": matched.Coefficient - same.Coefficient,
                "Full_to_Matched_Difference": matched.Coefficient - full.Coefficient,
                "Full_N": int(full.N), "Full_Start": full_start,
                "Full_End": END_DATE, "Same_Dates_N": int(same.N), "Same_Dates_Start": same.Start,
                "Same_Dates_End": same.End, "Matched_N": int(matched.N),
                "Matched_Start": matched.Start, "Matched_End": matched.End,
            })
    all_sets = list(primary_dates.values())
    identical = all(index.equals(all_sets[0]) for index in all_sets[1:])
    models_identical = all(primary_dates[(model, portfolio)].equals(
        primary_dates[("FF3", portfolio)]) for model in ["FF5", "FF5+MOM"]
        for portfolio in ["EV", "NonEV", "LS"])
    portfolios_identical = all(primary_dates[(model, portfolio)].equals(
        primary_dates[(model, "EV")]) for model in ["FF3", "FF5", "FF5+MOM"]
        for portfolio in ["NonEV", "LS"])
    for (model_name, portfolio), index in primary_dates.items():
        rows.append({"Record_Type": "Date_Audit", "Portfolio": portfolio, "Model": model_name,
                     "Matched_N": len(index), "Matched_Start": index.min(), "Matched_End": index.max(),
                     "Date_Sets_Identical_Across_All": identical,
                     "Date_Sets_Identical_Across_Models": models_identical,
                     "Date_Sets_Identical_Across_Portfolios": portfolios_identical,
                     "Standard_Passenger_Same_Dates_N": len(index),
                     "Missing_From_Model_Input": 0})
    return rows


def balance_rows(frame, pairs, stages, extra=None):
    output = []
    treated = frame[frame.group_outcome == "EV"].to_dict("records")
    controls = frame[frame.group_outcome == "Non-EV"].to_dict("records")
    pre = {v: smd(treated, controls, v) for v in COVARIATES}
    balance_stages = [("Before_Matching", pre, len(treated), len(controls)), *stages]
    for stage, values, treated_n, control_n in balance_stages:
        for variable in COVARIATES:
            output.append({"Record_Type": "Balance", "Stage": stage, "Variable": variable,
                           "SMD": values[variable], "Abs_SMD": abs(values[variable]),
                           "Max_Abs_SMD": max(abs(x) for x in values.values()),
                           "Treated_N": treated_n, "Control_N": control_n})
    if extra:
        output.extend(extra)
    return output


def write_sheet(workbook, name, records):
    frame = records if isinstance(records, pd.DataFrame) else pd.DataFrame(records)
    sheet = workbook.create_sheet(name)
    sheet.append(frame.columns.tolist())
    for row in frame.itertuples(index=False, name=None):
        sheet.append([None if pd.isna(value) else
                      value.to_pydatetime() if isinstance(value, pd.Timestamp) else value
                      for value in row])
    sheet.freeze_panes = "A2"
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            if hasattr(cell.value, "year") and hasattr(cell.value, "month"):
                cell.number_format = "yyyy-mm-dd"


def main():
    pit, age, eligibility, returns, model_input, universe = load_inputs()
    annual, cutoffs = build_annual_panel(pit, age, eligibility, universe)
    eligible = annual[annual.psm_eligible].copy()
    base, primary_coefficients, support, primary_diagnostics = fit_propensity(eligible)
    supported_ev = sum(row["att_support"] and row["group_outcome"] == "EV" for row in base)
    grids, grid_pairs = [], {}
    for multiplier in CALIPER_GRID:
        pairs, yearly = optimal_match(base, multiplier)
        values = balance_pairs(pairs)
        years_covered = len({pair["year"] for pair in pairs})
        grids.append({"caliper_multiplier": multiplier, "pairs": len(pairs),
                      "supported_ev": supported_ev,
                      "treated_retention": len(pairs) / supported_ev,
                      "years_covered": years_covered,
                      "max_abs_smd": max(abs(x) for x in values.values()),
                      "meets_0_10_target": max(abs(x) for x in values.values()) <= .10,
                      **{f"smd_{v}": values[v] for v in COVARIATES}})
        grid_pairs[multiplier] = (pairs, yearly)
    selected = min(grids, key=lambda row: (-row["pairs"], row["max_abs_smd"],
                                           -row["caliper_multiplier"]))["caliper_multiplier"]
    primary, yearly = grid_pairs[selected]
    nn = nearest_neighbor(base)
    no_proxy = eligible[~eligible.age_proxy]
    proxy_base, proxy_coefficients, proxy_support, proxy_diagnostics = fit_propensity(no_proxy)
    proxy_pairs, proxy_yearly = optimal_match(proxy_base, selected)

    strict_base, strict_coefficients, strict_support, strict_diagnostics = fit_propensity(
        eligible, squared_age=True)
    strict_candidates, strict_yearly = optimal_match(strict_base, STRICT_CALIPER, alternate=True)
    strict_pairs, strict_final_balance = strict_subset(strict_candidates)

    factor_dates = pd.DatetimeIndex(model_input.loc[(model_input.Date >= "2016-01-01") & (model_input.Date <= END_DATE), "Date"])
    factors = factor_frames(model_input)
    specifications = [("Primary", primary), ("NN_With_Replacement", nn),
                      ("Age_Proxy", proxy_pairs), ("Strict_Balance", strict_pairs)]
    models = []
    primary_dates = None
    for name, pairs in specifications:
        daily = daily_pairs(pairs, returns, eligibility, universe, factor_dates)
        regression_rows, date_sets = regress_daily(daily, factors, name)
        if name == "Primary":
            primary_dates = date_sets
        for row in regression_rows:
            row["Record_Type"] = "Regression"
        models.extend(regression_rows)
    if primary_dates is None:
        raise RuntimeError("Primary matched regression dates were not created")
    input_dates = pd.DatetimeIndex(model_input.Date)
    for key, dates in primary_dates.items():
        missing = dates.difference(input_dates)
        if len(missing):
            raise RuntimeError(f"Primary matched dates outside Model_Input for {key}: {len(missing)}")
    unmatched = model_input.set_index("Date")[["EV_Return", "NonEV_Return", "LS_Return"]].rename(
        columns={"EV_Return": "EV", "NonEV_Return": "NonEV", "LS_Return": "LS"})
    unmatched_rows, unmatched_dates = regress_daily(
        unmatched, factors, "Unmatched_Same_Dates", "Unmatched_Same_Dates", primary_dates)
    for key in primary_dates:
        if not unmatched_dates[key].equals(primary_dates[key]):
            raise RuntimeError(f"Unmatched same-date validation failed for {key}")
    for row in unmatched_rows:
        row["Record_Type"] = "Regression"
    models.extend(unmatched_rows)
    comparison = comparison_rows(models, primary_dates, model_input.Date.min())

    primary_extra = ([{"Record_Type": "Caliper_Grid", "Matching_Specification": "Primary", **row}
                      for row in grids]
                     + [{"Record_Type": "PS_Coefficient", "Matching_Specification": "Primary", **row}
                        for row in primary_coefficients]
                     + [{"Record_Type": "Optimizer_Diagnostic", "Matching_Specification": "Primary", **row}
                        for row in primary_diagnostics]
                     + [{"Record_Type": "Support", "Matching_Specification": "Primary", **row}
                        for row in support]
                     + [{"Record_Type": "PS_Coefficient", "Matching_Specification": "Age_Proxy", **row}
                        for row in proxy_coefficients]
                     + [{"Record_Type": "Optimizer_Diagnostic", "Matching_Specification": "Age_Proxy", **row}
                        for row in proxy_diagnostics]
                     + [{"Record_Type": "Support", "Matching_Specification": "Age_Proxy", **row}
                        for row in proxy_support]
                     + [{"Record_Type": "Winsorization", **cutoffs}])
    primary_balance = balance_rows(eligible, primary,
                                   [("Primary_Matched", balance_pairs(primary),
                                     len(primary), len(primary))], primary_extra)
    removed = [pair for pair in strict_candidates if pair not in strict_pairs]
    strict_rows = pair_rows(strict_candidates, "Strict_Candidate")
    final_keys = {(p["year"], p["ev"]["bbg_id"], p["ne"]["bbg_id"]) for p in strict_pairs}
    for row in strict_rows:
        row["Final_Strict_Pair"] = (row["Return_Year"], row["EV_Bloomberg_ID"], row["NonEV_Bloomberg_ID"]) in final_keys
        row["Pair_Status"] = "Retained" if row["Final_Strict_Pair"] else "Pruned"
    strict_extra = ([{"Record_Type": "PS_Coefficient", **row} for row in strict_coefficients]
                    + [{"Record_Type": "Optimizer_Diagnostic", **row} for row in strict_diagnostics]
                    + [{"Record_Type": "Support", **row} for row in strict_support]
                    + [{"Record_Type": "Yearly_Count", **row} for row in strict_yearly])
    strict_balance = balance_rows(eligible, strict_pairs,
                                  [("Strict_Candidate", balance_pairs(strict_candidates),
                                    len(strict_candidates), len(strict_candidates)),
                                   ("Strict_Final", strict_final_balance,
                                    len(strict_pairs), len(strict_pairs))], strict_extra)
    sensitivity = pair_rows(nn, "NN_With_Replacement") + pair_rows(proxy_pairs, "Age_Proxy")

    annual_out = annual.copy()
    ps_frame = pd.DataFrame(base)[["return_year", "bbg_id", "ps", "logit_ps", "att_support"]]
    annual_out = annual_out.merge(ps_frame, on=["return_year", "bbg_id"], how="left")

    if set(annual.return_year) != set(range(2016, 2026)) or annual.return_year.max() != 2025:
        raise RuntimeError("Annual panel is not restricted to return years 2016-2025")
    if annual.obs_date.max() != pd.Timestamp("2024-12-31"):
        raise RuntimeError("Annual panel uses an invalid terminal source anchor")
    if eligible.empty or not np.isfinite(eligible[COVARIATES].to_numpy()).all():
        raise RuntimeError("Matching-eligible covariates are empty or non-finite")
    if selected not in CALIPER_GRID:
        raise RuntimeError("Selected caliper is outside the validated grid")
    if any(not pairs for pairs in [primary, nn, proxy_pairs, strict_candidates, strict_pairs]):
        raise RuntimeError("A required matching specification produced no pairs")
    if any(pair["year"] > 2025 for pairs in [primary, nn, proxy_pairs, strict_candidates, strict_pairs]
           for pair in pairs):
        raise RuntimeError("A matching specification contains a post-2025 pair")
    if len(strict_pairs) > len(strict_candidates):
        raise RuntimeError("Strict pruning increased the candidate set")
    assert max(abs(value) for value in strict_final_balance.values()) < .10

    workbook = Workbook()
    workbook.remove(workbook.active)
    write_sheet(workbook, "Annual_Covariates", annual_out)
    write_sheet(workbook, "Primary_Pairs", pair_rows(primary, "Primary"))
    write_sheet(workbook, "Primary_Balance", primary_balance)
    write_sheet(workbook, "Strict_Pairs", strict_rows)
    write_sheet(workbook, "Strict_Balance", strict_balance)
    write_sheet(workbook, "Sensitivity_Pairs", sensitivity)
    write_sheet(workbook, "Matched_Models", models)
    write_sheet(workbook, "Matching_Comparison", comparison)
    workbook.save(OUTPUT)
    print(OUTPUT.name)


if __name__ == "__main__":
    main()
