from __future__ import annotations

import math
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

from openpyxl import Workbook, load_workbook


BASE = Path(__file__).resolve().parents[2] / 'Input' / 'V2'
OUTPUT_DIR = Path(__file__).resolve().parents[2] / 'Output' / 'Base'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
MARKET_DATA = BASE / "FF5_Market_Data.xlsx"
UNIVERSE_DATA = BASE / "FF5_Universe_Definitions.xlsx"
FACTOR_DATA = BASE / "FF5_Factor_Data.xlsx"
OUTPUT = OUTPUT_DIR / "FF5_Passenger_Data.xlsx"

SAMPLE_START = date(2015, 1, 1)
SAMPLE_END = date(2025, 12, 31)
LONG_GAP_WEEKDAYS = 40
MCAP_THRESHOLD_USD_MN = 50.0

FACTOR_FIELDS = [
    "FF3_Mkt_RF", "FF3_SMB", "FF3_HML", "FF3_RF",
    "FF5_Mkt_RF", "FF5_SMB", "FF5_HML", "RMW", "CMA", "MOM", "FF5_RF",
]


def parse_date(value):
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)):
        return date(1899, 12, 30) + timedelta(days=int(value))
    text = str(value).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(text[:10], fmt).date()
        except ValueError:
            pass
    return None


def positive_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number > 0 else None


def finite_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def read_rows(path, sheet_name):
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        return [list(row) for row in workbook[sheet_name].iter_rows(values_only=True)]
    finally:
        workbook.close()


def read_market_sheet(sheet_name):
    rows = read_rows(MARKET_DATA, sheet_name)
    tickers = [str(value) for value in rows[0][1:]]
    series = {ticker: {} for ticker in tickers}
    for row in rows[1:]:
        day = parse_date(row[0] if row else None)
        if day is None:
            continue
        for index, ticker in enumerate(tickers, start=1):
            if index >= len(row):
                continue
            value = positive_number(row[index])
            if value is not None:
                series[ticker][day] = value
    return series


def read_universe():
    rows = read_rows(UNIVERSE_DATA, "Passenger_Universe")
    positions = {str(value): index for index, value in enumerate(rows[0])}
    order = []
    windows = defaultdict(list)
    for row in rows[1:]:
        if not row or row[positions["Company"]] in (None, ""):
            continue
        company = str(row[positions["Company"]])
        if company not in order:
            order.append(company)
        windows[company].append({
            "Bloomberg_ID": row[positions["Bloomberg_ID"]],
            "Economic_Start": parse_date(row[positions["Economic_Start"]]),
            "Economic_End": parse_date(row[positions["Economic_End"]]),
            "Classification_Start": parse_date(row[positions["Classification_Start"]]),
            "Classification_End": parse_date(row[positions["Classification_End"]]),
            "Binary_Class": row[positions["Binary_Class"]],
        })
    return order, windows


def read_factors():
    rows = read_rows(FACTOR_DATA, "Daily_Factors")
    positions = {str(value): index for index, value in enumerate(rows[0])}
    missing = [field for field in ["Date", *FACTOR_FIELDS] if field not in positions]
    if missing:
        raise ValueError(f"Missing factor columns: {missing}")
    factors = {}
    for row in rows[1:]:
        day = parse_date(row[positions["Date"]])
        if day is None:
            continue
        values = {field: finite_number(row[positions[field]]) for field in FACTOR_FIELDS}
        factors[day] = values
    return factors


def weekday_calendar(start, end):
    days = []
    current = start
    while current <= end:
        if current.weekday() < 5:
            days.append(current)
        current += timedelta(days=1)
    return days


def missing_weekdays_between(left, right):
    count = 0
    current = left + timedelta(days=1)
    while current < right:
        if current.weekday() < 5:
            count += 1
        current += timedelta(days=1)
    return count


def month_start(day):
    return date(day.year, day.month, 1)


def next_month(month):
    return date(month.year + 1, 1, 1) if month.month == 12 else date(month.year, month.month + 1, 1)


def previous_month(month):
    return date(month.year - 1, 12, 1) if month.month == 1 else date(month.year, month.month - 1, 1)


def month_end(month):
    return next_month(month) - timedelta(days=1)


def monthly_calendar(start, end):
    months = []
    current = date(start.year, start.month, 1)
    last = date(end.year, end.month, 1)
    while current <= last:
        months.append(current)
        current = next_month(current)
    return months


def build_passenger_data():
    prices = read_market_sheet("Prices_USD")
    market_cap = read_market_sheet("MarketCap_USD")
    factors = read_factors()
    candidate_order, windows = read_universe()

    company_ticker = {}
    company_window = {}
    pre_price_exclusions = []
    for company in candidate_order:
        records = windows[company]
        tickers = [r["Bloomberg_ID"] for r in records if r["Bloomberg_ID"] not in (None, "")]
        ticker = str(tickers[0]) if tickers else None
        company_ticker[company] = ticker
        economic = {
            (r["Economic_Start"], r["Economic_End"])
            for r in records
            if r["Economic_Start"] is not None and r["Economic_End"] is not None
        }
        if ticker is None or ticker not in prices or not prices[ticker] or len(economic) != 1:
            pre_price_exclusions.append(company)
            continue
        company_window[company] = next(iter(economic))

    empirical_candidates = [c for c in candidate_order if c not in pre_price_exclusions]
    long_gap_exclusions = []
    for company in empirical_candidates:
        economic_start, economic_end = company_window[company]
        ticker = company_ticker[company]
        valid_dates = sorted(
            day for day, value in prices[ticker].items()
            if economic_start <= day <= economic_end and value > 0
        )
        maximum_gap = 0
        for left, right in zip(valid_dates[:-1], valid_dates[1:]):
            maximum_gap = max(maximum_gap, missing_weekdays_between(left, right))
        if maximum_gap >= LONG_GAP_WEEKDAYS:
            long_gap_exclusions.append(company)

    included = [c for c in empirical_candidates if c not in long_gap_exclusions]
    calendar = weekday_calendar(SAMPLE_START, SAMPLE_END)
    returns = {}
    daily_class = {}

    for company in included:
        economic_start, economic_end = company_window[company]
        ticker = company_ticker[company]
        raw = {
            day: value for day, value in prices[ticker].items()
            if economic_start <= day <= economic_end and value > 0
        }
        valid_dates = sorted(raw)
        company_returns = {day: None for day in calendar}
        classifications = {day: None for day in calendar}
        if valid_dates:
            first_valid, last_valid = valid_dates[0], valid_dates[-1]
            observed_returns = {
                day: raw[day] / raw[previous_day] - 1.0
                for previous_day, day in zip(valid_dates, valid_dates[1:])
            }
            for day in calendar:
                if day < first_valid or day > last_valid:
                    continue
                if day in observed_returns:
                    company_returns[day] = observed_returns[day]
                for window in windows[company]:
                    if (
                        window["Classification_Start"] is not None
                        and window["Classification_End"] is not None
                        and window["Classification_Start"] <= day <= window["Classification_End"]
                    ):
                        classifications[day] = window["Binary_Class"]
                        break
        returns[company] = company_returns
        daily_class[company] = classifications

    eligibility = {}
    eligibility_rows = []
    for company in included:
        economic_start, economic_end = company_window[company]
        ticker = company_ticker[company]
        for month in monthly_calendar(SAMPLE_START, SAMPLE_END):
            end = min(month_end(month), SAMPLE_END)
            active = any(
                month <= day <= end
                and economic_start <= day <= economic_end
                and daily_class[company][day] is not None
                for day in calendar
            )
            formation_date = None
            formation_value = None
            if active:
                if month == date(2015, 1, 1):
                    observations = sorted(
                        (day, value) for day, value in market_cap[ticker].items()
                        if day.weekday() < 5
                        and month <= day <= month_end(month)
                        and economic_start <= day <= economic_end
                        and value > 0
                    )
                    if observations:
                        formation_date, formation_value = observations[0]
                else:
                    prior = previous_month(month)
                    observations = sorted(
                        (day, value) for day, value in market_cap[ticker].items()
                        if day.weekday() < 5
                        and prior <= day <= month_end(prior)
                        and economic_start <= day <= economic_end
                        and value > 0
                    )
                    if observations:
                        formation_date, formation_value = observations[-1]
            passes = active and formation_value is not None and formation_value >= MCAP_THRESHOLD_USD_MN
            eligibility[(company, month)] = passes
            eligibility_rows.append([
                month, company, ticker, formation_date, formation_value, passes,
            ])

    daily_return_rows = [[day] + [returns[c][day] for c in included] for day in calendar]
    portfolio_rows = []
    portfolio_by_date = {}
    for day in calendar:
        month = month_start(day)
        ev_returns = []
        nonev_returns = []
        for company in included:
            if not eligibility[(company, month)]:
                continue
            value = returns[company][day]
            classification = daily_class[company][day]
            if value is None or classification is None:
                continue
            if classification == "EV":
                ev_returns.append(value)
            elif classification == "Non-EV":
                nonev_returns.append(value)
        ev_return = sum(ev_returns) / len(ev_returns) if ev_returns else None
        nonev_return = sum(nonev_returns) / len(nonev_returns) if nonev_returns else None
        ls_return = ev_return - nonev_return if ev_return is not None and nonev_return is not None else None
        values = {
            "EV_Return": ev_return,
            "NonEV_Return": nonev_return,
            "LS_Return": ls_return,
            "EV_Constituents": len(ev_returns),
            "NonEV_Constituents": len(nonev_returns),
        }
        portfolio_by_date[day] = values
        portfolio_rows.append([day, *values.values()])

    model_rows = []
    for day in sorted(set(portfolio_by_date) & set(factors)):
        portfolio = portfolio_by_date[day]
        factor = factors[day]
        if portfolio["EV_Return"] is None or portfolio["NonEV_Return"] is None:
            continue
        if any(factor[field] is None for field in FACTOR_FIELDS):
            continue
        model_rows.append([
            day,
            portfolio["EV_Return"], portfolio["NonEV_Return"], portfolio["LS_Return"],
            portfolio["EV_Return"] - factor["FF3_RF"],
            portfolio["NonEV_Return"] - factor["FF3_RF"],
            portfolio["EV_Return"] - factor["FF5_RF"],
            portfolio["NonEV_Return"] - factor["FF5_RF"],
            portfolio["EV_Constituents"], portfolio["NonEV_Constituents"],
            *[factor[field] for field in FACTOR_FIELDS],
        ])

    return {
        "candidate_order": candidate_order,
        "pre_price_exclusions": pre_price_exclusions,
        "long_gap_exclusions": long_gap_exclusions,
        "included": included,
        "daily_return_rows": daily_return_rows,
        "eligibility_rows": eligibility_rows,
        "portfolio_rows": portfolio_rows,
        "model_rows": model_rows,
    }


def validate_structure(result):
    assert len(result["candidate_order"]) == 54
    assert result["pre_price_exclusions"] == ["Lordstown Motors", "Iran Khodro", "SAIPA"]
    assert result["long_gap_exclusions"] == ["KG Mobility"]
    assert len(result["included"]) == 50
    assert result["daily_return_rows"][0][0] == SAMPLE_START
    assert result["daily_return_rows"][-1][0] == SAMPLE_END
    assert result["eligibility_rows"][-1][0] == date(2025, 12, 1)
    assert result["model_rows"][0][0] == date(2015, 1, 5)
    assert result["model_rows"][-1][0] == SAMPLE_END


def write_workbook(result):
    workbook = Workbook()
    workbook.remove(workbook.active)
    definitions = [
        ("Daily_Returns", ["Date", *result["included"]], result["daily_return_rows"]),
        ("Monthly_Eligibility", ["Month", "Company", "Bloomberg_ID", "MarketCap_Date", "MarketCap_USD_mn", "Pass_USD50m"], result["eligibility_rows"]),
        ("Daily_Portfolios", ["Date", "EV_Return", "NonEV_Return", "LS_Return", "EV_Constituents", "NonEV_Constituents"], result["portfolio_rows"]),
        ("Model_Input", [
            "Date", "EV_Return", "NonEV_Return", "LS_Return",
            "EV_Excess_FF3", "NonEV_Excess_FF3", "EV_Excess_FF5", "NonEV_Excess_FF5",
            "EV_Constituents", "NonEV_Constituents", *FACTOR_FIELDS,
        ], result["model_rows"]),
    ]
    for name, headers, rows in definitions:
        sheet = workbook.create_sheet(name)
        sheet.append(headers)
        for row in rows:
            sheet.append(row)
        for cell in sheet[1]:
            cell.number_format = "General"
        sheet.freeze_panes = "A2"
        if name == "Monthly_Eligibility":
            for cell in sheet["A"][1:]:
                cell.number_format = "yyyy-mm"
            for cell in sheet["D"][1:]:
                cell.number_format = "yyyy-mm-dd"
        else:
            for cell in sheet["A"][1:]:
                cell.number_format = "yyyy-mm-dd"
    workbook.save(OUTPUT)


def main():
    result = build_passenger_data()
    validate_structure(result)
    write_workbook(result)
    print(OUTPUT.name)


if __name__ == "__main__":
    main()
