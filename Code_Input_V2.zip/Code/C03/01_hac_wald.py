"""JBEM R2 Comment 3 — pooled HAC Wald structural-stability audit.

Requires: V2_2025_ObservedPriceOnly/FF5_Passenger_Data.xlsx.
The original FF5 V2 inputs are NOT altered. Reads the OOXML data sheet using stdlib
so the standalone computation does not depend on notebook state.

Outputs (in OUTPUT_DIR): baseline reproduction, Chow audit, pooled single-break
Wald tests, pooled three-regime Wald tests, regime coefficients and contrasts,
individual-factor Holm checks, HAC bandwidth sensitivity and run metadata.
"""
from __future__ import annotations
import json, zipfile, csv, re, hashlib
from collections import OrderedDict
from datetime import datetime, timedelta
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import f as f_dist
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[2]/'Output'/'C03'
SRC = Path(__file__).resolve().parents[2]/'Input'/'V2'/'FF5_Passenger_Data.xlsx'
OUT = ROOT
FF = ['Mkt-RF','SMB','HML','RMW','CMA','MOM']
B1 = pd.Timestamp('2020-03-11')
B2 = pd.Timestamp('2023-05-06')  # Saturday: effective first factor date is Mon 2023-05-08
LAGS = [5, 10, 22, 44]
NS = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'


def col_index(a1):
    s = re.match(r'[A-Z]+', a1).group()
    x=0
    for c in s: x=x*26+(ord(c)-64)
    return x-1


def read_model_input(path):
    """Use original XLSX's XML values; no forward filling or other transformations."""
    with zipfile.ZipFile(path) as z:
        book = ET.fromstring(z.read('xl/workbook.xml'))
        sheets = list(book.find(NS+'sheets'))
        model_sheet_id = [int(s.attrib['sheetId']) for s in sheets if s.attrib['name']=='Model_Input'][0]
        content = z.read(f'xl/worksheets/sheet{model_sheet_id}.xml')
    root=ET.fromstring(content)
    rows=[]
    for row in root.iter(NS+'row'):
        vals={}
        for cell in row.iter(NS+'c'):
            idx=col_index(cell.attrib['r'])
            v=cell.find(NS+'v')
            inline=cell.find(NS+'is')
            if inline is not None:
                txt=''.join(t.text or '' for t in inline.iter(NS+'t'))
                vals[idx]=txt
            elif v is not None:
                vals[idx]=v.text if cell.attrib.get('t')=='str' else float(v.text)
        rows.append(vals)
    headers=[rows[0].get(i) for i in range(max(rows[0])+1)]
    data=[]
    for row in rows[1:]:
        rec={headers[i]:row.get(i,np.nan) for i in range(len(headers))}
        val=rec['Date']
        if isinstance(val,(int,float)):
            rec['Date']=pd.Timestamp(datetime(1899,12,30)+timedelta(days=val))
        else: rec['Date']=pd.Timestamp(val)
        data.append(rec)
    frame=pd.DataFrame(data).set_index('Date').sort_index()
    needed={'LS_Return':'LS','FF5_Mkt_RF':'Mkt-RF','FF5_SMB':'SMB',
            'FF5_HML':'HML','RMW':'RMW','CMA':'CMA','MOM':'MOM'}
    df=frame[list(needed)].rename(columns=needed).dropna().copy()
    if not df.index.is_unique: raise ValueError('Duplicate Model_Input dates')
    if df.shape[0] != 2765: raise ValueError(f'Expected 2765 R1 dates, got {df.shape[0]}')
    if df.index.min()!=pd.Timestamp('2015-01-05') or df.index.max()!=pd.Timestamp('2025-12-31'):
        raise ValueError('Unexpected R1 date boundaries')
    return df


def ols_hac(y, X, lag=22):
    return sm.OLS(y, X).fit(cov_type='HAC', cov_kwds={'maxlags':lag})


def single_break_X(df,b):
    Z=df[FF]
    D=(df.index>=b).astype(float)
    X=pd.DataFrame(index=df.index)
    X['const']=1.0
    for k in FF: X[k]=Z[k].to_numpy()
    X['After:const']=D
    for k in FF: X['After:'+k]=D*Z[k].to_numpy()
    return X


def triple_regime_X(df):
    Z=df[FF]; d1=((df.index>=B1)&(df.index<B2)).astype(float)
    d2=(df.index>=B2).astype(float)
    X=pd.DataFrame(index=df.index); X['const']=1.0
    for f in FF:X[f]=Z[f].to_numpy()
    for reg,d in [('COVID',d1),('Post',d2)]:
        X[f'{reg}:const']=d
        for f in FF:X[f'{reg}:{f}']=d*Z[f].to_numpy()
    return X


def wald(model, label, terms, source, contrast=None, lag=22):
    # 'terms' : list of dict linear coefficient combos for null=0
    names=list(model.params.index); R=np.zeros((len(terms),len(names)))
    for i,combo in enumerate(terms):
        for name,val in combo.items():R[i,names.index(name)]+=val
    t=model.wald_test(R,scalar=True)
    statistic=float(np.asarray(t.statistic).item())
    p=float(np.asarray(t.pvalue).item())
    return dict(Analysis=source,Contrast=contrast or label,Test=label,HAC_Lags=lag,
                Wald_Chi2=statistic,df=len(terms),p_value=p,N=int(model.nobs),
                Reject_5pct=bool(p<0.05),Reject_1pct=bool(p<0.01))


def chows(df):
    F=[]; k=7
    full=sm.OLS(df.LS,sm.add_constant(df[FF],has_constant='add')).fit()
    rss0=float(np.square(full.resid).sum())
    for b in [B1,B2]:
        sub1=df.loc[df.index<b];sub2=df.loc[df.index>=b]
        res1=sm.OLS(sub1.LS,sm.add_constant(sub1[FF],has_constant='add')).fit()
        res2=sm.OLS(sub2.LS,sm.add_constant(sub2[FF],has_constant='add')).fit()
        num=(rss0-float(np.square(res1.resid).sum())-float(np.square(res2.resid).sum()))/k
        den=(float(np.square(res1.resid).sum())+float(np.square(res2.resid).sum()))/(len(df)-2*k)
        fstat=num/den
        F.append(dict(Breakpoint=str(b.date()),Test='Conventional Chow RSS F, reproduced R1',
                      Statistic=float(fstat),df1=k,df2=len(df)-2*k,p_value=float(f_dist.sf(fstat,k,len(df)-2*k)),
                      N_before=len(sub1),N_after=len(sub2),N=len(df)))
    return pd.DataFrame(F)


def contrast_terms(r1,r2,which):
    # r1 and r2: Pre/COVID/Post. Difference r2-r1, from pooled pre-coded model
    def comp(reg,f):
        if reg=='Pre':return {}
        return {f'{reg}:{f}':1.0}
    def diff(f):
        out=comp(r2,f).copy()
        for k,v in comp(r1,f).items():out[k]=out.get(k,0)-v
        return {k:v for k,v in out.items() if v!=0}
    factors={'Joint':['const',*FF],'Slopes':FF,'Intercept':['const']}[which]
    return [diff(f) for f in factors]


def estimate_contrasts(model):
    rows=[]; covariance=model.cov_params()
    for first,second in [('Pre','COVID'),('COVID','Post'),('Pre','Post')]:
        for f in ['const',*FF]:
            combo=contrast_terms(first,second,'Joint')[['const',*FF].index(f)]
            vec=pd.Series({n:0.0 for n in model.params.index})
            for k,v in combo.items():vec[k]+=v
            d=float(vec@model.params)
            se=float(np.sqrt(vec@covariance@vec))
            z=d/se
            from scipy.stats import norm
            p=2*norm.sf(abs(z))
            rows.append(dict(Contrast=f'{first} vs {second}',Variable='alpha' if f=='const' else f,
                             Change_Second_Minus_First=d,HAC_SE=se,z=z,p_value=p,
                             CI95_Lower=d-1.95996398454*se,CI95_Upper=d+1.95996398454*se))
    return pd.DataFrame(rows)


def run():
    df=read_model_input(SRC)
    assert df.notna().all().all()
    baseline=ols_hac(df.LS,sm.add_constant(df[FF],has_constant='add'))
    expected={'Mkt-RF':.6561,'SMB':.6947,'HML':-.6643,'RMW':-1.0308,'CMA':-.4051,'MOM':-.1408}
    for k,v in expected.items():
        if abs(float(baseline.params[k])-v)>0.000055:raise ValueError(f'V2 baseline mismatch {k}: {baseline.params[k]} != {v}')
    br=[]
    for k in baseline.params.index:
        br.append(dict(Variable='alpha' if k=='const' else k,Coefficient=float(baseline.params[k]),
                       HAC_SE=float(baseline.bse[k]),z=float(baseline.tvalues[k]),p_value=float(baseline.pvalues[k]),
                       N=int(baseline.nobs),Adj_R2=float(baseline.rsquared_adj)))
    baseline_df=pd.DataFrame(br)
    chow_df=chows(df)
    assert abs(chow_df.iloc[0].Statistic-3.1181)<0.0001 and abs(chow_df.iloc[1].Statistic-5.5911)<0.0001

    # Two distinct single-break pooled models replace the two old Chow RSS tests on exactly same dates.
    sb=[]; betas=[]
    for b in [B1,B2]:
        X=single_break_X(df,b)
        lag=22
        model=ols_hac(df.LS,X,lag)
        key=str(b.date())
        for name,fac in [('Joint', ['const',*FF]),('Slopes',FF),('Intercept',['const'])]:
            sb.append(wald(model,name,[{f'After:{k}':1} for k in fac],
                           f'Single-break pooled HAC Wald @ {key}',key,lag))
        for f in ['const',*FF]:
            par=f'After:{f}'
            betas.append(dict(Breakpoint=key,Variable='alpha' if f=='const' else f,
                              Change_After_Minus_Before=float(model.params[par]),
                              HAC_SE=float(model.bse[par]),z=float(model.tvalues[par]),
                              p_value=float(model.pvalues[par])))
    single_df=pd.DataFrame(sb)
    bcoef_df=pd.DataFrame(betas)

    # One pooled three-regime model, 21 parameters, 14 unrestricted regime shifts.
    X=triple_regime_X(df)
    triple=ols_hac(df.LS,X)
    if np.linalg.matrix_rank(X.to_numpy())!=21:raise ValueError('Regime design matrix not full rank')
    regrows=[]
    groups=[('Pre',df.index<B1),('COVID',(df.index>=B1)&(df.index<B2)),('Post',df.index>=B2)]
    for reg,mask in groups:
        model=ols_hac(df.loc[mask,'LS'],sm.add_constant(df.loc[mask,FF],has_constant='add'))
        for k in ['const',*FF]:
            pooled=float(triple.params[k]) + (float(triple.params[f'{reg}:{k}']) if reg!='Pre' else 0.0)
            estimate=float(model.params[k]);error=abs(pooled-estimate)
            if error>1e-9:raise ValueError(f'Pooled/separate differs {reg}/{k}: {error}')
            regrows.append(dict(Regime=reg,Variable='alpha' if k=='const' else k,
                                Coefficient=estimate,HAC_SE=float(model.bse[k]),
                                HAC_z=float(model.tvalues[k]),p_value=float(model.pvalues[k]),
                                N=int(model.nobs),R2=float(model.rsquared)))
    regime_df=pd.DataFrame(regrows)
    tests=[]
    for test in ['Joint','Slopes','Intercept']:
        fac={'Joint':['const',*FF],'Slopes':FF,'Intercept':['const']}[test]
        terms=[{f'{r}:{f}':1} for r in ['COVID','Post'] for f in fac]
        tests.append(wald(triple,test,terms,'Three-regime pooled HAC Wald','Global 3 regimes',22))
    for left,right in [('Pre','COVID'),('COVID','Post'),('Pre','Post')]:
        for name in ['Joint','Slopes','Intercept']:
            tests.append(wald(triple,name,contrast_terms(left,right,name),
                              'Three-regime pooled HAC Wald',f'{left} vs {right}',22))
    triple_tests=pd.DataFrame(tests)
    coef_contrasts=estimate_contrasts(triple)
    blocks=[]
    for label,group in coef_contrasts.groupby('Contrast',sort=False):
        slopes=group[group.Variable!='alpha'].copy()
        reject,padj,_,_=multipletests(slopes.p_value.to_numpy(),method='holm')
        for (_,row),p,r in zip(slopes.iterrows(),padj,reject):
            blocks.append({**row.to_dict(),'Holm_p_value':float(p),'Holm_Reject_5pct':bool(r),
                           'Multiple_Testing_Family':'6 factor-specific slope comparisons per contrast'})
    holm_df=pd.DataFrame(blocks)
    # HAC bandwidth sensitivity for all single-break and three-regime global & adjacent tests
    sensitivity=[]
    for lag in LAGS:
        tmod=ols_hac(df.LS,X,lag)
        for test in ['Joint','Slopes','Intercept']:
            fac={'Joint':['const',*FF],'Slopes':FF,'Intercept':['const']}[test]
            allterms=[{f'{r}:{f}':1} for r in ['COVID','Post'] for f in fac]
            sensitivity.append(wald(tmod,test,allterms,'Three-regime HAC lag sensitivity','Global 3 regimes',lag))
            for left,right in [('Pre','COVID'),('COVID','Post')]:
                sensitivity.append(wald(tmod,test,contrast_terms(left,right,test),
                                        'Three-regime HAC lag sensitivity',f'{left} vs {right}',lag))
        for b in [B1,B2]:
            sbmod=ols_hac(df.LS,single_break_X(df,b),lag)
            for test in ['Joint','Slopes','Intercept']:
                fac={'Joint':['const',*FF],'Slopes':FF,'Intercept':['const']}[test]
                sensitivity.append(wald(sbmod,test,[{f'After:{f}':1} for f in fac],
                                        'Single-break HAC lag sensitivity',str(b.date()),lag))
    sensitivity_df=pd.DataFrame(sensitivity)
    # explanatory timing and high-level run metadata
    metadata={
        'input_file':str(SRC.relative_to(Path(__file__).resolve().parents[2])) if SRC.is_relative_to(Path(__file__).resolve().parents[2]) else str(SRC),'input_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
        'n_obs':len(df),'first_date':str(df.index.min().date()),'last_date':str(df.index.max().date()),
        'breakpoints_nominal':[str(B1.date()),str(B2.date())],
        'breakpoints_first_observed_post':[str(df.index[df.index>=b].min().date()) for b in [B1,B2]],
        'regime_counts':{reg:int(np.count_nonzero(mask)) for reg,mask in groups},
        'model':'LS = EV_Return - NonEV_Return, FF5+MOM daily, US USD factors',
        'regressor_names':FF,'inference':'statsmodels OLS with HAC/Newey-West Bartlett maxlags=22, no small-sample correction; Wald asymptotic chi-square',
        'cov_type':'HAC','hac_default_lags':22,
        'HAC_sensitivity':LAGS,'break_dates_pre_specified':True,
        'decision_rule':'Two-sided / joint Wald tests at alpha=.05; explanatory, not causal',
        'predecessor_test':'R1 Chow RSS F not HAC robust; kept as reference, replaced for inference',
        'external_stability_sources':'none required; all market/factor inputs unchanged from R1 V2',
        'baseline_coefficients':{k:float(v) for k,v in baseline.params.items()}
    }
    tables={'Baseline_Reproduction':baseline_df,'Original_Chow_Audit':chow_df,
            'Single_Break_Wald':single_df,'Single_Break_Deltas':bcoef_df,
            'Three_Regime_Wald':triple_tests,'Regime_Coefficients':regime_df,
            'Pairwise_Deltas':coef_contrasts,'Factor_Holm':holm_df,
            'HAC_Lag_Sensitivity':sensitivity_df}
    for name,table in tables.items():table.to_csv(OUT/f'{name}.csv',index=False,float_format='%.12g')
    (OUT/'run_metadata.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False),encoding='utf-8')
    print('BASELINE');print(baseline_df.to_string(index=False))
    print('\nCHOW');print(chow_df.to_string(index=False))
    print('\nSINGLE BREAK');print(single_df.to_string(index=False))
    print('\nTRIPLE BREAKS');print(triple_tests.to_string(index=False))
    print('\nPAIRWISE FACTOR HOLM');print(holm_df[['Contrast','Variable','Change_Second_Minus_First','p_value','Holm_p_value']].to_string(index=False))
    print('\nREGIME COUNTS:',metadata['regime_counts'])
    print('OUTPUT',OUT)
    return tables,metadata

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description='R2 Comment 3 HAC pooled Wald reproducibility check')
    parser.add_argument('--input', default=str(SRC), help='Path to FF5_Passenger_Data.xlsx (V2)')
    parser.add_argument('--output', default=str(OUT), help='Directory for CSV/JSON outputs')
    args=parser.parse_args()
    SRC=Path(args.input).resolve()
    OUT=Path(args.output).resolve()
    OUT.mkdir(parents=True,exist_ok=True)
    run()
