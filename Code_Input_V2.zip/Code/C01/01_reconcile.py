from pathlib import Path
import pandas as pd
import numpy as np
import statsmodels.api as sm
from ff5_rapid_xml import as_records,serial_to_date
ROOT=Path(__file__).resolve().parents[2]; P=ROOT/'Input'/'R0'; V=ROOT/'Input'/'V2'; O=ROOT/'Output'/'C01'/'Bridge'; O.mkdir(parents=True,exist_ok=True)
FACTORS=['Mkt-RF','SMB','HML','RMW','CMA','Mom']; DROP={'ZEVY','WKHS','GP','EZGO','EBUS.AS','GGR','CENN','LOT'}
START='2015-01-05'; END='2025-11-28'
def load_ff(name):
    d=pd.read_csv(P/name,index_col=0);d.index=pd.to_datetime(d.index.astype(str),format='%Y%m%d',errors='coerce'); return d.loc[d.index.notna()].apply(pd.to_numeric,errors='coerce')/100
f3,f5,mom=map(load_ff,['ff3.csv','ff5.csv','Mom.csv']); f0=f5.join(mom)[FACTORS]
fv0=pd.DataFrame(as_records(V/'FF5_Factor_Data.xlsx','Daily_Factors'));fv0.index=pd.to_datetime(fv0.Date.map(serial_to_date)); fv=fv0[['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','MOM']].copy(); fv.columns=FACTORS
rows=[]
for family,old,new,fields in [('FF3',f3,fv0,['FF3_Mkt_RF','FF3_SMB','FF3_HML','FF3_RF']),('FF5',f5,fv0,['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','FF5_RF']),('MOM',mom,fv0,['MOM'])]:
    idx=old.index.intersection(new.index); idx=idx[(idx>=START)&(idx<=END)];
    for c,n in zip(old.columns,fields):
        e=(old.loc[idx,c]-new.loc[idx,n]).abs();rows.append([family,c,len(idx),int((e<1e-12).sum()),float(e.mean()),float(e.max())])
pd.DataFrame(rows,columns=['Family','Factor','N','Exact','Mean_abs_diff','Max_abs_diff']).to_csv(O/'Factor_vintage_comparison.csv',index=False)
raw={};filtered={};saved={};audit=[];qa=[];coverage=[]
for k in ['ev','nonev']:
    q=pd.read_csv(P/f'{k}_adj_close_2015_2025.csv',index_col='Date',parse_dates=True);raw[k]=q; filtered[k]=q.loc[q.index.isin(f5.index)].dropna(axis=1,how='all').drop(columns=list(DROP),errors='ignore');
    for c in q:
        z=q[c].dropna(); audit.append([k,c,len(z),str(z.index.min().date()) if len(z) else '',str(z.index.max().date()) if len(z) else '',c in filtered[k].columns,'explicit exclusion' if c in DROP else 'all missing' if c not in filtered[k].columns else 'included'])
    a=filtered[k];historical=a.ffill().pct_change(fill_method=None).fillna(0);calc=(1+historical.mean(axis=1)).cumprod()*100
    orig=pd.read_csv(P/f'{k}_equal_weight_index_100.csv',index_col='Date',parse_dates=True).Index
    assert orig.index.equals(calc.index); assert (orig-calc).abs().max()<1e-9
    qa.append([k,len(calc),len(q.columns),len(a.columns),int(a.iloc[0].notna().sum()),float((orig-calc).abs().max())]); saved[k]=orig.pct_change(fill_method=None)
    filled_counts=a.ffill().notna().sum(axis=1)
    for d in a.index:
        coverage.append([k,d,len(a.columns),int(a.loc[d].notna().sum()),int(filled_counts.loc[d])])
pd.DataFrame(audit,columns=['Leg','Ticker','Observed_prices','First_price','Last_price','Included_R0','Status']).to_csv(O/'R0_constituents.csv',index=False)
pd.DataFrame(qa,columns=['Leg','Index_days','Original_columns','Included_columns','Observed_at_initial_date','Max_abs_index_error']).to_csv(O/'Index_replication.csv',index=False)
pd.DataFrame(coverage,columns=['Leg','Date','R0_denominator','Observed_prices','Forward_filled_prices']).to_csv(O/'Daily_coverage.csv',index=False)
results=[];daily={}
def reg(label,es,ns,fs,bridge=False):
    d=pd.concat([es.rename('EV'),ns.rename('NonEV'),fs],axis=1,join='inner').dropna();d['LS']=d.EV-d.NonEV
    m=sm.OLS(d.LS,sm.add_constant(d[FACTORS])).fit(cov_type='HAC',cov_kwds={'maxlags':22})
    r=dict(Scenario=label,Bridge=bridge,N=len(d),Start=d.index.min().date(),End=d.index.max().date(),Adj_R2=m.rsquared_adj)
    for col in m.params.index:r[col]=m.params[col];r[col+'_p']=m.pvalues[col]
    results.append(r);daily[label]=d.LS;return r
reg('R0_exact',saved['ev'],saved['nonev'],f0,True)
reg('R0_R1_factor_vintage',saved['ev'],saved['nonev'],fv,True)
for mode in ['ffill_available','observed_consecutive','observed_previous','observed_previous_native_calendar']:
    rr={}
    for k,a in filtered.items():
        if mode=='ffill_available':r=a.ffill().pct_change(fill_method=None)
        elif mode=='observed_consecutive':r=a.pct_change(fill_method=None)
        elif mode=='observed_previous':r=a.apply(lambda s:s.dropna().pct_change(fill_method=None)).reindex(a.index)
        else:r=raw[k][a.columns].apply(lambda s:s.dropna().pct_change(fill_method=None)).reindex(a.index)
        rr[k]=r.mean(axis=1).loc[START:END]
    reg(mode,rr['ev'],rr['nonev'],fv,mode in ['ffill_available','observed_previous'])
for universe,name in [('broad','FF5_Broad_Data.xlsx'),('passenger','FF5_Passenger_Data.xlsx')]:
    d=pd.DataFrame(as_records(V/name,'Model_Input'));d.index=pd.to_datetime(d.Date.map(serial_to_date));
    reg('R1_'+universe+'_November',d.EV_Return.loc[:END],d.NonEV_Return.loc[:END],fv,True)
    reg('R1_'+universe+'_December',d.EV_Return,d.NonEV_Return,fv,universe=='passenger')
r=pd.DataFrame(results);r.to_csv(O/'Regressions.csv',index=False)
b=r[r.Bridge].copy();b['Delta_beta']=b['Mkt-RF'].diff(); b.to_csv(O/'Sequential_bridge.csv',index=False)
pd.DataFrame(daily).to_csv(O/'Daily_LS_series.csv',index_label='Date')
print(b[['Scenario','N','Mkt-RF','Delta_beta','Mkt-RF_p','HML','RMW']].to_string(index=False))
