from zipfile import ZipFile
import xml.etree.ElementTree as ET
import posixpath,re,datetime,math
N={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
X='http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def get_rows(path,sheet):
  with ZipFile(path) as z:
    wb=ET.fromstring(z.read('xl/workbook.xml')); rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    rid={p.attrib['Id']:p.attrib['Target'] for p in rels}
    entry=next(a for a in wb.find('m:sheets',N) if a.attrib['name']==sheet)
    rel=rid[entry.attrib['{%s}id'%N['r']]]
    target=rel.lstrip('/') if rel.startswith('/') else posixpath.normpath('xl/'+rel)
    ss=[]
    if 'xl/sharedStrings.xml' in z.namelist():
      root=ET.fromstring(z.read('xl/sharedStrings.xml'))
      for item in root:
        ss.append(''.join(x.text or '' for x in item.iter('{'+X+'}t')))
    with z.open(target) as xml:
      for _, row in ET.iterparse(xml, events=('end',)):
        if row.tag!='{%s}row'%X: continue
        res={}
        for cell in row.findall('m:c',N):
          addr=cell.attrib.get('r',''); mat=re.match('[A-Z]+',addr)
          if not mat: continue
          idx=0
          for ch in mat.group():idx=idx*26+ord(ch)-64
          typ=cell.attrib.get('t')
          ve=cell.find('m:v',N)
          if ve is None:
            if typ=='inlineStr':
              res[idx]=''.join((t.text or '') for t in cell.findall('.//m:t',N))
            continue
          s=ve.text
          if typ=='s': val=ss[int(s)]
          elif typ in ('str','e'): val=s
          elif typ=='b':val=s=='1'
          else:
            try:val=float(s)
            except (TypeError,ValueError):val=s
          res[idx]=val
        if res:yield int(row.attrib['r']),res
        row.clear()

def as_records(path,sheet):
  it=get_rows(path,sheet); _,header=next(it)
  cols={idx:str(v).strip() for idx,v in header.items()}
  for rownum,items in it:
    yield dict((key,items.get(idx)) for idx,key in cols.items())

def serial_to_date(x): return (datetime.datetime(1899,12,30)+datetime.timedelta(days=x)).date() if isinstance(x,(float,int)) else datetime.date.fromisoformat(str(x)[:10])
if __name__=='__main__':
 from pathlib import Path
 for fname,sh in [('FF5_Passenger_Data.xlsx','Model_Input'),('FF5_Passenger_Results.xlsx','Frequency_Robustness')]:
  print('\n',fname,sh)
  it=as_records(str(Path(__file__).resolve().parents[2] / 'Input' / 'V2' / fname),sh)
  for _ in range(4):print(next(it))
