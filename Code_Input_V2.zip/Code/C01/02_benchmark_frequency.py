from pathlib import Path
import csv,re,zipfile,hashlib,sys,subprocess,tempfile
import pandas as pd,numpy as np,statsmodels.api as sm
R=Path(__file__).resolve().parents[2]; I=R/'Input'; O=R/'Output'/'C01'; FOUT=R/'Output'/'C04'; O.mkdir(parents=True,exist_ok=True); FOUT.mkdir(parents=True,exist_ok=True)
K=['Mkt-RF','SMB','HML','RMW','CMA','MOM'];fs={};prov=[]
for p in sorted((I/'Factors').glob('*.zip')):
 n=p.name.lower();b='US' if n.startswith('f-f_') else 'Developed ex US' if 'ex_us' in n else 'Developed';freq='Daily' if 'daily' in n else 'Monthly';fam='MOM' if 'mom' in n else 'FF5' if '5_factors' in n else 'FF3';cols={'FF3':K[:3]+['RF'],'FF5':K[:5]+['RF'],'MOM':['MOM']}[fam]
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None;member=z.namelist()[0];txt=z.read(member).decode('utf-8-sig')
 lines=[];header=[];started=False
 for row in csv.reader(txt.splitlines()):
  if row and re.fullmatch(r'\d{'+('8' if freq=='Daily' else '6')+'}',row[0].strip()):
   started=True;lines.append([row[0].strip(),*[float(x) for x in row[1:len(cols)+1]]])
  elif not started:header.append(','.join(row))
 d=pd.DataFrame(lines,columns=['Date']+cols);d.index=pd.to_datetime(d.pop('Date'),format='%Y%m%d' if freq=='Daily' else '%Y%m');d=d.replace([-99.99,-999],np.nan)/100;assert d.index.is_unique and d.index.is_monotonic_increasing;assert (b,freq,fam) not in fs;fs[b,freq,fam]=d;w=d.loc['2015':'2025'];prov.append(dict(Benchmark=b,Frequency=freq,Family=fam,Archive=p.name,Member=member,Header=' | '.join(x for x in header if x.strip()),SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),Start=d.index.min().date(),End=d.index.max().date(),N_2015_2025=len(w),Missing_cells=int(w.isna().sum().sum()),Vintage='202609',Original_download_date='Not documented',Receipt_date='2026-11-24'))
assert len(fs)==18;pd.DataFrame(prov).to_csv(O/'Factor_Provenance.csv',index=False)
def sheet(n,s):return pd.read_excel(I/'V2'/n,sheet_name=s)
def idx(d):return d.assign(Date=pd.to_datetime(d.Date)).set_index('Date').sort_index()
m=idx(sheet('FF5_Passenger_Data.xlsx','Model_Input'));broad=idx(sheet('FF5_Broad_Data.xlsx','Model_Input'));frozen=idx(sheet('FF5_Factor_Data.xlsx','Daily_Factors'));checks=[]
for fam,cols in [('FF3',['FF3_Mkt_RF','FF3_SMB','FF3_HML','FF3_RF']),('FF5',['FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','FF5_RF']),('MOM',['MOM'])]:
 us=fs['US','Daily',fam]
 for c,k in zip(cols,us.columns):
  for label,d in [('R1 regression',m),('V2 factor workbook',frozen)]:
   ix=d.index.intersection(us.index);delta=(d.loc[ix,c]-us.loc[ix,k]).abs();checks.append(dict(Sample=label,Family=fam,Factor=c,N=len(ix),Exact=int((delta<1e-12).sum()),Max_abs_difference=delta.max(),Mean_abs_difference=delta.mean()))
  assert np.allclose(m[c],us.loc[m.index,k],atol=1e-12,rtol=0)
pd.DataFrame(checks).to_csv(O/'US_Provenance_Verification.csv',index=False)
r=idx(sheet('FF5_Passenger_Data.xlsx','Daily_Returns'));e=sheet('FF5_Passenger_Data.xlsx','Monthly_Eligibility');e['Month']=pd.to_datetime(e.Month);e=e.pivot(index='Month',columns='Company',values='Pass_USD50m').reindex(columns=r.columns);e=e.reindex(r.index.to_period('M').to_timestamp()).set_axis(r.index).fillna(False).astype(bool)
u=sheet('FF5_Universe_Definitions.xlsx','Passenger_Universe');g=pd.read_csv(I/'geography_mapping.csv').set_index('Company');assert set(g.index)==set(r.columns);g=g.join(u.groupby('Company').Bloomberg_ID.first().rename('Bloomberg_ID'));g['Status']='Provisional issuer-country proxy; not vendor constituent verification';g['Listing_code']=g.Bloomberg_ID.str.split().str[1];g.to_csv(O/'Geography_Mapping.csv')
cl=pd.DataFrame('',index=r.index,columns=r.columns)
for x in u.itertuples():
 if x.Company in cl:
  dates=(cl.index>=max(pd.Timestamp(x.Classification_Start),pd.Timestamp(x.Economic_Start))) & (cl.index<=min(pd.Timestamp(x.Classification_End),pd.Timestamp(x.Economic_End)));assert (cl.loc[dates,x.Company]=='').all();cl.loc[dates,x.Company]=x.Binary_Class
ports={};sizes={}
for label,names in [('Full Passenger',list(r)),('Developed-covered',g.index[g.Covered].tolist()),('Covered + Lotus sensitivity',g.index[g.Covered | (g.index=='Lotus Technology')].tolist())]:
 rr=r[names].where(e[names]);ev=rr.where(cl[names]=='EV');ne=rr.where(cl[names]=='Non-EV');ports[label]=pd.DataFrame({'EV':ev.mean(axis=1),'NonEV':ne.mean(axis=1),'EV_n':ev.count(axis=1),'NonEV_n':ne.count(axis=1)});ports[label]['LS']=ports[label].EV-ports[label].NonEV;sizes[label]=len(names)
for k,c in [('EV','EV_Return'),('NonEV','NonEV_Return'),('LS','LS_Return')]:assert np.allclose(ports['Full Passenger'].loc[m.index,k],m[c],rtol=0,atol=1e-10)
assert (ports['Full Passenger'].loc[m.index,'EV_n']==m.EV_Constituents).all();assert (ports['Full Passenger'].loc[m.index,'NonEV_n']==m.NonEV_Constituents).all()
ports['R1 Broad']=broad.rename(columns={'EV_Return':'EV','NonEV_Return':'NonEV','LS_Return':'LS','EV_Constituents':'EV_n','NonEV_Constituents':'NonEV_n'})[['EV','NonEV','LS','EV_n','NonEV_n']];sizes['R1 Broad']=np.nan
allp=ports['Full Passenger'];cov=ports['Developed-covered'];share=pd.DataFrame({'EV_outside':1-cov.loc[m.index,'EV_n']/allp.loc[m.index,'EV_n'],'NonEV_outside':1-cov.loc[m.index,'NonEV_n']/allp.loc[m.index,'NonEV_n']});share.groupby(share.index.year).mean().to_csv(O/'Geography_Annual_Outside_Share.csv')
bms=['US','Developed','Developed ex US'];models=['FF3','FF5','FF5+MOM']
def factors(b,freq,model):
 d=fs[b,freq,'FF3' if model=='FF3' else 'FF5'].copy();return d.join(fs[b,freq,'MOM'],how='inner') if model=='FF5+MOM' else d
common=m.index
for b in bms:
 for model in models:common=common.intersection(factors(b,'Daily',model).dropna().index)
for p in ports.values():common=common.intersection(p.dropna(subset=['LS']).index)
assert common.equals(m.index);rows=[];diag=[];qa=[]
def fit(y,f,b,u,period,model,leg,freq,con,cal,hac):
 z=pd.concat([y.rename('y'),f],axis=1,join='inner').dropna();cols=[k for k in K if k in f];a=sm.OLS(z.y,sm.add_constant(z[cols])).fit(cov_type='HAC',cov_kwds={'maxlags':hac},use_t=False);ci=a.conf_int()
 for k in a.params.index:rows.append(dict(Frequency=freq,Calendar=cal,Construction=con,Period=period,Universe=u,Benchmark=b,Model=model,Leg=leg,HAC=hac,Factor=k,Beta=a.params[k],SE=a.bse[k],t=a.tvalues[k],p=a.pvalues[k],CI_low=ci.loc[k,0],CI_high=ci.loc[k,1],N=len(z),Start=z.index.min(),End=z.index.max(),Adj_R2=a.rsquared_adj,Factor_SD=z[k].std() if k!='const' else np.nan,Loading_x_factor_SD=a.params[k]*z[k].std() if k!='const' else np.nan))
for period,ix in [('2015-2025',common),('2021-2025',common[common.year>=2021])]:
 for u,p in ports.items():
  q=p.loc[ix];diag.append(dict(Period=period,Universe=u,N=len(q),Universe_firms=sizes[u],Mean_EV=q.EV_n.mean(),Mean_NonEV=q.NonEV_n.mean(),Min_EV=q.EV_n.min(),Min_NonEV=q.NonEV_n.min()))
  for b in bms:
   for model in models:
    f=factors(b,'Daily',model).loc[ix]
    for leg in ['EV','NonEV','LS']:fit(q[leg]-(f.RF if leg!='LS' else 0),f,b,u,period,model,leg,'Daily','Raw spread / excess legs','R1 common dates',22)
for u,p in ports.items():
 for cal,q in [('R1 common dates',p.loc[common]),('Full paired observed dates',p.dropna(subset=['EV','NonEV']))]:
  if u=='R1 Broad' and cal!='R1 common dates':continue
  for freq,rule,hac in [('Weekly','W-FRI',5),('Monthly','MS',3)]:
   ev=(1+q.EV).resample(rule).prod(min_count=1)-1;ne=(1+q.NonEV).resample(rule).prod(min_count=1)-1;direct=(1+q.LS).resample(rule).prod(min_count=1)-1;ys={'Separate legs':ev-ne,'Direct compounded LS':direct}
   qa.append(dict(Universe=u,Calendar=cal,Frequency=freq,Daily_N=len(q),Period_N=len(ev.dropna()),Mean_abs_LS_difference=(ys['Separate legs']-direct).abs().mean(),Max_abs_LS_difference=(ys['Separate legs']-direct).abs().max()))
   for b in bms:
    fd=factors(b,'Daily','FF5+MOM').reindex(q.index).dropna()
    if cal=='Full paired observed dates':fd=factors(b,'Daily','FF5+MOM').loc['2015':'2025'].dropna()
    su=fd[K].resample(rule).sum(min_count=1);hy=su.copy();hy['Mkt-RF']=(1+fd['Mkt-RF']+fd.RF).resample(rule).prod(min_count=1)-(1+fd.RF).resample(rule).prod(min_count=1);comp=(1+fd[K]).resample(rule).prod(min_count=1)-1
    fsets={'Official monthly':factors(b,'Monthly','FF5+MOM')} if freq=='Monthly' else {}
    if cal=='R1 common dates' or freq=='Weekly':fsets.update({'Hybrid approximation':hy,'Daily sums':su,'Direct factor compounding':comp})
    for typ,f in fsets.items():
     for con,y in ys.items():fit(y,f,b,u,'2015-2025','FF5+MOM','LS',freq,con+' | '+typ,cal,hac)
res=pd.DataFrame(rows);res[res.Frequency=='Daily'].to_csv(O/'Regression_Results.csv',index=False);res[res.Frequency!='Daily'].to_csv(FOUT/'Benchmark_Frequency_Regressions.csv',index=False);pd.DataFrame(diag).to_csv(O/'Sample_Diagnostics.csv',index=False);pd.DataFrame(qa).to_csv(FOUT/'Frequency_Construction_QA.csv',index=False)
for u,p in ports.items():p.to_csv(O/('Returns_'+u.replace(' ','_')+'.csv'))
subprocess.run([sys.executable,str(R/'Code/C01/01_reconcile.py')],check=True,cwd=R)
sel=res[(res.Leg=='LS') & (res.Model=='FF5+MOM') & (res.Factor.isin(['Mkt-RF','HML','RMW'])) & (res.Universe.isin(['Full Passenger','Developed-covered'])) & (res.Calendar=='R1 common dates') & ((res.Frequency=='Daily')|res.Construction.eq('Separate legs | Official monthly')|((res.Frequency=='Weekly') & res.Construction.eq('Separate legs | Hybrid approximation')))];sel[sel.Frequency=='Daily'].to_csv(O/'Key_Results.csv',index=False);sel[sel.Frequency!='Daily'].to_csv(FOUT/'Key_Results.csv',index=False)
print('Outside mean',share.mean().to_dict());print('Regressions',len(res.groupby(['Frequency','Calendar','Construction','Period','Universe','Benchmark','Model','Leg','HAC'])));print(sel[['Frequency','Period','Universe','Benchmark','Factor','Beta','p','N','Adj_R2']].to_string(index=False))
