def main():
    source=BASE / 'FF5_Portfolio_Robustness_frozen.xlsx'
    sheets={k:pd.read_excel(source,sheet_name=k) for k in ['Active_Constituents','Universe_Restriction','Daily_Robustness']}
    model_input=pd.read_excel(PASSENGER_DATA,sheet_name='Model_Input')
    model_input['Date']=pd.to_datetime(model_input['Date'])
    daily=sheets['Daily_Robustness'].set_index('Date')
    factors=factor_sets(model_input)
    rows=[]
    for ev,ne,label in [('EV_EW','NonEV_EW','Passenger EW baseline'),('EV_Restricted','NonEV_Restricted','Passenger EW — exclude Economic_Start after 2020-12-31'),('EV_VW','NonEV_VW','Passenger VW baseline — strict lagged USD market cap')]:
        rows+=regress_three_models(daily[ev],daily[ne],factors,label)
    workbook=Workbook();workbook.remove(workbook.active)
    for name,frame in sheets.items():write_sheet(workbook,name,frame)
    write_sheet(workbook,'Robustness_Models',pd.DataFrame(rows));workbook.save(OUTPUT)
    print(OUTPUT.name)


if __name__ == '__main__':
    main()
