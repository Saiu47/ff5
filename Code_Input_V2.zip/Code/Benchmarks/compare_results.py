from pathlib import Path
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'Output';ALT=OUT/'Alternative_Benchmarks';CMP=ALT/'Comparison';CMP.mkdir(parents=True,exist_ok=True)
SOURCES={'US':OUT,'Developed':ALT/'Developed','Developed ex US':ALT/'Developed_ex_US'}

def add_benchmark(d,b):
    d=d.copy();d.insert(0,'Benchmark',b);return d

def collect_csv(name,rel):
    frames=[add_benchmark(pd.read_csv(root/rel),b) for b,root in SOURCES.items()]
    x=pd.concat(frames,ignore_index=True);x.to_csv(CMP/f'{name}.csv',index=False);return x

def collect_excel(name,rel,sheet,select=None):
    frames=[]
    for b,root in SOURCES.items():
        d=pd.read_excel(root/rel,sheet_name=sheet)
        if select is not None:d=d.loc[select(d)]
        frames.append(add_benchmark(d,b))
    x=pd.concat(frames,ignore_index=True);x.to_csv(CMP/f'{name}.csv',index=False);return x

for u in ['Passenger','Broad']:
    for sheet in ['Main_Models','Descriptives','Diagnostics','Regime_Models','HAC_Sensitivity','Rolling_Models']:
        collect_excel(f'{u}_{sheet}',f'Base/FF5_{u}_Results.xlsx',sheet,(lambda d:d.Record_Type.eq('Summary')) if sheet=='Rolling_Models' else None)
collect_excel('Portfolio_Robustness','Base/FF5_Portfolio_Robustness.xlsx','Robustness_Models')
for sheet in ['State_Models','Interactions','Joint_Tests','Marginal_Loadings','Commodity_Controls']:
    collect_excel(sheet,'Base/FF5_State_Dependent_Models.xlsx',sheet)
for c,files in {'C02':['Matching_Models','Leave_One_Out'],'C03':['Single_Break_Wald','Three_Regime_Wald','Regime_Coefficients','Pairwise_Deltas','Factor_Holm','HAC_Lag_Sensitivity'],'C05':['scenario_regressions','ev_leave_one_out','loo_fixed_2021_2025','tata_event_regressions','canoo_taxonomy_sensitivity','Conditional_RIDE_FF5_MOM_HAC22']}.items():
    for name in files:collect_csv(c+'_'+name,f'{c}/{name}.csv')
# Corrected frequency comparisons already published together in C01/C04, copy without changing original.
f=pd.read_csv(OUT/'C04/Benchmark_Frequency_Regressions.csv');f.to_csv(CMP/'C04_Benchmark_Frequency_Regressions.csv',index=False)
# The direct and corrected constructions and HAC bandwidth sensitivity for all daily benchmarks.
for name in ['Frequency_Regressions','HAC_Lag_Sensitivity']:collect_csv('C04_'+name,f'C04/{name}.csv')
# Select one compact data-only table of core FF5+MOM estimates for the same portfolio, without commentary.
main=pd.read_csv(CMP/'Passenger_Main_Models.csv');main=main[(main.Record_Type=='Coefficient')&(main.Model=='FF5+MOM')&(main.Portfolio=='LS')];rows=[]
for r in main.itertuples():rows.append(dict(Benchmark=r.Benchmark,Analysis='Baseline',Scenario='Passenger EW',Factor=r.Variable,Coefficient=r.Coefficient,p_value=r.p_value,N=r.N,Adj_R2=r.Adj_R2))
rob=pd.read_csv(CMP/'Portfolio_Robustness.csv');rob=rob[(rob.Model=='FF5+MOM')&(rob.Portfolio=='LS')&~rob.Specification.eq('Passenger EW baseline')]
for r in rob.itertuples():rows.append(dict(Benchmark=r.Benchmark,Analysis='Portfolio construction',Scenario=r.Specification,Factor=r.Variable,Coefficient=r.Coefficient,p_value=r.p_value,N=r.N,Adj_R2=r.Adj_R2))
mat=pd.read_csv(CMP/'C02_Matching_Models.csv');mat=mat[(mat.Model=='FF5+MOM')&(mat.Portfolio=='LS')&(mat.Type!='Unmatched_Full')]
for r in mat.itertuples():rows.append(dict(Benchmark=r.Benchmark,Analysis='Matching',Scenario=r.Design+' | '+r.Type,Factor=r.Variable,Coefficient=r.Coefficient,p_value=r.p_value,N=r.N,Adj_R2=r.Adj_R2))
f=f[(f.Universe=='Full Passenger')&(f.Calendar=='R1 common dates')&f.Construction.isin(['Separate legs | Official monthly','Separate legs | Hybrid approximation'])&((f.Frequency=='Weekly')|f.Construction.eq('Separate legs | Official monthly'))]
for r in f.itertuples():rows.append(dict(Benchmark=r.Benchmark,Analysis='Frequency',Scenario=r.Frequency+' | '+r.Construction,Factor=r.Factor,Coefficient=r.Beta,p_value=r.p,N=r.N,Adj_R2=r.Adj_R2))
sc=pd.read_csv(CMP/'C05_scenario_regressions.csv');sc=sc[sc.Comparison=='scenario']
for _,r in sc.iterrows():
    for factor in ['const','Mkt-RF','SMB','HML','RMW','CMA','MOM']:rows.append(dict(Benchmark=r.Benchmark,Analysis='Sample sensitivity',Scenario=r.Scenario,Factor='alpha' if factor=='const' else factor,Coefficient=r[factor],p_value=r['p_'+factor],N=r.n,Adj_R2=r.adj_r2))
pd.DataFrame(rows).to_csv(CMP/'Key_Coefficients.csv',index=False)
# Verify each selected analysis has identical sample counts across geographies.
k=pd.DataFrame(rows);cnt=k.groupby(['Analysis','Scenario','Factor']).agg(Benchmarks=('Benchmark','nunique'),N_versions=('N','nunique'));assert cnt.Benchmarks.eq(3).all() and cnt.N_versions.eq(1).all()
print('Comparison tables generated:',len(list(CMP.glob('*.csv'))),'Key coefficients:',len(k))
