from pathlib import Path
import sys
import pandas as pd
import numpy as np
import statsmodels.api as sm
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from run_alternative_benchmarks import parse,LABELS
OUT=ROOT/'Output'; ALT=OUT/'Alternative_Benchmarks'; CMP=ALT/'Comparison'
K=['Mkt-RF','SMB','HML','RMW','CMA','MOM']
source=pd.read_csv(OUT/'C04/Monthly_Aligned.csv');source.index=pd.to_datetime(source.Period)
rows=[]
for b,label in LABELS.items():
    f=parse(b,False).rename(columns={'FF5_Mkt_RF':'Mkt-RF','FF5_SMB':'SMB','FF5_HML':'HML'})[K].reindex(source.index);assert f.notna().all().all()
    for dep in ['LS_DirectCompounded','LS_SeparateLegs']:
        for lag in [0,1,2,3,6]:
            a=sm.OLS(source[dep],sm.add_constant(f)).fit(cov_type='HAC',cov_kwds={'maxlags':lag,'use_correction':False});ci=a.conf_int()
            for k in a.params.index:rows.append(dict(Benchmark=label,LS_Definition=dep,HAC_Lags=lag,Factor='alpha' if k=='const' else k,Coefficient=a.params[k],HAC_SE=a.bse[k],p_value=a.pvalues[k],CI95_Lower=ci.loc[k,0],CI95_Upper=ci.loc[k,1],N=int(a.nobs),Adj_R2=a.rsquared_adj))
r=pd.DataFrame(rows);r.to_csv(CMP/'Official_Monthly_HAC_Sensitivity.csv',index=False)
for b,label in LABELS.items():
    if b=='US':continue
    orig=pd.read_csv(ALT/b/'C04/Monthly_Official_Factor_Results.csv');d=r[r.Benchmark==label].merge(orig,on=['LS_Definition','HAC_Lags','Factor'],validate='one_to_one');assert len(d)==70;assert np.allclose(d.Coefficient_x,d.Coefficient_y,rtol=0,atol=1e-10);assert np.allclose(d.p_value_x,d.p_value_y,rtol=0,atol=1e-9)
