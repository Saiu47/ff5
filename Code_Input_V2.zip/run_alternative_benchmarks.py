from pathlib import Path
import argparse, csv, io, os, re, shutil, subprocess, sys, tempfile, zipfile
import numpy as np
import pandas as pd
import statsmodels.api as sm
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parent
I=ROOT/'Input'; O=ROOT/'Output'; CODE=ROOT/'Code'
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg')
FIELDS=['FF3_Mkt_RF','FF3_SMB','FF3_HML','FF3_RF','FF5_Mkt_RF','FF5_SMB','FF5_HML','RMW','CMA','MOM','FF5_RF']
LABELS={'Developed':'Developed','Developed_ex_US':'Developed ex US','US':'US'}
MODELS={'FF3':FIELDS[:3],'FF5':FIELDS[4:9],'FF5+MOM':FIELDS[4:10]}

def archives(b):
    files=list((I/'Factors').glob('*.zip'))
    def is_b(p):
        n=p.name.lower()
        return n.startswith('f-f_') if b=='US' else n.startswith('developed_ex_us_') if b=='Developed_ex_US' else n.startswith('developed_') and not n.startswith('developed_ex_us_')
    return [p for p in files if is_b(p)]

def parse(b,daily):
    datasets={}
    for p in archives(b):
        n=p.name.lower()
        if ('daily' in n)!=daily: continue
        family='MOM' if 'mom' in n else 'FF5' if '5_factors' in n else 'FF3'
        cols={'MOM':['MOM'],'FF3':FIELDS[:4],'FF5':FIELDS[4:9]+['FF5_RF']}[family]
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            txt=z.read(z.namelist()[0]).decode('utf-8-sig')
        rows=[]
        for r in csv.reader(txt.splitlines()):
            if r and re.fullmatch(r'\d{'+str(8 if daily else 6)+'}',r[0].strip()):
                rows.append([r[0].strip(),*[float(x) for x in r[1:len(cols)+1]]])
        d=pd.DataFrame(rows,columns=['Date',*cols]); d.index=pd.to_datetime(d.pop('Date'),format='%Y%m%d' if daily else '%Y%m');d=d.replace([-99.99,-999],np.nan)/100
        assert d.index.is_unique and family not in datasets
        datasets[family]=d
    assert len(datasets)==3
    return pd.concat([datasets[k] for k in ['FF3','FF5','MOM']],axis=1,join='inner')[FIELDS].sort_index()

def read_model(p):
    return pd.read_excel(p,sheet_name='Model_Input').set_index('Date').sort_index()

def align(d,f):
    result=d.copy(); d2=f.reindex(d.index)
    assert d2.notna().all().all(), 'Missing factors on frozen R1 dates'
    result[FIELDS]=d2[FIELDS]
    for leg in ['EV','NonEV']:
        for fam in ['FF3','FF5']:result[f'{leg}_Excess_{fam}']=result[f'{leg}_Return']-result[f'{fam}_RF']
    return result

def write_model(original,destination,d):
    # The original file is read-only; update only the model-input sheet in a disposable copy.
    w=load_workbook(original);s=w['Model_Input']; cols=[c.value for c in s[1]]
    assert cols==['Date',*d.columns] and s.max_row==len(d)+1
    for row,values in zip(s.iter_rows(min_row=2),d.itertuples(index=True,name=None)):
        assert pd.Timestamp(row[0].value)==values[0]
        for c,v in zip(row[1:],values[1:]):
            if cols[c.column-1] in FIELDS or '_Excess_' in cols[c.column-1]:c.value=float(v)
    w.save(destination)

def run_script(work,name):
    print('RUN',work.name,name,flush=True)
    subprocess.run([sys.executable,str(work/'Code'/name)],cwd=work,env=ENV,check=True)

def replace_once(p,a,b):
    s=p.read_text();assert s.count(a)==1,(p,a,s.count(a));p.write_text(s.replace(a,b))

def verify_equal(a,b,columns=None):
    if columns is not None:a=a[columns];b=b[columns]
    pd.testing.assert_frame_equal(a.reset_index(drop=True),b.reset_index(drop=True),check_dtype=False,rtol=1e-10,atol=1e-12)

def compare_base(work,benchmark):
    # Match selection and nonfactor-dependent values must stay frozen.
    base=I/'V2'/'FF5_Lifecycle_Matching.xlsx';new=work/'Output/Base/FF5_Lifecycle_Matching.xlsx'
    for sheet in ['Annual_Covariates','Primary_Pairs','Strict_Pairs','Sensitivity_Pairs']:
        verify_equal(pd.read_excel(base,sheet_name=sheet),pd.read_excel(new,sheet_name=sheet))
    for sheet in ['Primary_Balance','Strict_Balance']:
        a=pd.read_excel(base,sheet_name=sheet);b=pd.read_excel(new,sheet_name=sheet)
        # Optimizer score norms vary at machine precision between BLAS implementations.
        verify_equal(a,b,[c for c in a if c not in ['Score_Norm','Max_Coefficient_Difference','Max_Propensity_Difference']])
        for c in ['Score_Norm','Max_Coefficient_Difference','Max_Propensity_Difference']:
            if c in a:assert np.allclose(a[c],b[c],atol=1e-8,rtol=1e-8,equal_nan=True)
    for fn in ['Annual_Balance','Annual_Coverage','Annual_Pair_List','Common_Support','Daily_Matched_Portfolios','Pair_Daily_Contribution','Unique_Counts']:
        verify_equal(pd.read_csv(O/'C02'/f'{fn}.csv'),pd.read_csv(work/'Output/C02'/f'{fn}.csv'))
    for k in ['Passenger','Broad']:
        p=work/'Input/V2'/f'FF5_{k}_Data.xlsx';a=read_model(I/'V2'/p.name);b=read_model(p)
        assert a.index.equals(b.index)
        verify_equal(a,b,['EV_Return','NonEV_Return','LS_Return','EV_Constituents','NonEV_Constituents'])
        # Compare regressions to independent prior C01 benchmark results, all 3 models and legs.
        r=pd.read_excel(work/'Output/Base'/f'FF5_{k}_Results.xlsx',sheet_name='Main_Models');r=r[r.Record_Type=='Coefficient'].copy();r.Variable=r.Variable.replace({'alpha':'const'});q=pd.read_csv(O/'C01/Regression_Results.csv');q=q[(q.Benchmark==LABELS[benchmark])&(q.Universe==('Full Passenger' if k=='Passenger' else 'R1 Broad'))&(q.Period=='2015-2025')];q=q.rename(columns={'Leg':'Portfolio','Factor':'Variable'});q.Portfolio=q.Portfolio.replace({'NonEV':'Non-EV'});q=q.merge(r,on=['Portfolio','Model','Variable'],validate='one_to_one');assert len(q)==51
        assert np.allclose(q.Beta,q.Coefficient,atol=1e-10,rtol=0) and np.allclose(q.p,q.p_value,atol=1e-9,rtol=0)
    a=pd.read_excel(O/'Base/FF5_Portfolio_Robustness.xlsx',sheet_name='Daily_Robustness');b=pd.read_excel(work/'Output/Base/FF5_Portfolio_Robustness.xlsx',sheet_name='Daily_Robustness');verify_equal(a,b)
    # State variables and commodity returns must remain unchanged.
    a=pd.read_excel(O/'Base/FF5_State_Dependent_Models.xlsx',sheet_name='State_Data');b=pd.read_excel(work/'Output/Base/FF5_State_Dependent_Models.xlsx',sheet_name='State_Data');verify_equal(a,b,[c for c in a if c not in ['Mkt-RF','SMB','HML','RMW','CMA','MOM']])
    for fn in ['daily_ev_concentration','annual_ev_concentration','kg_gap_eligible_daily','Tata_Daily_Adjustment_Audit','Lordstown_Daily_Bloomberg_Audit','Lordstown_Monthly_Eligibility_Active_Days','Tata_Return_Reconciliation']:
        verify_equal(pd.read_csv(O/'C05'/f'{fn}.csv'),pd.read_csv(work/'Output/C05'/f'{fn}.csv'))
    print('QA passed: fixed dates, raw returns, matching assignments/diagnostics, portfolio robustness, state inputs, corporate-action data, C01 coefficients',benchmark,flush=True)

def run_alt(b):
    target=O/'Alternative_Benchmarks'/b;target.mkdir(parents=True,exist_ok=True)
    f=parse(b,True);m=parse(b,False);dates=read_model(I/'V2/FF5_Passenger_Data.xlsx').index
    assert f.reindex(dates).notna().all().all() and len(dates)==2765
    f.reindex(dates).to_csv(target/'Daily_Factors_Aligned.csv',index_label='Date');m.loc['2015':'2025'].to_csv(target/'Monthly_Factors.csv',index_label='Date')
    with tempfile.TemporaryDirectory(prefix='ff5_'+b+'_') as tmp:
        work=Path(tmp);shutil.copytree(CODE,work/'Code');shutil.copytree(I,work/'Input');(work/'Output').mkdir()
        for c in ['Base','C02','C03','C04','C05']:(work/'Output'/c).mkdir()
        for k in ['Passenger','Broad']:
            p=I/'V2'/f'FF5_{k}_Data.xlsx'; d=align(read_model(p),f);d.to_csv(target/f'{k}_Model_Input.csv',index_label='Date');write_model(p,work/'Input/V2'/p.name,d)
        # C03 historical US assertions do not apply to new benchmarks. Validate against the independent C01 matrix instead.
        p=work/'Code/C03/01_hac_wald.py'
        replace_once(p,"    expected={'Mkt-RF':.6561,'SMB':.6947,'HML':-.6643,'RMW':-1.0308,'CMA':-.4051,'MOM':-.1408}\n    for k,v in expected.items():\n        if abs(float(baseline.params[k])-v)>0.000055:raise ValueError(f'V2 baseline mismatch {k}: {baseline.params[k]} != {v}')\n",'')
        replace_once(p,'    assert abs(chow_df.iloc[0].Statistic-3.1181)<0.0001 and abs(chow_df.iloc[1].Statistic-5.5911)<0.0001\n','')
        replace_once(p,'US USD factors',LABELS[b]+' USD factors')
        replace_once(p,'Conventional Chow RSS F, reproduced R1','Conventional Chow RSS F (alternative benchmark; reference only)')
        replace_once(p,'none required; all market/factor inputs unchanged from R1 V2','R1 market data held fixed; alternative factor series on R1 dates')
        # C04 uses the matching geography for the official monthly data.
        p=work/'Code/C04/02_official_monthly_factors.py'
        if b=='Developed_ex_US':
            replace_once(p,'Developed_5_Factors_CSV (1).zip','Developed_ex_US_5_Factors_CSV.zip');replace_once(p,'Developed_Mom_Factor_CSV (1).zip','Developed_ex_US_Mom_Factor_CSV.zip');replace_once(p,'Official Developed FF5 + Developed MOM monthly','Official Developed ex US FF5 + MOM monthly')
        p=work/'Code/C04/01_frequency_reconstruction.py'
        replace_once(p,"'R1 reproduced'","'Historical R1 construction, alternative factors'")
        # Reuse the validated, factor-independent robustness portfolio series.
        p=work/'Code/Base/04_portfolio_robustness.py'
        p.write_text(p.read_text().split('def main():')[0]+(CODE/'Benchmarks/frozen_robustness_main.py').read_text())
        shutil.copy2(O/'Base/FF5_Portfolio_Robustness.xlsx',work/'Input/V2/FF5_Portfolio_Robustness_frozen.xlsx')
        # The base model is needed by lifecycle and C04 independent cross-checks.
        run_script(work,'Base/03_run_factor_models.py')
        shutil.copy2(work/'Output/Base/FF5_Passenger_Results.xlsx',work/'Input/V2/FF5_Passenger_Results.xlsx')
        for name in ['Base/04_portfolio_robustness.py','Base/05_lifecycle_matching.py','Base/06_state_dependent_models.py']:
            run_script(work,name)
        shutil.copy2(work/'Output/Base/FF5_Lifecycle_Matching.xlsx',work/'Input/V2/FF5_Lifecycle_Matching.xlsx')
        for name in ['C02/01_matching_audit.py','C03/01_hac_wald.py','C04/01_frequency_reconstruction.py','C04/02_official_monthly_factors.py','C05/01_gap_concentration.py','C05/02_event_audit.py','C05/03_external_event_sources.py','C05/05_tata_sensitivity.py','C05/06_canoo_sensitivity.py','C05/07_bloomberg_validation.py','C05/08_issuer_documentation.py']:
            run_script(work,name)
        compare_base(work,b)
        for c in ['Base','C02','C03','C04','C05']:
            dest=target/c;dest.mkdir(exist_ok=True)
            for p in sorted((work/'Output'/c).iterdir()):
                if p.suffix.lower() in ['.csv','.xlsx','.json']:shutil.copy2(p,dest/p.name)
        print('COMPLETED',b,flush=True)

def carryforward():
    rows=[]
    for universe in ['Passenger','Broad']:
        for construction,d in [('ObservedPriceOnly',read_model(I/'V2'/f'FF5_{universe}_Data.xlsx')),('CarryForward',read_model(I/'V1'/f'FF5_{universe}_Data.xlsx'))]:
            for benchmark in LABELS:
                q=align(d,parse(benchmark,True));assert len(q)==2765
                for model,cols in MODELS.items():
                    for leg in ['EV','NonEV','LS']:
                        y=q.LS_Return if leg=='LS' else q[f'{leg}_Excess_{"FF3" if model=="FF3" else "FF5"}'];x=q[cols].rename(columns=dict(zip(cols,['Mkt-RF','SMB','HML','RMW','CMA','MOM'])));fit=sm.OLS(y,sm.add_constant(x)).fit(cov_type='HAC',cov_kwds={'maxlags':22});ci=fit.conf_int()
                        for k,v in fit.params.items():rows.append(dict(Universe=universe,Construction=construction,Benchmark=LABELS[benchmark],Model=model,Portfolio=leg,Variable=k,Coefficient=v,HAC_SE=fit.bse[k],p_value=fit.pvalues[k],CI95_Lower=ci.loc[k,0],CI95_Upper=ci.loc[k,1],N=int(fit.nobs),Adj_R2=fit.rsquared_adj))
    dest=O/'Alternative_Benchmarks';dest.mkdir(exist_ok=True);pd.DataFrame(rows).to_csv(dest/'CarryForward_Comparison.csv',index=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--benchmark',choices=['Developed','Developed_ex_US','all'],default='all');args=p.parse_args()
    for b in (['Developed','Developed_ex_US'] if args.benchmark=='all' else [args.benchmark]):run_alt(b)
    carryforward()
